export type HealthStatus = 'ok' | 'vigilance' | 'alerte' | 'none';

export type UserRole = 'ELEVEUR' | 'DGE' | 'VETERINAIRE' | 'BCEG' | 'ADMIN';

export type ProvinceGabon =
  | 'Estuaire'
  | 'Haut-Ogooué'
  | 'Ogooué-Maritime'
  | 'Woleu-Ntem'
  | 'Moyen-Ogooué'
  | 'Ngounié'
  | 'Nyanga'
  | 'Ogooué-Ivindo'
  | 'Ogooué-Lolo';

export type AlertWorkflowStatus = 'Nouvelle' | 'En analyse' | 'Confirmée' | 'Infirmée' | 'Close';

export interface DailyLogEntry {
  id: string;
  bandeCode: string;
  dayNumber: number;
  dateIso: string; // ex. 2026-11-06
  dateLabel: string; // ex. 6 nov. 2026
  mortalite: number;
  alimentKg: number;
  effectifPresent: number;
  poidsMoyenG?: number;
  observation?: string;
  synced: boolean;
  updatedAt: string;
}

export interface ProphylaxisStep {
  id: string;
  dayNumber: number;
  dateLabel: string;
  vaccineOrCare: string;
  route: string;
  lotVaccin: string;
  completed: boolean;
  completedAt?: string;
}

export interface FarmRecord {
  code: string; // ex. EST-0014
  nom: string;
  province: ProvinceGabon;
  localite: string;
  responsable: string;
  cohorte: 'POUFA-2026-T3' | 'POUFA-2026-T4' | 'POUFA-2025-T4';
  bandeActiveCode: string; // ex. EST-0014-B03
  lotActifCode: string; // ex. EST-0014-B03-L01
  souche: 'Ross 308' | 'Cobb 500';
  jourBande: number;
  dureeCibleJours: number;
  effectifInitial: number;
  effectifPresent: number;
  mortaliteCumuleePct: number;
  poidsMoyenG: number;
  indiceConsommation: number;
  alimentCumuleKg: number;
  coutProductionFcfaKg: number;
  statut: HealthStatus;
  derniereMaj: string; // ex. 6 nov. 2026 à 07:40
  lat: number;
  lng: number;
}

export interface SanitaryAlert {
  id: string; // ex. ALR-2026-089
  fermeCode: string;
  fermeNom: string;
  bandeCode: string;
  province: ProvinceGabon;
  localite: string;
  dateDeclaration: string;
  symptomes: string[];
  mortalite24h: number;
  mortalitePct24h: number;
  effectifPresent: number;
  statutWorkflow: AlertWorkflowStatus;
  gravite: HealthStatus;
  veterinaireAssigne: string;
  commentaireTerrain: string;
  diagnosticVeterinaire?: string;
  photoMetadata?: {
    fileName: string;
    dimensions: string;
    sizeKb: number;
    capturedAt: string;
  };
  historique: {
    etape: AlertWorkflowStatus;
    date: string;
    auteur: string;
    note: string;
  }[];
}

export interface SyncQueueItem {
  id?: number;
  uid: string;
  type: 'RELEVE_JOUR' | 'PESEE_HEBDO' | 'DECLARATION_SANITAIRE' | 'PROPHYLAXIE';
  cibleCode: string;
  resume: string;
  createdAt: string;
  status: 'PENDING' | 'SYNCED' | 'FAILED';
  payloadJson: string;
}

export interface PublicQrLotData {
  codeLot: string;
  reconnu: boolean;
  clos: boolean;
  produit: {
    designation: string;
    souche: string;
    modeElevage: string;
    calibreMoyenKg: number;
    conditionnement: string;
    dateAbattageOuSortie: string;
    dateLimiteConsommation: string;
  };
  origine: {
    codeFerme: string;
    nomFerme: string;
    localite: string;
    province: ProvinceGabon;
    codeBande: string;
    couvoirOrigine: string;
    provenderie: string;
  };
  parcours: {
    etape: string;
    date: string;
    lieu: string;
    detail: string;
    statut: HealthStatus;
  }[];
}
