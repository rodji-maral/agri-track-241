const intFormatter = new Intl.NumberFormat('fr-FR', {
  maximumFractionDigits: 0,
});

const dec1Formatter = new Intl.NumberFormat('fr-FR', {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
});

const dec2Formatter = new Intl.NumberFormat('fr-FR', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

export function formatInt(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return '—';
  }
  return intFormatter.format(Math.round(value));
}

export function formatDec1(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return '—';
  }
  return dec1Formatter.format(value);
}

export function formatDec2(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return '—';
  }
  return dec2Formatter.format(value);
}

export function formatKg(value: number | null | undefined, decimals: 0 | 1 = 0): string {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return 'Non renseigné';
  }
  return `${decimals === 1 ? formatDec1(value) : formatInt(value)} kg`;
}

export function formatGrammes(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return 'Non renseigné';
  }
  return `${formatInt(value)} g`;
}

export function formatPct(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return 'Non renseigné';
  }
  return `${formatDec1(value)} %`;
}

export function formatFcfa(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return 'Non renseigné';
  }
  return `${formatInt(value)} FCFA`;
}

const SHORT_MONTHS_FR = [
  'janv.',
  'févr.',
  'mars',
  'avr.',
  'mai',
  'juin',
  'juil.',
  'août',
  'sept.',
  'oct.',
  'nov.',
  'déc.',
];

export function formatDateGabon(dateInput: Date | string): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  if (Number.isNaN(d.getTime())) {
    return String(dateInput);
  }
  // Format "6 nov. 2026" en fuseau Africa/Libreville (UTC+1)
  const parts = new Intl.DateTimeFormat('fr-FR', {
    timeZone: 'Africa/Libreville',
    day: 'numeric',
    month: 'numeric',
    year: 'numeric',
  }).formatToParts(d);

  const day = parts.find((p) => p.type === 'day')?.value ?? '1';
  const monthIdx = Number(parts.find((p) => p.type === 'month')?.value ?? '1') - 1;
  const year = parts.find((p) => p.type === 'year')?.value ?? '2026';

  return `${day} ${SHORT_MONTHS_FR[monthIdx] ?? 'nov.'} ${year}`;
}

export function formatDateTimeGabon(dateInput: Date | string): string {
  const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
  if (Number.isNaN(d.getTime())) {
    return String(dateInput);
  }
  const datePart = formatDateGabon(d);
  const timePart = new Intl.DateTimeFormat('fr-FR', {
    timeZone: 'Africa/Libreville',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(d);
  return `${datePart} à ${timePart}`;
}

/**
 * Redimensionne une photo terrain à ~1280 px max de côté en JPEG qualité 0.7 avant stockage Dexie/IndexedDB
 */
export async function compressFieldPhoto(file: File): Promise<{
  dataUrl: string;
  width: number;
  height: number;
  sizeKb: number;
  fileName: string;
}> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Lecture du fichier image impossible.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Format d’image non reconnu.'));
      img.onload = () => {
        const maxSide = 1280;
        let width = img.width;
        let height = img.height;
        if (width > maxSide || height > maxSide) {
          if (width >= height) {
            height = Math.round((height * maxSide) / width);
            width = maxSide;
          } else {
            width = Math.round((width * maxSide) / height);
            height = maxSide;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Contexte graphique indisponible sur cet appareil.'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
        const approxBytes = Math.round((dataUrl.length * 3) / 4);
        resolve({
          dataUrl,
          width,
          height,
          sizeKb: Math.max(1, Math.round(approxBytes / 1024)),
          fileName: file.name.replace(/\.[^.]+$/, '') + '-1280p.jpg',
        });
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}
