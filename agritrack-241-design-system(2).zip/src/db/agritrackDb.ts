import Dexie, { type Table } from 'dexie';
import type {
  DailyLogEntry,
  FarmRecord,
  ProphylaxisStep,
  SanitaryAlert,
  SyncQueueItem,
} from '../types/domain';
import {
  INITIAL_DAILY_LOGS_EST0014,
  INITIAL_FARMS_150,
  INITIAL_PROPHYLAXIS_EST0014,
  INITIAL_SANITARY_ALERTS,
} from '../data/gabonSeedData';

export class AgriTrackDatabase extends Dexie {
  dailyLogs!: Table<DailyLogEntry, string>;
  prophylaxis!: Table<ProphylaxisStep, string>;
  farms!: Table<FarmRecord, string>;
  alerts!: Table<SanitaryAlert, string>;
  syncQueue!: Table<SyncQueueItem, number>;

  constructor() {
    super('AgriTrack241_DB_v1');
    this.version(1).stores({
      dailyLogs: 'id, bandeCode, dayNumber, synced',
      prophylaxis: 'id, dayNumber, completed',
      farms: 'code, province, cohorte, statut',
      alerts: 'id, fermeCode, province, statutWorkflow',
      syncQueue: '++id, uid, status, createdAt',
    });
  }
}

export const db = new AgriTrackDatabase();

export async function ensureSeedDatabase(): Promise<void> {
  try {
    const logCount = await db.dailyLogs.count();
    if (logCount === 0) {
      await db.dailyLogs.bulkPut(INITIAL_DAILY_LOGS_EST0014);
    }
    const prophCount = await db.prophylaxis.count();
    if (prophCount === 0) {
      await db.prophylaxis.bulkPut(INITIAL_PROPHYLAXIS_EST0014);
    }
    const farmCount = await db.farms.count();
    if (farmCount === 0) {
      await db.farms.bulkPut(INITIAL_FARMS_150);
    }
    const alertCount = await db.alerts.count();
    if (alertCount === 0) {
      await db.alerts.bulkPut(INITIAL_SANITARY_ALERTS);
    }
  } catch {
    // Repli en mémoire si IndexedDB est bloqué en navigation privée stricte
  }
}
