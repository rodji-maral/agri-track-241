import { useEffect, useMemo, useState } from 'react';
import {
  Building2,
  Eye,
  Palette,
  QrCode,
  RefreshCw,
  Smartphone,
  SlidersHorizontal,
  Wifi,
  WifiOff,
} from 'lucide-react';
import type {
  AlertWorkflowStatus,
  DailyLogEntry,
  FarmRecord,
  ProphylaxisStep,
  SanitaryAlert,
  SyncQueueItem,
  UserRole,
} from './types/domain';
import {
  INITIAL_DAILY_LOGS_EST0014,
  INITIAL_FARMS_150,
  INITIAL_PROPHYLAXIS_EST0014,
  INITIAL_SANITARY_ALERTS,
} from './data/gabonSeedData';
import { db, ensureSeedDatabase } from './db/agritrackDb';
import { EleveurView } from './views/EleveurView';
import { BureauView } from './views/BureauView';
import { PublicQrView } from './views/PublicQrView';
import { DesignSystemView } from './views/DesignSystemView';
import { Drawer } from './components/ui/Drawer';
import { Toast } from './components/ui/Toast';
import { Button } from './components/ui/Button';
import { StatusBadge } from './components/ui/StatusBadge';
import { CodeCopyBadge } from './components/ui/CodeCopyBadge';
import { EmptyState } from './components/ui/EmptyState';
import {
  formatDateGabon,
  formatDateTimeGabon,
  formatInt,
} from './utils/formatters';

export type ActiveWorkspace = 'eleveur' | 'bureau' | 'qr' | 'design';

export function App() {
  const [workspace, setWorkspace] = useState<ActiveWorkspace>('eleveur');
  const [bureauRole, setBureauRole] = useState<UserRole>('DGE');
  const [qrLotCode, setQrLotCode] = useState<string>('EST-0014-B03-L01');

  // Modes d'auto-contrôle visuel (Test du plissement des yeux 2s & Niveaux de gris)
  const [squintMode, setSquintMode] = useState<boolean>(false);
  const [grayscaleMode, setGrayscaleMode] = useState<boolean>(false);

  // État réseau et synchronisation IndexedDB (Dexie)
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [lastSyncedAt, setLastSyncedAt] = useState<string>('6 nov. 2026 à 07:40');
  const [syncDrawerOpen, setSyncDrawerOpen] = useState<boolean>(false);

  // Données métier synchronisées avec IndexedDB
  const [farms, setFarms] = useState<FarmRecord[]>(INITIAL_FARMS_150);
  const [dailyLogs, setDailyLogs] = useState<DailyLogEntry[]>(INITIAL_DAILY_LOGS_EST0014);
  const [prophylaxisSteps, setProphylaxisSteps] = useState<ProphylaxisStep[]>(
    INITIAL_PROPHYLAXIS_EST0014
  );
  const [alerts, setAlerts] = useState<SanitaryAlert[]>(INITIAL_SANITARY_ALERTS);
  const [pendingSyncItems, setPendingSyncItems] = useState<SyncQueueItem[]>([]);

  // Notification Toast aria-live
  const [toastState, setToastState] = useState<{
    message: string;
    detail?: string;
    status: 'ok' | 'vigilance' | 'alerte';
  } | null>(null);

  // Initialisation de la base locale Dexie
  useEffect(() => {
    let mounted = true;
    (async () => {
      await ensureSeedDatabase();
      try {
        const [dbFarms, dbLogs, dbProph, dbAlerts, dbQueue] = await Promise.all([
          db.farms.toArray(),
          db.dailyLogs.toArray(),
          db.prophylaxis.toArray(),
          db.alerts.toArray(),
          db.syncQueue.where('status').equals('PENDING').toArray(),
        ]);
        if (!mounted) return;
        if (dbFarms.length > 0) setFarms(dbFarms);
        if (dbLogs.length > 0) setDailyLogs(dbLogs);
        if (dbProph.length > 0) setProphylaxisSteps(dbProph);
        if (dbAlerts.length > 0) setAlerts(dbAlerts);
        setPendingSyncItems(dbQueue);
      } catch {
        // Repli mémoire déjà initialisé
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const activeEleveurFarm = useMemo(() => {
    return farms.find((f) => f.code === 'EST-0014') ?? farms[0];
  }, [farms]);

  const enqueueSyncOperation = async (
    type: SyncQueueItem['type'],
    cibleCode: string,
    resume: string,
    payload: unknown
  ) => {
    const newItem: SyncQueueItem = {
      uid: `SYNC-${Date.now()}`,
      type,
      cibleCode,
      resume,
      createdAt: formatDateTimeGabon(new Date()),
      status: isOnline ? 'SYNCED' : 'PENDING',
      payloadJson: JSON.stringify(payload),
    };

    if (!isOnline) {
      setPendingSyncItems((prev) => [newItem, ...prev]);
      try {
        await db.syncQueue.add(newItem);
      } catch {
        // Ignorer en mode privé
      }
    } else {
      setLastSyncedAt(formatDateTimeGabon(new Date()));
    }
  };

  // Enregistrement d'une journée par l'éleveur (en 3 taps)
  const handleSaveDailyLog = async (entry: {
    mortalite: number;
    alimentKg: number;
    poidsMoyenG?: number;
    observation?: string;
  }) => {
    const currentDay = activeEleveurFarm.jourBande;
    const newPresent = Math.max(0, activeEleveurFarm.effectifPresent - entry.mortalite);
    const totalMorts = activeEleveurFarm.effectifInitial - newPresent;
    const newMortalitePct = Number(
      ((totalMorts / activeEleveurFarm.effectifInitial) * 100).toFixed(1)
    );
    const newAlimentCumul = activeEleveurFarm.alimentCumuleKg + entry.alimentKg;
    const nowLabel = formatDateTimeGabon(new Date());

    const newLog: DailyLogEntry = {
      id: `EST-0014-B03-J${currentDay}`,
      bandeCode: activeEleveurFarm.bandeActiveCode,
      dayNumber: currentDay,
      dateIso: '2026-11-06',
      dateLabel: '6 nov. 2026',
      mortalite: entry.mortalite,
      alimentKg: entry.alimentKg,
      effectifPresent: newPresent,
      poidsMoyenG: entry.poidsMoyenG,
      observation: entry.observation,
      synced: isOnline,
      updatedAt: nowLabel,
    };

    const updatedFarm: FarmRecord = {
      ...activeEleveurFarm,
      jourBande: Math.min(activeEleveurFarm.dureeCibleJours, currentDay + 1),
      effectifPresent: newPresent,
      mortaliteCumuleePct: newMortalitePct,
      alimentCumuleKg: newAlimentCumul,
      statut:
        newMortalitePct >= 5.5
          ? 'alerte'
          : newMortalitePct >= 4.0
          ? 'vigilance'
          : 'ok',
      derniereMaj: nowLabel,
    };

    setDailyLogs((prev) => {
      const filtered = prev.filter((l) => l.id !== newLog.id);
      return [...filtered, newLog];
    });

    setFarms((prev) =>
      prev.map((f) => (f.code === updatedFarm.code ? updatedFarm : f))
    );

    try {
      await db.dailyLogs.put(newLog);
      await db.farms.put(updatedFarm);
    } catch {
      // Repli mémoire
    }

    await enqueueSyncOperation(
      'RELEVE_JOUR',
      activeEleveurFarm.bandeActiveCode,
      `Jour ${currentDay} : ${formatInt(entry.mortalite)} mort(s), ${formatInt(
        entry.alimentKg
      )} kg d'aliment`,
      newLog
    );

    // Message de confirmation exact requis par le cahier des charges
    setToastState({
      message: isOnline
        ? 'Enregistré.'
        : 'Enregistré sur ce téléphone. Envoi dès le retour du réseau.',
      detail: `Bande ${activeEleveurFarm.bandeActiveCode} · Jour ${currentDay} · Effectif présent : ${formatInt(
        newPresent
      )} sujets`,
      status: isOnline ? 'ok' : 'vigilance',
    });
  };

  // Enregistrement d'une pesée hebdomadaire
  const handleSaveWeighing = async (poidsMoyenG: number, echantillonCount: number) => {
    const nowLabel = formatDateTimeGabon(new Date());
    const updatedFarm: FarmRecord = {
      ...activeEleveurFarm,
      poidsMoyenG,
      derniereMaj: nowLabel,
    };

    setFarms((prev) =>
      prev.map((f) => (f.code === updatedFarm.code ? updatedFarm : f))
    );

    try {
      await db.farms.put(updatedFarm);
    } catch {
      // Repli mémoire
    }

    await enqueueSyncOperation(
      'PESEE_HEBDO',
      activeEleveurFarm.bandeActiveCode,
      `Pesée J${activeEleveurFarm.jourBande} : ${formatInt(poidsMoyenG)} g (${formatInt(
        echantillonCount
      )} sujets)`,
      { poidsMoyenG, echantillonCount }
    );

    setToastState({
      message: isOnline
        ? 'Enregistré.'
        : 'Enregistré sur ce téléphone. Envoi dès le retour du réseau.',
      detail: `Pesée enregistrée : ${formatInt(poidsMoyenG)} g sur un échantillon de ${formatInt(
        echantillonCount
      )} sujets.`,
      status: isOnline ? 'ok' : 'vigilance',
    });
  };

  // Validation d'une étape de prophylaxie
  const handleToggleProphylaxis = async (stepId: string) => {
    const target = prophylaxisSteps.find((s) => s.id === stepId);
    if (!target) return;
    const nextCompleted = !target.completed;
    const updatedStep: ProphylaxisStep = {
      ...target,
      completed: nextCompleted,
      completedAt: nextCompleted ? formatDateTimeGabon(new Date()) : undefined,
    };

    setProphylaxisSteps((prev) =>
      prev.map((s) => (s.id === stepId ? updatedStep : s))
    );

    try {
      await db.prophylaxis.put(updatedStep);
    } catch {
      // Repli mémoire
    }

    await enqueueSyncOperation(
      'PROPHYLAXIE',
      activeEleveurFarm.bandeActiveCode,
      `Prophylaxie J${target.dayNumber} (${target.vaccineOrCare}) : ${
        nextCompleted ? 'Administré' : 'À préparer'
      }`,
      updatedStep
    );

    setToastState({
      message: isOnline
        ? 'Enregistré.'
        : 'Enregistré sur ce téléphone. Envoi dès le retour du réseau.',
      detail: `${target.vaccineOrCare} — ${
        nextCompleted ? 'Administration validée' : 'Remis en attente'
      }`,
      status: isOnline ? 'ok' : 'vigilance',
    });
  };

  // Création d'une alerte sanitaire depuis le carnet éleveur
  const handleCreateAlert = async (alertData: {
    symptomes: string[];
    mortalite24h: number;
    commentaireTerrain: string;
    photoMetadata?: SanitaryAlert['photoMetadata'];
  }) => {
    const nowLabel = formatDateTimeGabon(new Date());
    const pct24h = Number(
      ((alertData.mortalite24h / Math.max(1, activeEleveurFarm.effectifPresent)) * 100).toFixed(1)
    );
    const newAlert: SanitaryAlert = {
      id: `ALR-2026-09${alerts.length + 1}`,
      fermeCode: activeEleveurFarm.code,
      fermeNom: activeEleveurFarm.nom,
      bandeCode: activeEleveurFarm.bandeActiveCode,
      province: activeEleveurFarm.province,
      localite: activeEleveurFarm.localite,
      dateDeclaration: nowLabel,
      symptomes: alertData.symptomes,
      mortalite24h: alertData.mortalite24h,
      mortalitePct24h: pct24h,
      effectifPresent: activeEleveurFarm.effectifPresent,
      statutWorkflow: 'Nouvelle',
      gravite: pct24h >= 1.5 ? 'alerte' : 'vigilance',
      veterinaireAssigne: 'Dr. Marc-Aurèle Obiang (Brigade Vétérinaire Estuaire)',
      commentaireTerrain: alertData.commentaireTerrain,
      photoMetadata: alertData.photoMetadata,
      historique: [
        {
          etape: 'Nouvelle',
          date: nowLabel,
          auteur: `${activeEleveurFarm.responsable} (Éleveur ${activeEleveurFarm.code})`,
          note: alertData.commentaireTerrain,
        },
      ],
    };

    setAlerts((prev) => [newAlert, ...prev]);

    const updatedFarm: FarmRecord = {
      ...activeEleveurFarm,
      statut: newAlert.gravite,
      derniereMaj: nowLabel,
    };
    setFarms((prev) =>
      prev.map((f) => (f.code === updatedFarm.code ? updatedFarm : f))
    );

    try {
      await db.alerts.put(newAlert);
      await db.farms.put(updatedFarm);
    } catch {
      // Repli mémoire
    }

    await enqueueSyncOperation(
      'DECLARATION_SANITAIRE',
      newAlert.id,
      `Déclaration sanitaire ${activeEleveurFarm.code} (${formatInt(
        alertData.mortalite24h
      )} morts / 24 h)`,
      newAlert
    );

    setToastState({
      message: isOnline
        ? 'Déclaration sanitaire transmise à la brigade vétérinaire DGE.'
        : 'Enregistré sur ce téléphone. Envoi dès le retour du réseau.',
      detail: `Dossier ${newAlert.id} · Bande ${activeEleveurFarm.bandeActiveCode}`,
      status: isOnline ? 'ok' : 'vigilance',
    });
  };

  // Qualification vétérinaire d'une alerte sanitaire (Rôle VETERINAIRE)
  const handleUpdateAlertStatus = async (
    alertId: string,
    nextStatus: AlertWorkflowStatus,
    diagnosticNote: string
  ) => {
    const target = alerts.find((a) => a.id === alertId);
    if (!target) return;
    const nowLabel = formatDateTimeGabon(new Date());

    const nextGravite =
      nextStatus === 'Confirmée'
        ? 'alerte'
        : nextStatus === 'Infirmée' || nextStatus === 'Close'
        ? 'ok'
        : 'vigilance';

    const updatedAlert: SanitaryAlert = {
      ...target,
      statutWorkflow: nextStatus,
      gravite: nextGravite,
      diagnosticVeterinaire: diagnosticNote,
      historique: [
        ...target.historique,
        {
          etape: nextStatus,
          date: nowLabel,
          auteur: `${target.veterinaireAssigne.split(' (')[0]} (Rôle VETERINAIRE)`,
          note: diagnosticNote,
        },
      ],
    };

    setAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? updatedAlert : a))
    );

    try {
      await db.alerts.put(updatedAlert);
    } catch {
      // Repli mémoire
    }

    setToastState({
      message: `Statut du dossier ${alertId} mis à jour : « ${nextStatus} ».`,
      detail: `Exploitation ${target.fermeCode} · Inscrit au registre sanitaire national DGE.`,
      status: nextStatus === 'Confirmée' ? 'alerte' : 'ok',
    });
  };

  // Synchronisation manuelle de la file d'attente IndexedDB
  const handleSyncNow = async () => {
    if (!isOnline) {
      setToastState({
        message: 'Appareil hors ligne.',
        detail: `Rétablissez la connexion réseau pour envoyer les ${formatInt(
          pendingSyncItems.length
        )} enregistrement(s) stocké(s) sur ce téléphone.`,
        status: 'vigilance',
      });
      return;
    }

    const syncedCount = pendingSyncItems.length;
    setPendingSyncItems([]);
    setDailyLogs((prev) => prev.map((l) => ({ ...l, synced: true })));
    const nowLabel = formatDateTimeGabon(new Date());
    setLastSyncedAt(nowLabel);

    try {
      await db.syncQueue.clear();
    } catch {
      // Repli mémoire
    }

    setToastState({
      message: 'Enregistré.',
      detail:
        syncedCount > 0
          ? `${formatInt(syncedCount)} enregistrement(s) transmis au serveur national DGE (${nowLabel}).`
          : `Synchronisation vérifiée à ${nowLabel}.`,
      status: 'ok',
    });
  };

  const handleToggleOnline = () => {
    setIsOnline((prev) => {
      const next = !prev;
      setToastState({
        message: next
          ? 'Connexion réseau rétablie (Mode En ligne).'
          : 'Mode Hors ligne activé : stockage local IndexedDB actif.',
        detail: next
          ? pendingSyncItems.length > 0
            ? `${formatInt(pendingSyncItems.length)} relevé(s) prêt(s) à être synchronisé(s).`
            : 'Tous les relevés sont synchronisés.'
          : 'Les saisies de l’éleveur sont conservées sur cet appareil sans perte.',
        status: next ? 'ok' : 'vigilance',
      });
      return next;
    });
  };

  return (
    <div
      className={`${squintMode ? 'squint-mode' : ''} ${
        grayscaleMode ? 'grayscale-mode' : ''
      }`}
    >
      {/* Barre supérieure institutionnelle de navigation entre les 4 espaces du programme POUFA (masquée à l'impression A5) */}
      <div className="no-print border-b border-border bg-ink text-surface">
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-2 px-4 py-1.5 text-14">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="mr-2 font-semibold text-surface tabular-nums">
              AgriTrack 241 · POUFA Gabon :
            </span>

            <button
              type="button"
              onClick={() => setWorkspace('eleveur')}
              className={`inline-flex min-h-[2.25rem] items-center gap-1.5 rounded-sm px-2.5 py-1 text-14 font-medium transition-colors duration-150 cursor-pointer ${
                workspace === 'eleveur'
                  ? 'bg-green-700 text-surface font-semibold'
                  : 'text-surface/80 hover:bg-surface/10 hover:text-surface'
              }`}
            >
              <Smartphone size={16} strokeWidth={1.75} aria-hidden="true" />
              <span>1. Écran Éleveur (Carnet terrain)</span>
            </button>

            <button
              type="button"
              onClick={() => setWorkspace('bureau')}
              className={`inline-flex min-h-[2.25rem] items-center gap-1.5 rounded-sm px-2.5 py-1 text-14 font-medium transition-colors duration-150 cursor-pointer ${
                workspace === 'bureau'
                  ? 'bg-green-700 text-surface font-semibold'
                  : 'text-surface/80 hover:bg-surface/10 hover:text-surface'
              }`}
            >
              <Building2 size={16} strokeWidth={1.75} aria-hidden="true" />
              <span>2. Portail Bureau (DGE · Vétérinaire · 150 fermes)</span>
            </button>

            <button
              type="button"
              onClick={() => setWorkspace('qr')}
              className={`inline-flex min-h-[2.25rem] items-center gap-1.5 rounded-sm px-2.5 py-1 text-14 font-medium transition-colors duration-150 cursor-pointer ${
                workspace === 'qr'
                  ? 'bg-green-700 text-surface font-semibold'
                  : 'text-surface/80 hover:bg-surface/10 hover:text-surface'
              }`}
            >
              <QrCode size={16} strokeWidth={1.75} aria-hidden="true" />
              <span>3. Page publique QR (A5)</span>
            </button>

            <button
              type="button"
              onClick={() => setWorkspace('design')}
              className={`inline-flex min-h-[2.25rem] items-center gap-1.5 rounded-sm px-2.5 py-1 text-14 font-medium transition-colors duration-150 cursor-pointer ${
                workspace === 'design'
                  ? 'bg-green-700 text-surface font-semibold'
                  : 'text-surface/80 hover:bg-surface/10 hover:text-surface'
              }`}
            >
              <Palette size={16} strokeWidth={1.75} aria-hidden="true" />
              <span>4. Référentiel /design (Lot A)</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={handleToggleOnline}
              className="inline-flex min-h-[2rem] items-center gap-1.5 rounded-sm border border-surface/25 px-2.5 py-0.5 text-14 font-medium text-surface hover:bg-surface/10 cursor-pointer tabular-nums"
            >
              {isOnline ? (
                <>
                  <Wifi size={16} strokeWidth={1.75} aria-hidden="true" />
                  <span>Réseau : En ligne</span>
                </>
              ) : (
                <>
                  <WifiOff size={16} strokeWidth={1.75} aria-hidden="true" />
                  <span>Réseau : Hors ligne ({formatInt(pendingSyncItems.length)})</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setSquintMode((v) => !v)}
              title="Test du plissement des yeux : vérifier l'action principale et l'état en 2 secondes"
              className={`inline-flex min-h-[2rem] items-center gap-1 rounded-sm border px-2 py-0.5 text-14 font-medium cursor-pointer ${
                squintMode
                  ? 'border-flag-yellow bg-surface text-ink font-semibold'
                  : 'border-surface/25 text-surface/85 hover:bg-surface/10'
              }`}
            >
              <Eye size={16} strokeWidth={1.75} aria-hidden="true" />
              <span>Plissement 2s</span>
            </button>

            <button
              type="button"
              onClick={() => setGrayscaleMode((v) => !v)}
              title="Vérifier que les 4 formes géométriques d'état sont lisibles en niveaux de gris"
              className={`inline-flex min-h-[2rem] items-center gap-1 rounded-sm border px-2 py-0.5 text-14 font-medium cursor-pointer ${
                grayscaleMode
                  ? 'border-flag-yellow bg-surface text-ink font-semibold'
                  : 'border-surface/25 text-surface/85 hover:bg-surface/10'
              }`}
            >
              <SlidersHorizontal size={16} strokeWidth={1.75} aria-hidden="true" />
              <span>Niveaux de gris</span>
            </button>
          </div>
        </div>
      </div>

      {/* Zone de notification flottante Toast (aria-live="polite") */}
      {toastState && (
        <div className="no-print fixed bottom-20 right-4 z-50 w-full max-w-md px-4 sm:px-0">
          <Toast
            message={toastState.message}
            detail={toastState.detail}
            status={toastState.status}
            onClose={() => setToastState(null)}
          />
        </div>
      )}

      {/* Rendu de l'espace actif */}
      {workspace === 'eleveur' && (
        <EleveurView
          farm={activeEleveurFarm}
          dailyLogs={dailyLogs}
          prophylaxisSteps={prophylaxisSteps}
          isOnline={isOnline}
          pendingSyncItems={pendingSyncItems}
          lastSyncedAt={lastSyncedAt}
          onOpenSyncDrawer={() => setSyncDrawerOpen(true)}
          onToggleOnline={handleToggleOnline}
          onSyncNow={handleSyncNow}
          onSaveDailyLog={handleSaveDailyLog}
          onSaveWeighing={handleSaveWeighing}
          onToggleProphylaxis={handleToggleProphylaxis}
          onCreateAlert={handleCreateAlert}
          onOpenQrLot={(code) => {
            setQrLotCode(code);
            setWorkspace('qr');
          }}
          onSwitchToBureau={() => setWorkspace('bureau')}
          onCopiedCode={(code) =>
            setToastState({
              message: `Identifiant ${code} copié dans le presse-papiers.`,
              status: 'ok',
            })
          }
        />
      )}

      {workspace === 'bureau' && (
        <BureauView
          activeRole={bureauRole}
          onChangeRole={setBureauRole}
          farms={farms}
          alerts={alerts}
          onUpdateAlertStatus={handleUpdateAlertStatus}
          isOnline={isOnline}
          pendingSyncItems={pendingSyncItems}
          lastSyncedAt={lastSyncedAt}
          onOpenSyncDrawer={() => setSyncDrawerOpen(true)}
          onSwitchToEleveur={() => setWorkspace('eleveur')}
          onOpenQrLot={(code) => {
            setQrLotCode(code);
            setWorkspace('qr');
          }}
          onOpenDesignSystem={() => setWorkspace('design')}
          onCopiedCode={(code) =>
            setToastState({
              message: `Identifiant ${code} copié dans le presse-papiers.`,
              status: 'ok',
            })
          }
        />
      )}

      {workspace === 'qr' && (
        <PublicQrView
          initialLotCode={qrLotCode}
          onNavigateBack={() => setWorkspace('eleveur')}
          onCopiedCode={(code) =>
            setToastState({
              message: `Identifiant ${code} copié dans le presse-papiers.`,
              status: 'ok',
            })
          }
        />
      )}

      {workspace === 'design' && (
        <DesignSystemView
          onNavigateBack={() => setWorkspace('eleveur')}
          squintMode={squintMode}
          onToggleSquint={() => setSquintMode((v) => !v)}
          grayscaleMode={grayscaleMode}
          onToggleGrayscale={() => setGrayscaleMode((v) => !v)}
        />
      )}

      {/* Tiroir global de synchronisation IndexedDB (ouvert au clic sur SyncStatusBar) */}
      <Drawer
        isOpen={syncDrawerOpen}
        onClose={() => setSyncDrawerOpen(false)}
        title="Journal de synchronisation locale (IndexedDB / Dexie)"
        subtitle={`Dernier envoi réussi : ${lastSyncedAt} · Fuseau Africa/Libreville`}
        footer={
          <div className="flex flex-wrap items-center justify-between gap-2">
            <Button
              variant="secondary"
              size="bureau"
              icon={isOnline ? WifiOff : Wifi}
              onClick={handleToggleOnline}
            >
              {isOnline ? 'Passer Hors ligne' : 'Passer En ligne'}
            </Button>
            <Button
              variant="primary"
              size="bureau"
              icon={RefreshCw}
              disabled={!isOnline || pendingSyncItems.length === 0}
              onClick={handleSyncNow}
            >
              Synchroniser ({formatInt(pendingSyncItems.length)})
            </Button>
          </div>
        }
      >
        <div className="flex flex-col gap-4 text-14 tabular-nums">
          <div className="flex items-center justify-between rounded-sm border border-border bg-bg p-3">
            <span className="font-medium text-ink">État actuel de la liaison :</span>
            <StatusBadge
              status={isOnline && pendingSyncItems.length === 0 ? 'ok' : 'vigilance'}
              customLabel={
                !isOnline
                  ? 'Hors ligne (Stockage téléphone actif)'
                  : pendingSyncItems.length > 0
                  ? `${formatInt(pendingSyncItems.length)} envoi(s) en attente`
                  : 'En ligne · Synchronisé'
              }
            />
          </div>

          {pendingSyncItems.length === 0 ? (
            <EmptyState
              title="Aucun enregistrement en attente d’envoi."
              description={`Toutes les saisies du carnet (${formatDateGabon(
                new Date('2026-11-06T08:00:00+01:00')
              )}) ont été transmises au serveur central de la DGE.`}
            />
          ) : (
            <ul className="divide-y divide-border rounded-sm border border-border bg-surface">
              {pendingSyncItems.map((item) => (
                <li key={item.uid} className="flex flex-col gap-1 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <CodeCopyBadge code={item.cibleCode} compact />
                    <span className="text-ink-muted">{item.createdAt}</span>
                  </div>
                  <p className="font-semibold text-ink">{item.resume}</p>
                  <span className="text-ink-muted">
                    Type : {item.type} · Statut : Stocké dans IndexedDB
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </Drawer>
    </div>
  );
}

export default App;
