import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  CalendarCheck,
  Camera,
  Check,
  ClipboardList,
  FileSpreadsheet,
  HeartPulse,
  QrCode,
  RefreshCw,
  Scale,
  Settings,
  ShieldAlert,
  Wifi,
  WifiOff,
} from 'lucide-react';
import type {
  DailyLogEntry,
  FarmRecord,
  ProphylaxisStep,
  SanitaryAlert,
  SyncQueueItem,
} from '../types/domain';
import { Button } from '../components/ui/Button';
import { NumberStepper } from '../components/ui/NumberStepper';
import { Field } from '../components/ui/Field';
import { StatusBadge } from '../components/ui/StatusBadge';
import { SyncStatusBar } from '../components/ui/SyncStatusBar';
import { CodeCopyBadge } from '../components/ui/CodeCopyBadge';
import { EmptyState } from '../components/ui/EmptyState';
import { ErrorState } from '../components/ui/ErrorState';
import {
  compressFieldPhoto,
  formatDateGabon,
  formatDateTimeGabon,
  formatDec1,
  formatDec2,
  formatInt,
} from '../utils/formatters';

export type EleveurTab = 'aujourdhui' | 'bande' | 'sante' | 'plus';

export interface EleveurViewProps {
  farm: FarmRecord;
  dailyLogs: DailyLogEntry[];
  prophylaxisSteps: ProphylaxisStep[];
  isOnline: boolean;
  pendingSyncItems: SyncQueueItem[];
  lastSyncedAt: string;
  onOpenSyncDrawer: () => void;
  onToggleOnline: () => void;
  onSyncNow: () => void;
  onSaveDailyLog: (entry: {
    mortalite: number;
    alimentKg: number;
    poidsMoyenG?: number;
    observation?: string;
  }) => void;
  onSaveWeighing: (poidsMoyenG: number, echantillonCount: number) => void;
  onToggleProphylaxis: (stepId: string) => void;
  onCreateAlert: (alertData: {
    symptomes: string[];
    mortalite24h: number;
    commentaireTerrain: string;
    photoMetadata?: SanitaryAlert['photoMetadata'];
  }) => void;
  onOpenQrLot: (codeLot: string) => void;
  onSwitchToBureau: () => void;
  onCopiedCode?: (code: string) => void;
}

const SYMPTOM_CHOICES = [
  'Mortalité journalière > 1,5 %',
  'Râles respiratoires ou bec ouvert',
  'Diarrhées blanchâtres ou verdâtres',
  'Fientes sanguinolentes (suspicion coccidiose)',
  'Baisse brutale de consommation d’eau ou d’aliment',
  'Prostration / sujets entassés',
  'Boiteries ou paralysie des pattes',
];

export const EleveurView: React.FC<EleveurViewProps> = ({
  farm,
  dailyLogs,
  prophylaxisSteps,
  isOnline,
  pendingSyncItems,
  lastSyncedAt,
  onOpenSyncDrawer,
  onToggleOnline,
  onSyncNow,
  onSaveDailyLog,
  onSaveWeighing,
  onToggleProphylaxis,
  onCreateAlert,
  onOpenQrLot,
  onSwitchToBureau,
  onCopiedCode,
}) => {
  const [activeTab, setActiveTab] = useState<EleveurTab>('aujourdhui');

  // État du flux de saisie en 3 taps ("Saisir la journée")
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3>(1);

  const sortedLogsDesc = useMemo(
    () => [...dailyLogs].sort((a, b) => b.dayNumber - a.dayNumber),
    [dailyLogs]
  );
  const latestLog = sortedLogsDesc[0];
  const yesterdayMorts = latestLog?.mortalite ?? 3;
  const yesterdayAliment = latestLog?.alimentKg ?? 222;

  const [mortsInput, setMortsInput] = useState<number | null>(yesterdayMorts);
  const [alimentInput, setAlimentInput] = useState<number | null>(yesterdayAliment);
  const [wizardObservation, setWizardObservation] = useState('');
  const [wizardError, setWizardError] = useState<string | null>(null);

  // Saisie pesée hebdomadaire dans l'onglet Bande
  const [showWeighingForm, setShowWeighingForm] = useState(false);
  const [weighingGrams, setWeighingGrams] = useState<string>(String(farm.poidsMoyenG));
  const [weighingSample, setWeighingSample] = useState<string>('100');
  const [weighingError, setWeighingError] = useState<string | null>(null);

  // Déclaration problème sanitaire dans l'onglet Santé
  const [showAlertForm, setShowAlertForm] = useState(false);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [alertMorts24h, setAlertMorts24h] = useState<string>('15');
  const [alertComment, setAlertComment] = useState<string>('');
  const [alertError, setAlertError] = useState<string | null>(null);
  const [compressedPhoto, setCompressedPhoto] = useState<{
    fileName: string;
    dimensions: string;
    sizeKb: number;
    capturedAt: string;
  } | null>(null);
  const [compressingPhoto, setCompressingPhoto] = useState(false);

  // Les 7 derniers jours pour la fiche papier
  const last7DaysLogs = useMemo(() => {
    return [...sortedLogsDesc].slice(0, 7).sort((a, b) => a.dayNumber - b.dayNumber);
  }, [sortedLogsDesc]);

  const totals7Days = useMemo(() => {
    const totalMorts = last7DaysLogs.reduce((acc, row) => acc + row.mortalite, 0);
    const totalAliment = last7DaysLogs.reduce((acc, row) => acc + row.alimentKg, 0);
    const lastEffectif =
      last7DaysLogs.length > 0
        ? last7DaysLogs[last7DaysLogs.length - 1].effectifPresent
        : farm.effectifPresent;
    return { totalMorts, totalAliment, lastEffectif };
  }, [last7DaysLogs, farm.effectifPresent]);

  const latestWeighingLog = useMemo(
    () => sortedLogsDesc.find((l) => l.poidsMoyenG !== undefined),
    [sortedLogsDesc]
  );

  const progressPct = Math.min(
    100,
    Math.round((farm.jourBande / farm.dureeCibleJours) * 100)
  );

  const openDailyWizard = () => {
    setMortsInput(yesterdayMorts);
    setAlimentInput(yesterdayAliment);
    setWizardObservation('');
    setWizardError(null);
    setWizardStep(1);
    setIsWizardOpen(true);
  };

  const handleNextStep1 = () => {
    if (mortsInput === null || Number.isNaN(mortsInput) || mortsInput < 0) {
      setWizardError(
        'Le champ « Morts du jour » est obligatoire. Indiquez 0 si aucune perte n’a été constatée.'
      );
      return;
    }
    if (mortsInput > farm.effectifPresent) {
      setWizardError(
        `Les morts du jour (${formatInt(mortsInput)}) dépassent l'effectif présent (${formatInt(
          farm.effectifPresent
        )}).`
      );
      return;
    }
    setWizardError(null);
    setWizardStep(2);
  };

  const handleNextStep2 = () => {
    if (alimentInput === null || Number.isNaN(alimentInput) || alimentInput <= 0) {
      setWizardError(
        'Indiquez la quantité d’aliment distribuée en kilogrammes (ex. 225 kg).'
      );
      return;
    }
    if (alimentInput > 5000) {
      setWizardError(
        `La quantité saisie (${formatInt(
          alimentInput
        )} kg) dépasse la capacité de stockage du bâtiment (5 000 kg). Vérifiez l'unité.`
      );
      return;
    }
    setWizardError(null);
    setWizardStep(3);
  };

  const handleConfirmDailySave = () => {
    if (mortsInput === null || alimentInput === null) return;
    onSaveDailyLog({
      mortalite: mortsInput,
      alimentKg: alimentInput,
      observation: wizardObservation.trim() || undefined,
    });
    setIsWizardOpen(false);
  };

  const handleWeighingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const grams = Number(weighingGrams);
    const sample = Number(weighingSample);
    if (!weighingGrams.trim() || Number.isNaN(grams) || grams < 35 || grams > 5500) {
      setWeighingError(
        'Le poids moyen par sujet doit être compris entre 35 g et 5 500 g.'
      );
      return;
    }
    if (!weighingSample.trim() || Number.isNaN(sample) || sample < 10) {
      setWeighingError(
        'L’échantillon de pesée doit comporter au moins 10 sujets pour être représentatif.'
      );
      return;
    }
    setWeighingError(null);
    onSaveWeighing(Math.round(grams), Math.round(sample));
    setShowWeighingForm(false);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCompressingPhoto(true);
    try {
      const result = await compressFieldPhoto(file);
      setCompressedPhoto({
        fileName: result.fileName,
        dimensions: `${result.width} × ${result.height} px (JPEG 0.7)`,
        sizeKb: result.sizeKb,
        capturedAt: formatDateTimeGabon(new Date()),
      });
    } catch {
      setAlertError(
        'Le redimensionnement de la photo a échoué. Choisissez une image au format JPG ou PNG.'
      );
    } finally {
      setCompressingPhoto(false);
    }
  };

  const handleAlertSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedSymptoms.length === 0) {
      setAlertError('Cochez au moins un signe clinique observé dans le bâtiment.');
      return;
    }
    const morts24 = Number(alertMorts24h);
    if (!alertMorts24h.trim() || Number.isNaN(morts24) || morts24 < 0) {
      setAlertError('Indiquez le nombre de sujets morts sur les dernières 24 heures.');
      return;
    }
    if (morts24 > farm.effectifPresent) {
      setAlertError(
        `Les morts sur 24 h (${formatInt(morts24)}) dépassent l'effectif présent (${formatInt(
          farm.effectifPresent
        )}).`
      );
      return;
    }
    if (!alertComment.trim()) {
      setAlertError(
        'Décrivez brièvement les observations du bâtiment (ex. litière humide, heure de constat).'
      );
      return;
    }
    setAlertError(null);
    onCreateAlert({
      symptomes: selectedSymptoms,
      mortalite24h: morts24,
      commentaireTerrain: alertComment.trim(),
      photoMetadata: compressedPhoto ?? undefined,
    });
    setShowAlertForm(false);
    setSelectedSymptoms([]);
    setAlertComment('');
    setCompressedPhoto(null);
  };

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(symptom) ? prev.filter((s) => s !== symptom) : [...prev, symptom]
    );
  };

  return (
    <div className="min-h-screen bg-bg pb-24 text-ink">
      {/* En-tête permanent du Carnet Éleveur */}
      <header className="sticky top-0 z-30 border-b border-border bg-surface">
        <div className="tricolor-bar" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>
        <div className="mx-auto flex max-w-xl flex-wrap items-center justify-between gap-2 px-4 py-2.5">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-16 font-semibold text-ink">{farm.nom}</span>
              <StatusBadge status={farm.statut} compact />
            </div>
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-14 text-ink-muted tabular-nums">
              <span>Bande :</span>
              <CodeCopyBadge
                code={farm.bandeActiveCode}
                compact
                onCopied={onCopiedCode}
              />
              <span>· {farm.souche}</span>
            </div>
          </div>

          <SyncStatusBar
            isOnline={isOnline}
            pendingCount={pendingSyncItems.length}
            lastSyncedAt={lastSyncedAt}
            onClick={onOpenSyncDrawer}
            compact
          />
        </div>
      </header>

      {/* Contenu principal centré format Carnet de ferme (max-w-xl) */}
      <main className="mx-auto max-w-xl px-4 pt-4">
        {/* Flux de saisie en 3 taps ("Saisir la journée") */}
        {isWizardOpen ? (
          <section
            aria-label="Saisie de la journée en 3 étapes"
            className="flex flex-col gap-4 rounded-md border border-border bg-surface p-4"
          >
            <div className="flex items-center justify-between border-b border-border pb-3">
              <div>
                <span className="text-14 font-medium text-ink-muted tabular-nums">
                  Étape {wizardStep} sur 3 · Bande {farm.bandeActiveCode}
                </span>
                <h1 className="text-20 font-semibold text-ink tabular-nums">
                  Relevé du Jour {farm.jourBande} ({formatDateGabon(new Date('2026-11-06T08:00:00+01:00'))})
                </h1>
              </div>
              <Button
                variant="secondary"
                size="bureau"
                icon={ArrowLeft}
                onClick={() => setIsWizardOpen(false)}
              >
                Fermer
              </Button>
            </div>

            {/* Indicateur d'étape sobre */}
            <div className="grid grid-cols-3 gap-1.5 tabular-nums" aria-hidden="true">
              {[
                { step: 1, label: '1. Morts du jour' },
                { step: 2, label: '2. Aliment (kg)' },
                { step: 3, label: '3. Récapitulatif' },
              ].map((s) => (
                <div
                  key={s.step}
                  className={`rounded-sm border px-2.5 py-1.5 text-14 font-medium ${
                    wizardStep === s.step
                      ? 'border-blue-700 bg-blue-50 text-blue-700'
                      : wizardStep > s.step
                      ? 'border-green-700 bg-green-50 text-green-700'
                      : 'border-border bg-bg text-ink-muted'
                  }`}
                >
                  {s.label}
                </div>
              ))}
            </div>

            {wizardError && (
              <ErrorState
                title="Valeur à corriger avant de continuer"
                correctionInstruction={wizardError}
                actionLabel="Réinitialiser avec la valeur d'hier"
                mode="terrain"
                onAction={() => {
                  if (wizardStep === 1) setMortsInput(yesterdayMorts);
                  if (wizardStep === 2) setAlimentInput(yesterdayAliment);
                  setWizardError(null);
                }}
              />
            )}

            {/* Étape 1 : Morts du jour */}
            {wizardStep === 1 && (
              <div className="flex flex-col gap-4">
                <NumberStepper
                  id="stepper-morts-jour"
                  label="Combien de sujets morts aujourd’hui ?"
                  unit="sujets"
                  value={mortsInput}
                  onChange={(val) => {
                    setMortsInput(val);
                    setWizardError(null);
                  }}
                  yesterdayValue={yesterdayMorts}
                  yesterdayLabel="Hier (J22)"
                  min={0}
                  max={farm.effectifPresent + 50}
                />

                <div className="flex items-center justify-between rounded-sm border border-border bg-bg px-3.5 py-2.5 text-14 tabular-nums">
                  <span className="text-ink-muted">Effectif présent avant saisie :</span>
                  <strong className="font-semibold text-ink">
                    {formatInt(farm.effectifPresent)} sujets
                  </strong>
                </div>

                <Button
                  variant="primary"
                  size="terrain"
                  fullWidth
                  icon={ArrowRight}
                  iconPosition="right"
                  onClick={handleNextStep1}
                >
                  Continuer vers l’aliment (Étape 2/3)
                </Button>
              </div>
            )}

            {/* Étape 2 : Aliment en kg */}
            {wizardStep === 2 && (
              <div className="flex flex-col gap-4">
                <NumberStepper
                  id="stepper-aliment-jour"
                  label="Quantité d’aliment distribuée aujourd’hui"
                  unit="kg"
                  value={alimentInput}
                  onChange={(val) => {
                    setAlimentInput(val);
                    setWizardError(null);
                  }}
                  yesterdayValue={yesterdayAliment}
                  yesterdayLabel="Hier (J22)"
                  min={0}
                  max={5000}
                  step={5}
                />

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <Button
                    variant="secondary"
                    size="terrain"
                    icon={ArrowLeft}
                    onClick={() => {
                      setWizardError(null);
                      setWizardStep(1);
                    }}
                  >
                    Retour aux morts
                  </Button>
                  <Button
                    variant="primary"
                    size="terrain"
                    icon={ArrowRight}
                    iconPosition="right"
                    onClick={handleNextStep2}
                  >
                    Voir le récapitulatif
                  </Button>
                </div>
              </div>
            )}

            {/* Étape 3 : Récapitulatif + Enregistrer (zone du pouce en bas) */}
            {wizardStep === 3 && (
              <div className="flex flex-col gap-4">
                <div className="rounded-sm border border-border bg-bg p-4">
                  <h2 className="mb-3 text-16 font-semibold text-ink">
                    Vérifiez les chiffres avant l’enregistrement dans le carnet
                  </h2>
                  <dl className="divide-y divide-border text-16 tabular-nums">
                    <div className="flex items-baseline justify-between py-2.5">
                      <dt className="text-ink-muted">Date & jour de bande</dt>
                      <dd className="font-semibold text-ink">
                        Jour {farm.jourBande} · 6 nov. 2026
                      </dd>
                    </div>
                    <div className="flex items-baseline justify-between py-2.5">
                      <dt className="text-ink-muted">Morts constatés ce jour</dt>
                      <dd className="text-20 font-semibold text-ink">
                        {formatInt(mortsInput)}{' '}
                        <span className="text-14 font-regular text-ink-muted">sujets</span>
                      </dd>
                    </div>
                    <div className="flex items-baseline justify-between py-2.5">
                      <dt className="text-ink-muted">Aliment distribué</dt>
                      <dd className="text-20 font-semibold text-ink">
                        {formatInt(alimentInput)}{' '}
                        <span className="text-14 font-regular text-ink-muted">kg</span>
                      </dd>
                    </div>
                    <div className="flex items-baseline justify-between py-2.5">
                      <dt className="text-ink-muted">Nouvel effectif présent calculé</dt>
                      <dd className="text-20 font-semibold text-green-700">
                        {formatInt(farm.effectifPresent - (mortsInput ?? 0))}{' '}
                        <span className="text-14 font-regular text-ink-muted">sujets</span>
                      </dd>
                    </div>
                  </dl>
                </div>

                <Field
                  id="obs-jour"
                  label="Observation bâtiment (facultatif)"
                  mode="terrain"
                  placeholder="Ex. Température 28 °C, litière sèche, eau claire"
                  value={wizardObservation}
                  onChange={(e) => setWizardObservation(e.target.value)}
                />

                {!isOnline && (
                  <div className="rounded-sm border border-orange-600 bg-orange-50 px-3.5 py-2.5 text-14 text-ink">
                    Mode hors-ligne actif : ce relevé sera enregistré immédiatement sur ce téléphone et transmis dès le retour du réseau.
                  </div>
                )}

                <div className="grid grid-cols-1 gap-2 pt-1 sm:grid-cols-[auto_1fr]">
                  <Button
                    variant="secondary"
                    size="terrain"
                    icon={ArrowLeft}
                    onClick={() => setWizardStep(2)}
                  >
                    Modifier l’aliment
                  </Button>
                  <Button
                    variant="primary"
                    size="terrain"
                    fullWidth
                    icon={Check}
                    onClick={handleConfirmDailySave}
                  >
                    Enregistrer la journée
                  </Button>
                </div>
              </div>
            )}
          </section>
        ) : (
          <>
            {/* ONGLET 1 : AUJOURD'HUI (Strictement conforme : Jour + barre fine, 1 bouton pleine largeur, 3 chiffres, mini-tableau 7 jours) */}
            {activeTab === 'aujourdhui' && (
              <div className="flex flex-col gap-6">
                {/* Bloc principal : Jour de bande + Barre de progression fine + Bouton unique pleine largeur */}
                <section
                  aria-label="Avancement de la bande et saisie quotidienne"
                  className="flex flex-col gap-4 rounded-md border border-border bg-surface p-4"
                >
                  <div className="flex flex-col gap-2">
                    <div className="flex items-baseline justify-between gap-2 tabular-nums">
                      <h1 className="text-24 font-semibold text-ink tabular-nums">
                        Jour {formatInt(farm.jourBande)} sur {formatInt(farm.dureeCibleJours)}
                      </h1>
                      <span className="text-14 font-medium text-ink-muted tabular-nums">
                        Vendredi 6 nov. 2026 · {progressPct} % du cycle
                      </span>
                    </div>

                    {/* Barre de progression fine de 4 px */}
                    <div
                      className="h-1 w-full overflow-hidden rounded-none bg-bg"
                      role="progressbar"
                      aria-valuenow={farm.jourBande}
                      aria-valuemin={1}
                      aria-valuemax={farm.dureeCibleJours}
                    >
                      <div
                        className="h-full bg-green-700 transition-all duration-150"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  </div>

                  {/* UN bouton pleine largeur "Saisir la journée" */}
                  <Button
                    variant="primary"
                    size="terrain"
                    fullWidth
                    icon={ClipboardList}
                    onClick={openDailyWizard}
                  >
                    Saisir la journée
                  </Button>
                </section>

                {/* 3 chiffres lisibles d'un coup d'œil */}
                <section
                  aria-label="Indicateurs du jour"
                  className="grid grid-cols-3 gap-2.5"
                >
                  <article className="flex flex-col justify-between rounded-sm border border-border bg-surface p-3">
                    <span className="text-14 font-medium text-ink-muted">
                      Effectif présent
                    </span>
                    <div className="my-1 flex items-baseline gap-1 tabular-nums">
                      <span className="text-24 font-semibold text-ink tabular-nums">
                        {formatInt(farm.effectifPresent)}
                      </span>
                      <span className="text-14 font-regular text-ink-muted">sujets</span>
                    </div>
                    <span className="text-14 text-ink-muted tabular-nums">
                      Maj : {latestLog?.dateLabel ?? '5 nov. 2026'}
                    </span>
                  </article>

                  <article className="flex flex-col justify-between rounded-sm border border-border bg-surface p-3">
                    <span className="text-14 font-medium text-ink-muted">
                      Mortalité cumulée
                    </span>
                    <div className="my-1 flex items-baseline gap-1 tabular-nums">
                      <span className="text-24 font-semibold text-ink tabular-nums">
                        {formatDec1(farm.mortaliteCumuleePct)}
                      </span>
                      <span className="text-14 font-regular text-ink-muted">%</span>
                    </div>
                    <span className="text-14 text-ink-muted tabular-nums">
                      {formatInt(farm.effectifInitial - farm.effectifPresent)} morts cumulés
                    </span>
                  </article>

                  <article className="flex flex-col justify-between rounded-sm border border-border bg-surface p-3">
                    <span className="text-14 font-medium text-ink-muted">
                      Dernière pesée
                    </span>
                    <div className="my-1 flex items-baseline gap-1 tabular-nums">
                      <span className="text-24 font-semibold text-ink tabular-nums">
                        {formatInt(farm.poidsMoyenG)}
                      </span>
                      <span className="text-14 font-regular text-ink-muted">g</span>
                    </div>
                    <span className="text-14 text-ink-muted tabular-nums">
                      {latestWeighingLog
                        ? `J${latestWeighingLog.dayNumber} (${latestWeighingLog.dateLabel})`
                        : 'Pesée J21'}
                    </span>
                  </article>
                </section>

                {/* Mini-tableau des 7 derniers jours calqué sur la fiche papier (Date / Morts / Aliment kg / Effectif + totaux en bas) */}
                <section
                  aria-label="Fiche d'élevage des 7 derniers jours"
                  className="overflow-hidden rounded-sm border border-border bg-surface"
                >
                  <div className="flex items-center justify-between border-b border-border bg-bg px-3.5 py-2.5">
                    <h2 className="text-16 font-semibold text-ink">
                      Fiche d’élevage — 7 derniers jours enregistrés
                    </h2>
                    <span className="text-14 text-ink-muted tabular-nums">
                      Bande {farm.bandeActiveCode}
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse text-14 tabular-nums">
                      <thead>
                        <tr className="h-10 border-b border-border bg-bg text-ink">
                          <th scope="col" className="px-3 text-left font-semibold">
                            Date (Jour)
                          </th>
                          <th scope="col" className="px-3 text-right font-semibold">
                            Morts <span className="font-regular text-ink-muted">(sujets)</span>
                          </th>
                          <th scope="col" className="px-3 text-right font-semibold">
                            Aliment <span className="font-regular text-ink-muted">(kg)</span>
                          </th>
                          <th scope="col" className="px-3 text-right font-semibold">
                            Effectif <span className="font-regular text-ink-muted">(présent)</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {last7DaysLogs.map((row) => (
                          <tr key={row.id} className="h-10 hover:bg-bg/60">
                            <td className="px-3 py-1.5 text-left font-medium text-ink">
                              <span>{row.dateLabel}</span>
                              <span className="ml-1.5 text-ink-muted">(J{row.dayNumber})</span>
                              {!row.synced && (
                                <span
                                  className="ml-1.5 inline-block rounded-sm border border-orange-600 bg-orange-50 px-1.5 py-0.5 text-14 font-medium text-orange-600"
                                  title="En attente d'envoi réseau"
                                >
                                  Local
                                </span>
                              )}
                            </td>
                            <td className="px-3 py-1.5 text-right font-medium text-ink">
                              {formatInt(row.mortalite)}
                            </td>
                            <td className="px-3 py-1.5 text-right font-medium text-ink">
                              {formatInt(row.alimentKg)}
                            </td>
                            <td className="px-3 py-1.5 text-right font-semibold text-ink">
                              {formatInt(row.effectifPresent)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="h-10 border-t-2 border-border bg-bg font-semibold text-ink">
                          <td className="px-3 py-1.5 text-left">
                            Total 7 jours
                          </td>
                          <td className="px-3 py-1.5 text-right">
                            {formatInt(totals7Days.totalMorts)}
                          </td>
                          <td className="px-3 py-1.5 text-right">
                            {formatInt(totals7Days.totalAliment)} kg
                          </td>
                          <td className="px-3 py-1.5 text-right">
                            {formatInt(totals7Days.lastEffectif)}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </section>
              </div>
            )}

            {/* ONGLET 2 : BANDE (Registre complet, pesée hebdomadaire, identifiants lot/bande) */}
            {activeTab === 'bande' && (
              <div className="flex flex-col gap-6">
                <section className="flex flex-col gap-4 rounded-sm border border-border bg-surface p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2 border-b border-border pb-3">
                    <div>
                      <h1 className="text-20 font-semibold text-ink">
                        Registre de bande {farm.bandeActiveCode}
                      </h1>
                      <p className="text-14 text-ink-muted">
                        Mise en place : 15 oct. 2026 · Effectif initial : {formatInt(farm.effectifInitial)} poussins {farm.souche}
                      </p>
                    </div>
                    <CodeCopyBadge code={farm.lotActifCode} onCopied={onCopiedCode} />
                  </div>

                  <dl className="grid grid-cols-2 gap-3 text-14 tabular-nums sm:grid-cols-4">
                    <div className="rounded-sm border border-border bg-bg p-3">
                      <dt className="text-ink-muted">Aliment cumulé</dt>
                      <dd className="mt-1 flex items-baseline gap-1">
                        <span className="text-20 font-semibold text-ink">
                          {formatInt(farm.alimentCumuleKg)}
                        </span>
                        <span className="text-14 font-regular text-ink-muted">kg</span>
                      </dd>
                    </div>
                    <div className="rounded-sm border border-border bg-bg p-3">
                      <dt className="text-ink-muted">Indice conso. (IC)</dt>
                      <dd className="mt-1 flex items-baseline gap-1">
                        <span className="text-20 font-semibold text-ink">
                          {formatDec2(farm.indiceConsommation)}
                        </span>
                        <span className="text-14 font-regular text-ink-muted">kg/kg</span>
                      </dd>
                    </div>
                    <div className="rounded-sm border border-border bg-bg p-3">
                      <dt className="text-ink-muted">Poids vif J21</dt>
                      <dd className="mt-1 flex items-baseline gap-1">
                        <span className="text-20 font-semibold text-ink">
                          {formatInt(farm.poidsMoyenG)}
                        </span>
                        <span className="text-14 font-regular text-ink-muted">g</span>
                      </dd>
                    </div>
                    <div className="rounded-sm border border-border bg-bg p-3">
                      <dt className="text-ink-muted">Cible Ross 308 (J21)</dt>
                      <dd className="mt-1 flex items-baseline gap-1">
                        <span className="text-20 font-semibold text-green-700">925</span>
                        <span className="text-14 font-regular text-ink-muted">g (+15 g)</span>
                      </dd>
                    </div>
                  </dl>

                  {/* Action principale de l'onglet Bande : Enregistrer une pesée hebdomadaire */}
                  {!showWeighingForm ? (
                    <Button
                      variant="primary"
                      size="terrain"
                      fullWidth
                      icon={Scale}
                      onClick={() => setShowWeighingForm(true)}
                    >
                      Enregistrer une pesée hebdomadaire
                    </Button>
                  ) : (
                    <form
                      onSubmit={handleWeighingSubmit}
                      className="flex flex-col gap-4 rounded-sm border border-border bg-bg p-4"
                    >
                      <h2 className="text-18 font-semibold text-ink">
                        Nouvelle pesée d’échantillon — Jour {farm.jourBande}
                      </h2>
                      {weighingError && (
                        <ErrorState
                          title="Pesée non valide"
                          correctionInstruction={weighingError}
                          mode="terrain"
                        />
                      )}
                      <Field
                        id="poids-moyen-g"
                        label="Poids vif moyen constaté par sujet"
                        unit="g"
                        hint="Cible J23 : 1 065 g"
                        mode="terrain"
                        type="number"
                        requiredLabel
                        value={weighingGrams}
                        onChange={(e) => setWeighingGrams(e.target.value)}
                      />
                      <Field
                        id="echantillon-sujets"
                        label="Nombre de sujets pesés"
                        unit="sujets"
                        hint="Recommandé DGE : 100 sujets"
                        mode="terrain"
                        type="number"
                        requiredLabel
                        value={weighingSample}
                        onChange={(e) => setWeighingSample(e.target.value)}
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          variant="secondary"
                          size="terrain"
                          onClick={() => {
                            setShowWeighingForm(false);
                            setWeighingError(null);
                          }}
                        >
                          Annuler
                        </Button>
                        <Button
                          type="submit"
                          variant="primary"
                          size="terrain"
                          icon={Check}
                        >
                          Enregistrer la pesée
                        </Button>
                      </div>
                    </form>
                  )}
                </section>

                {/* État pesée de la semaine */}
                <EmptyState
                  mode="terrain"
                  title="Prochaine pesée réglementaire attendue à J28 (mercredi 11 nov. 2026)"
                  description="La pesée S3 (J21) a été validée à 940 g sur 100 sujets. Pesez au moins 4 % de l'effectif à jeun le matin."
                />
              </div>
            )}

            {/* ONGLET 3 : SANTÉ (Déclaration sanitaire + compression photo ~1280px + Calendrier de prophylaxie) */}
            {activeTab === 'sante' && (
              <div className="flex flex-col gap-6">
                <section className="flex flex-col gap-4 rounded-sm border border-border bg-surface p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h1 className="text-20 font-semibold text-ink">
                        Surveillance sanitaire & Prophylaxie
                      </h1>
                      <p className="text-14 text-ink-muted">
                        Bande {farm.bandeActiveCode} · Brigade vétérinaire de rattachement : Estuaire (Nkok / Owendo)
                      </p>
                    </div>
                    <StatusBadge status={farm.statut} />
                  </div>

                  {!showAlertForm ? (
                    <Button
                      variant="primary"
                      size="terrain"
                      fullWidth
                      icon={ShieldAlert}
                      onClick={() => setShowAlertForm(true)}
                    >
                      Déclarer un problème sanitaire
                    </Button>
                  ) : (
                    <form
                      onSubmit={handleAlertSubmit}
                      className="flex flex-col gap-4 rounded-sm border border-border bg-bg p-4"
                    >
                      <h2 className="text-18 font-semibold text-ink">
                        Déclaration sanitaire au vétérinaire de secteur
                      </h2>

                      {alertError && (
                        <ErrorState
                          title="Déclaration incomplète"
                          correctionInstruction={alertError}
                          mode="terrain"
                        />
                      )}

                      <fieldset className="flex flex-col gap-2">
                        <legend className="mb-1 text-16 font-semibold text-ink">
                          Signes cliniques observés dans le bâtiment (obligatoire) :
                        </legend>
                        {SYMPTOM_CHOICES.map((symptom) => {
                          const checked = selectedSymptoms.includes(symptom);
                          return (
                            <label
                              key={symptom}
                              className={`flex min-h-[3rem] cursor-pointer items-center gap-3 rounded-sm border px-3 py-2 text-14 font-medium transition-colors duration-150 ${
                                checked
                                  ? 'border-blue-700 bg-blue-50 text-ink'
                                  : 'border-border bg-surface text-ink hover:bg-bg'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => toggleSymptom(symptom)}
                                className="h-5 w-5 accent-green-700"
                              />
                              <span>{symptom}</span>
                            </label>
                          );
                        })}
                      </fieldset>

                      <Field
                        id="alert-morts-24h"
                        label="Morts constatés sur les dernières 24 heures"
                        unit="sujets"
                        hint={`Effectif présent : ${formatInt(farm.effectifPresent)}`}
                        mode="terrain"
                        type="number"
                        requiredLabel
                        value={alertMorts24h}
                        onChange={(e) => setAlertMorts24h(e.target.value)}
                      />

                      <Field
                        id="alert-comment"
                        label="Observations terrain (litière, eau, température, bâtiment)"
                        mode="terrain"
                        requiredLabel
                        placeholder="Ex. Râles entendus côté sud après coupure ventilateur"
                        value={alertComment}
                        onChange={(e) => setAlertComment(e.target.value)}
                      />

                      {/* Photo terrain redimensionnée automatiquement à ~1280 px JPEG 0.7 */}
                      <div className="flex flex-col gap-2 rounded-sm border border-border bg-surface p-3">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-14 font-semibold text-ink">
                            Photo de terrain (compressée à 1280 px · JPEG 0.7)
                          </span>
                          <span className="text-14 text-ink-muted">Facultatif</span>
                        </div>
                        <label className="inline-flex min-h-[3rem] cursor-pointer items-center justify-center gap-2 rounded-sm border border-border bg-bg px-4 py-2 text-14 font-semibold text-ink hover:bg-green-50">
                          <Camera size={20} strokeWidth={1.75} aria-hidden="true" />
                          <span>
                            {compressingPhoto
                              ? 'Compression JPEG 0.7 en cours…'
                              : 'Joindre une photo du bâtiment ou de la litière'}
                          </span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handlePhotoUpload}
                            className="sr-only"
                          />
                        </label>
                        {compressedPhoto && (
                          <div className="rounded-sm border border-green-700/40 bg-green-50 px-3 py-2 text-14 tabular-nums">
                            <p className="font-semibold text-ink">
                              Cliché prêt : {compressedPhoto.fileName}
                            </p>
                            <p className="text-ink-muted">
                              {compressedPhoto.dimensions} · Poids réduit : {formatInt(compressedPhoto.sizeKb)} Ko
                            </p>
                          </div>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          variant="secondary"
                          size="terrain"
                          onClick={() => {
                            setShowAlertForm(false);
                            setAlertError(null);
                          }}
                        >
                          Annuler
                        </Button>
                        <Button
                          type="submit"
                          variant="danger"
                          size="terrain"
                          icon={ShieldAlert}
                        >
                          Transmettre l’alerte
                        </Button>
                      </div>
                    </form>
                  )}
                </section>

                {/* Calendrier de prophylaxie de la bande */}
                <section className="overflow-hidden rounded-sm border border-border bg-surface">
                  <div className="border-b border-border bg-bg px-4 py-3">
                    <h2 className="text-16 font-semibold text-ink">
                      Calendrier de prophylaxie réglementaire (Programme POUFA)
                    </h2>
                  </div>
                  <ul className="divide-y divide-border">
                    {prophylaxisSteps.map((step) => (
                      <li
                        key={step.id}
                        className="flex flex-wrap items-center justify-between gap-3 p-4"
                      >
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2 tabular-nums">
                            <span className="rounded-sm border border-border bg-bg px-2 py-0.5 text-14 font-semibold text-ink">
                              Jour {step.dayNumber} · {step.dateLabel}
                            </span>
                            <StatusBadge
                              status={step.completed ? 'ok' : 'vigilance'}
                              customLabel={step.completed ? 'Administré' : 'À préparer'}
                              compact
                            />
                          </div>
                          <p className="text-16 font-semibold text-ink">
                            {step.vaccineOrCare}
                          </p>
                          <p className="text-14 text-ink-muted tabular-nums">
                            Voie : {step.route} · Lot : {step.lotVaccin}
                            {step.completedAt ? ` · Validé le ${step.completedAt}` : ''}
                          </p>
                        </div>

                        <Button
                          variant={step.completed ? 'secondary' : 'primary'}
                          size="terrain"
                          icon={CalendarCheck}
                          onClick={() => onToggleProphylaxis(step.id)}
                        >
                          {step.completed ? 'Marqué fait' : 'Valider l’administration'}
                        </Button>
                      </li>
                    ))}
                  </ul>
                </section>
              </div>
            )}

            {/* ONGLET 4 : PLUS (Synchronisation, test hors-ligne, Fiche QR publique, Bascule Bureau) */}
            {activeTab === 'plus' && (
              <div className="flex flex-col gap-6">
                <section className="flex flex-col gap-4 rounded-sm border border-border bg-surface p-4">
                  <h1 className="text-20 font-semibold text-ink">
                    Synchronisation locale & Traçabilité du lot
                  </h1>

                  <div className="rounded-sm border border-border bg-bg p-3.5 text-14 tabular-nums">
                    <div className="flex items-center justify-between py-1">
                      <span className="text-ink-muted">Exploitation :</span>
                      <CodeCopyBadge code={farm.code} onCopied={onCopiedCode} />
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <span className="text-ink-muted">Bande en cours :</span>
                      <CodeCopyBadge code={farm.bandeActiveCode} onCopied={onCopiedCode} />
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <span className="text-ink-muted">Lot de traçabilité QR :</span>
                      <CodeCopyBadge code={farm.lotActifCode} onCopied={onCopiedCode} />
                    </div>
                    <div className="flex items-center justify-between py-1">
                      <span className="text-ink-muted">Enregistrements en attente :</span>
                      <strong className="font-semibold text-ink">
                        {formatInt(pendingSyncItems.length)} élément(s) dans IndexedDB
                      </strong>
                    </div>
                  </div>

                  {/* Action principale sur l'onglet Plus : Synchroniser maintenant */}
                  <Button
                    variant="primary"
                    size="terrain"
                    fullWidth
                    icon={RefreshCw}
                    onClick={onSyncNow}
                    disabled={!isOnline || pendingSyncItems.length === 0}
                  >
                    {pendingSyncItems.length > 0
                      ? `Envoyer les ${formatInt(pendingSyncItems.length)} relevé(s) en attente`
                      : 'Tout le carnet est synchronisé'}
                  </Button>

                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    <Button
                      variant="secondary"
                      size="terrain"
                      icon={isOnline ? WifiOff : Wifi}
                      onClick={onToggleOnline}
                    >
                      {isOnline
                        ? 'Simuler coupure réseau (Hors ligne)'
                        : 'Rétablir le réseau (En ligne)'}
                    </Button>

                    <Button
                      variant="secondary"
                      size="terrain"
                      icon={QrCode}
                      onClick={() => onOpenQrLot(farm.lotActifCode)}
                    >
                      Ouvrir la fiche publique QR
                    </Button>
                  </div>
                </section>

                <section className="flex flex-col gap-3 rounded-sm border border-border bg-surface p-4">
                  <h2 className="text-16 font-semibold text-ink">
                    Changement d’interface (Démonstration multi-rôles)
                  </h2>
                  <p className="text-14 text-ink-muted">
                    Passez au portail statistique officiel pour inspecter les 150 fermes, la carte nationale et le traitement vétérinaire des alertes.
                  </p>
                  <Button
                    variant="secondary"
                    size="terrain"
                    icon={FileSpreadsheet}
                    onClick={onSwitchToBureau}
                  >
                    Accéder au Portail Bureau (DGE / Vétérinaires / BCEG)
                  </Button>
                </section>
              </div>
            )}
          </>
        )}
      </main>

      {/* Navigation basse fixe à 4 entrées — libellés toujours visibles, icônes 24 px, cibles ≥ 48 px */}
      <nav
        aria-label="Navigation principale du carnet éleveur"
        className="fixed bottom-0 left-0 right-0 z-30 border-t border-border bg-surface"
      >
        <div className="mx-auto grid max-w-xl grid-cols-4">
          {[
            { id: 'aujourdhui' as const, label: "Aujourd'hui", icon: ClipboardList },
            { id: 'bande' as const, label: 'Bande', icon: FileSpreadsheet },
            { id: 'sante' as const, label: 'Santé', icon: HeartPulse },
            { id: 'plus' as const, label: 'Plus', icon: Settings },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id && !isWizardOpen;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setIsWizardOpen(false);
                  setActiveTab(item.id);
                }}
                aria-current={isActive ? 'page' : undefined}
                className={`relative flex min-h-[3.75rem] flex-col items-center justify-center gap-1 px-2 py-1.5 text-14 font-medium transition-colors duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-blue-50 text-blue-700 font-semibold'
                    : 'text-ink-muted hover:bg-bg hover:text-ink'
                }`}
              >
                {isActive && (
                  <span
                    className="absolute top-0 left-0 right-0 h-[3px] bg-green-700"
                    aria-hidden="true"
                  />
                )}
                <Icon size={24} strokeWidth={1.75} aria-hidden="true" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
