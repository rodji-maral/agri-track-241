import React, { useState } from 'react';
import { ArrowLeft, Printer, QrCode, Search } from 'lucide-react';
import { PUBLIC_QR_LOTS } from '../data/gabonSeedData';
import { Button } from '../components/ui/Button';
import { CodeCopyBadge } from '../components/ui/CodeCopyBadge';
import { StatusBadge } from '../components/ui/StatusBadge';
import { Timeline } from '../components/ui/Timeline';
import { formatDec2 } from '../utils/formatters';

export interface PublicQrViewProps {
  initialLotCode?: string;
  onNavigateBack: () => void;
  onCopiedCode?: (code: string) => void;
}

/**
 * Génère un motif QR vectoriel SVG déterministe 100 % local sans aucune bibliothèque ni script externe
 */
function DeterministicQrSvg({ code }: { code: string }) {
  const size = 11;
  const cells: boolean[][] = [];
  let seed = 0;
  for (let i = 0; i < code.length; i++) {
    seed = (seed * 31 + code.charCodeAt(i)) % 100000;
  }

  for (let r = 0; r < size; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < size; c++) {
      // Marqueurs de positionnement dans les 3 coins
      const inTopLeft = r < 3 && c < 3;
      const inTopRight = r < 3 && c >= size - 3;
      const inBottomLeft = r >= size - 3 && c < 3;
      if (inTopLeft || inTopRight || inBottomLeft) {
        row.push(true);
      } else {
        const val = (seed + r * 17 + c * 29 + r * c) % 3;
        row.push(val !== 0);
      }
    }
    cells.push(row);
  }

  return (
    <svg
      width={88}
      height={88}
      viewBox={`0 0 ${size} ${size}`}
      aria-label={`Code QR vectoriel du lot ${code}`}
      className="shrink-0 rounded-sm border border-border bg-surface p-1.5"
    >
      {cells.map((row, rIdx) =>
        row.map((filled, cIdx) =>
          filled ? (
            <rect
              key={`${rIdx}-${cIdx}`}
              x={cIdx}
              y={rIdx}
              width={0.92}
              height={0.92}
              fill="var(--color-ink)"
            />
          ) : null
        )
      )}
    </svg>
  );
}

export const PublicQrView: React.FC<PublicQrViewProps> = ({
  initialLotCode = 'EST-0014-B03-L01',
  onNavigateBack,
  onCopiedCode,
}) => {
  const [lotCode, setLotCode] = useState<string>(initialLotCode);
  const lotData = PUBLIC_QR_LOTS[lotCode] ?? null;
  const isRecognizedAndActive = Boolean(lotData && lotData.reconnu && !lotData.clos);

  return (
    <div className="min-h-screen bg-bg py-6 px-4 text-ink">
      {/* Barre d'outils hors-impression permettant de tester les états "Lot reconnu", "Lot clos" et "Lot inconnu" */}
      <div className="no-print mx-auto mb-4 flex max-w-xl flex-wrap items-center justify-between gap-2 rounded-sm border border-border bg-surface p-3">
        <Button
          variant="secondary"
          size="bureau"
          icon={ArrowLeft}
          onClick={onNavigateBack}
        >
          Retour à l’application
        </Button>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-14 font-medium text-ink-muted">Tester l’état du lot :</span>
          <button
            type="button"
            onClick={() => setLotCode('EST-0014-B03-L01')}
            className={`min-h-[2.25rem] rounded-sm border px-2.5 py-1 text-14 font-medium cursor-pointer tabular-nums ${
              lotCode === 'EST-0014-B03-L01'
                ? 'border-blue-700 bg-blue-50 text-blue-700 font-semibold'
                : 'border-border bg-bg text-ink hover:bg-surface'
            }`}
          >
            Lot reconnu (EST-0014-B03-L01)
          </button>
          <button
            type="button"
            onClick={() => setLotCode('EST-0002-B01-L01')}
            className={`min-h-[2.25rem] rounded-sm border px-2.5 py-1 text-14 font-medium cursor-pointer tabular-nums ${
              lotCode === 'EST-0002-B01-L01'
                ? 'border-blue-700 bg-blue-50 text-blue-700 font-semibold'
                : 'border-border bg-bg text-ink hover:bg-surface'
            }`}
          >
            Lot clos (EST-0002-B01-L01)
          </button>
          <button
            type="button"
            onClick={() => setLotCode('INC-9999-B01-L01')}
            className={`min-h-[2.25rem] rounded-sm border px-2.5 py-1 text-14 font-medium cursor-pointer tabular-nums ${
              lotCode === 'INC-9999-B01-L01'
                ? 'border-blue-700 bg-blue-50 text-blue-700 font-semibold'
                : 'border-border bg-bg text-ink hover:bg-surface'
            }`}
          >
            Lot inconnu
          </button>
        </div>

        <Button
          variant="primary"
          size="bureau"
          icon={Printer}
          onClick={() => window.print()}
        >
          Imprimer A5
        </Button>
      </div>

      {/* Feuille unique colonne imprimable au format A5 */}
      <main
        aria-label="Fiche publique de traçabilité QR"
        className="print-a5-sheet mx-auto max-w-xl overflow-hidden rounded-sm border border-border bg-surface"
      >
        {/* Filet tricolore de 3 px en tête */}
        <div className="tricolor-bar" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>

        <div className="flex flex-col gap-6 p-6">
          {/* En-tête officiel de la fiche */}
          <header className="flex items-start justify-between gap-4 border-b border-border pb-4">
            <div className="flex flex-col gap-1.5">
              <span className="text-14 font-semibold text-ink-muted">
                RÉPUBLIQUE GABONAISE · DIRECTION GÉNÉRALE DE L’ÉLEVAGE (DGE)
              </span>
              <h1 className="text-24 font-semibold text-ink">
                Fiche publique de traçabilité avicole
              </h1>
              <p className="text-14 text-ink-muted">
                Programme POUFA — Filière poulet de chair · Centre Gabonais de l’Innovation
              </p>
              <div className="mt-1 flex flex-wrap items-center gap-2">
                <CodeCopyBadge code={lotCode} onCopied={onCopiedCode} />
                {isRecognizedAndActive ? (
                  <StatusBadge status="ok" customLabel="Lot reconnu" />
                ) : (
                  <StatusBadge status="vigilance" customLabel="Lot inconnu ou clos" />
                )}
              </div>
            </div>

            <DeterministicQrSvg code={lotCode} />
          </header>

          {/* MENTION OBLIGATOIRE EN ENCADRÉ VISIBLE */}
          <div
            role="note"
            aria-label="Avertissement réglementaire"
            className="rounded-sm border-2 border-ink bg-bg px-4 py-3 text-16 font-semibold text-ink"
          >
            Ce QR code n'est pas un certificat sanitaire. Il atteste uniquement de l’enregistrement technico-économique et de l’origine déclarée du lot dans le système national AgriTrack 241 (Programme POUFA).
          </div>

          {/* Contenu selon l'état : "Lot reconnu" vs "Lot inconnu ou clos" */}
          {isRecognizedAndActive && lotData ? (
            <>
              {/* BLOC 1 : PRODUIT */}
              <section
                aria-labelledby="qr-bloc-produit"
                className="flex flex-col gap-3 rounded-sm border border-border bg-surface p-4"
              >
                <div className="flex items-center justify-between border-b border-border pb-2">
                  <h2 id="qr-bloc-produit" className="text-18 font-semibold text-ink">
                    1. Produit
                  </h2>
                  <span className="text-14 font-medium text-ink-muted tabular-nums">
                    Souche {lotData.produit.souche}
                  </span>
                </div>

                <dl className="divide-y divide-border text-14 tabular-nums">
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Désignation</dt>
                    <dd className="font-semibold text-ink text-right">
                      {lotData.produit.designation}
                    </dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Mode d’élevage</dt>
                    <dd className="font-medium text-ink text-right">
                      {lotData.produit.modeElevage}
                    </dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Calibre moyen du lot</dt>
                    <dd className="font-semibold text-ink">
                      {formatDec2(lotData.produit.calibreMoyenKg)}{' '}
                      <span className="font-regular text-ink-muted">kg</span>
                    </dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Conditionnement</dt>
                    <dd className="font-medium text-ink text-right">
                      {lotData.produit.conditionnement}
                    </dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Date de sortie / abattage</dt>
                    <dd className="font-semibold text-ink">
                      {lotData.produit.dateAbattageOuSortie}
                    </dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Date limite de consommation (à +4 °C)</dt>
                    <dd className="font-semibold text-ink">
                      {lotData.produit.dateLimiteConsommation}
                    </dd>
                  </div>
                </dl>
              </section>

              {/* BLOC 2 : ORIGINE (Aucune donnée personnelle de l'éleveur : uniquement codes et établissement) */}
              <section
                aria-labelledby="qr-bloc-origine"
                className="flex flex-col gap-3 rounded-sm border border-border bg-surface p-4"
              >
                <div className="flex items-center justify-between border-b border-border pb-2">
                  <h2 id="qr-bloc-origine" className="text-18 font-semibold text-ink">
                    2. Origine de l’élevage
                  </h2>
                  <span className="text-14 font-medium text-ink-muted">
                    Province : {lotData.origine.province}
                  </span>
                </div>

                <dl className="divide-y divide-border text-14 tabular-nums">
                  <div className="flex flex-wrap items-center justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Identifiant d’exploitation DGE</dt>
                    <dd>
                      <CodeCopyBadge
                        code={lotData.origine.codeFerme}
                        compact
                        onCopied={onCopiedCode}
                      />
                    </dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Unité de production</dt>
                    <dd className="font-semibold text-ink">{lotData.origine.nomFerme}</dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Localité & Province</dt>
                    <dd className="font-medium text-ink">
                      {lotData.origine.localite} ({lotData.origine.province})
                    </dd>
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Code bande d’élevage</dt>
                    <dd>
                      <CodeCopyBadge
                        code={lotData.origine.codeBande}
                        compact
                        onCopied={onCopiedCode}
                      />
                    </dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Couvoir de naissance</dt>
                    <dd className="font-medium text-ink text-right">
                      {lotData.origine.couvoirOrigine}
                    </dd>
                  </div>
                  <div className="flex flex-wrap justify-between gap-2 py-2">
                    <dt className="text-ink-muted">Alimentation / Provenderie</dt>
                    <dd className="font-medium text-ink text-right">
                      {lotData.origine.provenderie}
                    </dd>
                  </div>
                </dl>
              </section>

              {/* BLOC 3 : PARCOURS (Frise chronologique) */}
              <section
                aria-labelledby="qr-bloc-parcours"
                className="flex flex-col gap-3 rounded-sm border border-border bg-surface p-4"
              >
                <div className="border-b border-border pb-2">
                  <h2 id="qr-bloc-parcours" className="text-18 font-semibold text-ink">
                    3. Parcours de traçabilité du lot
                  </h2>
                </div>

                <Timeline
                  orientation="vertical"
                  items={lotData.parcours.map((step, idx) => ({
                    id: `qr-step-${idx}`,
                    title: step.etape,
                    date: step.date,
                    subtitle: step.lieu,
                    description: step.detail,
                    status: step.statut,
                  }))}
                />
              </section>
            </>
          ) : (
            /* État "Lot inconnu ou clos" */
            <section className="flex flex-col gap-4 rounded-sm border border-orange-600 bg-orange-50 p-5">
              <div className="flex items-start gap-3">
                <QrCode
                  size={24}
                  strokeWidth={1.75}
                  className="mt-0.5 text-orange-600 shrink-0"
                  aria-hidden="true"
                />
                <div className="flex flex-col gap-1.5">
                  <h2 className="text-20 font-semibold text-ink">
                    Lot inconnu ou clos ({lotCode})
                  </h2>
                  <p className="text-14 text-ink">
                    {lotData?.clos
                      ? `Le lot ${lotCode} correspond à une bande clôturée le ${lotData.produit.dateAbattageOuSortie} dont la période de commercialisation est échue.`
                      : `Aucun lot actif ne correspond au code « ${lotCode} » dans la base nationale AgriTrack 241.`}
                  </p>
                  <p className="text-14 text-ink-muted">
                    Pour toute vérification en point de vente, demandez le bordereau d’inspection vétérinaire délivré par la brigade provinciale de la Direction Générale de l’Élevage (DGE).
                  </p>
                </div>
              </div>

              <div className="no-print pt-1">
                <Button
                  variant="secondary"
                  size="bureau"
                  icon={Search}
                  onClick={() => setLotCode('EST-0014-B03-L01')}
                >
                  Consulter le lot actif de référence EST-0014-B03-L01
                </Button>
              </div>
            </section>
          )}

          {/* Pied de page obligatoire avec la date de génération et mention confidentialité */}
          <footer className="border-t border-border pt-4 text-14 text-ink-muted tabular-nums">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span>
                Date de génération de la fiche : <strong className="font-semibold text-ink">6 nov. 2026 à 07:45</strong> (Africa/Libreville)
              </span>
              <span>Format officiel A5 · Sans donnée personnelle</span>
            </div>
            <p className="mt-1">
              Source : Registre national AgriTrack 241 · Programme POUFA · Direction Générale de l’Élevage (DGE) & Centre Gabonais de l’Innovation (CGI).
            </p>
          </footer>
        </div>
      </main>
    </div>
  );
};
