import React, { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  BarChart3,
  Building2,
  Check,
  Eye,
  FileSpreadsheet,
  Lock,
  MapPin,
  Palette,
  QrCode,
  RefreshCw,
  Search,
  ShieldAlert,
  Smartphone,
  UserCheck,
  XCircle,
} from 'lucide-react';
import type {
  AlertWorkflowStatus,
  FarmRecord,
  ProvinceGabon,
  SanitaryAlert,
  SyncQueueItem,
  UserRole,
} from '../types/domain';
import {
  COHORT_PERFORMANCE_SERIES,
  GROWTH_CURVE_ROSS308,
  PROVINCES_GABON,
  PROVINCE_STATS_SUMMARY,
} from '../data/gabonSeedData';
import { Button } from '../components/ui/Button';
import { StatCard } from '../components/ui/StatCard';
import { StatusBadge } from '../components/ui/StatusBadge';
import { CodeCopyBadge } from '../components/ui/CodeCopyBadge';
import { DataTable, type DataTableColumn } from '../components/ui/DataTable';
import { Timeline, type TimelineItem } from '../components/ui/Timeline';
import { Drawer } from '../components/ui/Drawer';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { SyncStatusBar } from '../components/ui/SyncStatusBar';
import { EmptyState } from '../components/ui/EmptyState';
import { GabonFarmsMap } from '../components/map/GabonFarmsMap';
import {
  formatDec1,
  formatDec2,
  formatFcfa,
  formatInt,
} from '../utils/formatters';

export type BureauSection = 'dashboard' | 'repertoire' | 'carte' | 'alertes';

export interface BureauViewProps {
  activeRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  farms: FarmRecord[];
  alerts: SanitaryAlert[];
  onUpdateAlertStatus: (
    alertId: string,
    nextStatus: AlertWorkflowStatus,
    diagnosticNote: string
  ) => void;
  isOnline: boolean;
  pendingSyncItems: SyncQueueItem[];
  lastSyncedAt: string;
  onOpenSyncDrawer: () => void;
  onSwitchToEleveur: () => void;
  onOpenQrLot: (codeLot: string) => void;
  onOpenDesignSystem: () => void;
  onCopiedCode?: (code: string) => void;
}

const ROLE_LABELS: Record<UserRole, string> = {
  ELEVEUR: 'Éleveur (Carnet terrain)',
  DGE: 'Agent DGE (Direction Générale de l’Élevage)',
  VETERINAIRE: 'Vétérinaire inspecteur (Brigade sanitaire)',
  BCEG: 'Analyste BCEG (Financement & coûts)',
  ADMIN: 'Administrateur CGI (Centre Gabonais de l’Innovation)',
};

export const BureauView: React.FC<BureauViewProps> = ({
  activeRole,
  onChangeRole,
  farms,
  alerts,
  onUpdateAlertStatus,
  isOnline,
  pendingSyncItems,
  lastSyncedAt,
  onOpenSyncDrawer,
  onSwitchToEleveur,
  onOpenQrLot,
  onOpenDesignSystem,
  onCopiedCode,
}) => {
  const [section, setSection] = useState<BureauSection>('dashboard');

  // Filtres globaux de l'en-tête
  const [provinceFilter, setProvinceFilter] = useState<string>('ALL');
  const [cohorteFilter, setCohorteFilter] = useState<string>('ALL');
  const [statutFilter, setStatutFilter] = useState<string>('ALL');
  const [periodeFilter, setPeriodeFilter] = useState<string>('2026-T4');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [simulateLoading, setSimulateLoading] = useState<boolean>(false);

  // Fiche ferme dans le Drawer latéral
  const [selectedFarm, setSelectedFarm] = useState<FarmRecord | null>(null);

  // Alerte sélectionnée dans la vue Alertes
  const [selectedAlertId, setSelectedAlertId] = useState<string>(
    alerts[0]?.id ?? 'ALR-2026-089'
  );
  const [vetNoteInput, setVetNoteInput] = useState<string>('');
  const [pendingVetDecision, setPendingVetDecision] = useState<{
    alert: SanitaryAlert;
    nextStatus: AlertWorkflowStatus;
  } | null>(null);

  // Filtrage global des 150 fermes
  const filteredFarms = useMemo(() => {
    return farms.filter((f) => {
      if (provinceFilter !== 'ALL' && f.province !== provinceFilter) return false;
      if (cohorteFilter !== 'ALL' && f.cohorte !== cohorteFilter) return false;
      if (statutFilter !== 'ALL' && f.statut !== statutFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const match =
          f.code.toLowerCase().includes(q) ||
          f.nom.toLowerCase().includes(q) ||
          f.localite.toLowerCase().includes(q) ||
          f.responsable.toLowerCase().includes(q) ||
          f.bandeActiveCode.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [farms, provinceFilter, cohorteFilter, statutFilter, searchQuery]);

  // Filtrage des alertes selon province globale
  const filteredAlerts = useMemo(() => {
    return alerts.filter((a) => {
      if (provinceFilter !== 'ALL' && a.province !== provinceFilter) return false;
      return true;
    });
  }, [alerts, provinceFilter]);

  const activeAlert = useMemo(() => {
    return (
      filteredAlerts.find((a) => a.id === selectedAlertId) ??
      filteredAlerts[0] ??
      null
    );
  }, [filteredAlerts, selectedAlertId]);

  // Calcul des 5 indicateurs nationaux dynamiques selon les filtres actifs
  const kpiStats = useMemo(() => {
    const count = filteredFarms.length;
    if (count === 0) {
      return {
        effectifTotal: 0,
        mortaliteMoy: 0,
        poidsMoyen: 0,
        icMoyen: 0,
        coutMoyen: 0,
        alertCount: 0,
      };
    }
    const effectifTotal = filteredFarms.reduce((s, f) => s + f.effectifPresent, 0);
    const mortaliteMoy =
      filteredFarms.reduce((s, f) => s + f.mortaliteCumuleePct, 0) / count;
    const poidsMoyen =
      filteredFarms.reduce((s, f) => s + f.poidsMoyenG, 0) / count;
    const icMoyen =
      filteredFarms.reduce((s, f) => s + f.indiceConsommation, 0) / count;
    const coutMoyen =
      filteredFarms.reduce((s, f) => s + f.coutProductionFcfaKg, 0) / count;
    const alertCount = filteredFarms.filter((f) => f.statut === 'alerte').length;

    return {
      effectifTotal,
      mortaliteMoy,
      poidsMoyen,
      icMoyen,
      coutMoyen,
      alertCount,
    };
  }, [filteredFarms]);

  // Données pour le graphique 4 : Répartition par statut sanitaire (max 4 parts)
  const statusDistributionData = useMemo(() => {
    return [
      {
        statut: 'Normal',
        fermes: filteredFarms.filter((f) => f.statut === 'ok').length,
        color: 'var(--color-green-700)',
      },
      {
        statut: 'À surveiller',
        fermes: filteredFarms.filter((f) => f.statut === 'vigilance').length,
        color: 'var(--color-orange-600)',
      },
      {
        statut: 'Alerte',
        fermes: filteredFarms.filter((f) => f.statut === 'alerte').length,
        color: 'var(--color-red-700)',
      },
      {
        statut: 'Non renseigné',
        fermes: filteredFarms.filter((f) => f.statut === 'none').length,
        color: 'var(--color-ink-muted)',
      },
    ];
  }, [filteredFarms]);

  // Colonnes du tableau des 150 exploitations
  const farmColumns: DataTableColumn<FarmRecord>[] = useMemo(
    () => [
      {
        key: 'nom',
        header: 'Exploitation & Responsable',
        sortable: true,
        sortAccessor: (r) => r.nom,
        csvAccessor: (r) => `${r.nom} (${r.responsable})`,
        render: (r) => (
          <div className="flex flex-col">
            <span className="font-semibold text-ink">{r.nom}</span>
            <span className="text-14 text-ink-muted">{r.responsable}</span>
          </div>
        ),
      },
      {
        key: 'province',
        header: 'Province & Localité',
        sortable: true,
        sortAccessor: (r) => r.province,
        csvAccessor: (r) => `${r.province} - ${r.localite}`,
        render: (r) => (
          <span className="text-ink">
            {r.province} <span className="text-ink-muted">· {r.localite}</span>
          </span>
        ),
      },
      {
        key: 'bandeActiveCode',
        header: 'Bande active',
        sortable: true,
        sortAccessor: (r) => r.bandeActiveCode,
        csvAccessor: (r) => r.bandeActiveCode,
        render: (r) => (
          <span className="font-mono text-14 font-medium text-ink tabular-nums">
            {r.bandeActiveCode} (J{r.jourBande})
          </span>
        ),
      },
      {
        key: 'effectifPresent',
        header: 'Effectif présent',
        unit: 'sujets',
        align: 'right',
        sortable: true,
        sortAccessor: (r) => r.effectifPresent,
        csvAccessor: (r) => r.effectifPresent,
        render: (r) => formatInt(r.effectifPresent),
      },
      {
        key: 'mortaliteCumuleePct',
        header: 'Mortalité cumulée',
        unit: '%',
        align: 'right',
        sortable: true,
        sortAccessor: (r) => r.mortaliteCumuleePct,
        csvAccessor: (r) => r.mortaliteCumuleePct,
        render: (r) => (
          <span
            className={
              r.mortaliteCumuleePct >= 5
                ? 'font-semibold text-red-700'
                : r.mortaliteCumuleePct >= 4
                ? 'font-semibold text-orange-600'
                : 'text-ink'
            }
          >
            {formatDec1(r.mortaliteCumuleePct)}
          </span>
        ),
      },
      {
        key: 'poidsMoyenG',
        header: 'Poids vif moyen',
        unit: 'g',
        align: 'right',
        sortable: true,
        sortAccessor: (r) => r.poidsMoyenG,
        csvAccessor: (r) => r.poidsMoyenG,
        render: (r) => formatInt(r.poidsMoyenG),
      },
      {
        key: 'indiceConsommation',
        header: 'Indice conso.',
        unit: 'IC',
        align: 'right',
        sortable: true,
        sortAccessor: (r) => r.indiceConsommation,
        csvAccessor: (r) => r.indiceConsommation,
        render: (r) => formatDec2(r.indiceConsommation),
      },
      {
        key: 'coutProductionFcfaKg',
        header: 'Coût revient',
        unit: 'FCFA/kg',
        align: 'right',
        sortable: true,
        sortAccessor: (r) => r.coutProductionFcfaKg,
        csvAccessor: (r) => r.coutProductionFcfaKg,
        render: (r) => formatInt(r.coutProductionFcfaKg),
      },
      {
        key: 'derniereMaj',
        header: 'Dernière mise à jour',
        sortable: true,
        sortAccessor: (r) => r.derniereMaj,
        csvAccessor: (r) => r.derniereMaj,
        render: (r) => <span className="text-ink-muted">{r.derniereMaj}</span>,
      },
    ],
    []
  );

  const resetGlobalFilters = () => {
    setProvinceFilter('ALL');
    setCohorteFilter('ALL');
    setStatutFilter('ALL');
    setSearchQuery('');
  };

  // Construction de la frise horizontale des 4 étapes d'une alerte sanitaire
  const buildAlertHorizontalTimeline = (alert: SanitaryAlert): TimelineItem[] => {
    const s = alert.statutWorkflow;
    const findDate = (etape: AlertWorkflowStatus) =>
      alert.historique.find((h) => h.etape === etape)?.date;

    return [
      {
        id: 'step-nouvelle',
        title: 'Nouvelle',
        date: findDate('Nouvelle') ?? alert.dateDeclaration,
        subtitle: `Ferme ${alert.fermeCode}`,
        status: 'alerte',
        active: s === 'Nouvelle',
        completed: s !== 'Nouvelle',
      },
      {
        id: 'step-analyse',
        title: 'En analyse',
        date: findDate('En analyse'),
        subtitle: alert.veterinaireAssigne.split(' (')[0],
        status: s === 'Nouvelle' ? 'none' : 'vigilance',
        active: s === 'En analyse',
        completed: s === 'Confirmée' || s === 'Infirmée' || s === 'Close',
      },
      {
        id: 'step-qualification',
        title:
          s === 'Infirmée'
            ? 'Infirmée'
            : s === 'Confirmée'
            ? 'Confirmée'
            : 'Confirmée / Infirmée',
        date: findDate('Confirmée') ?? findDate('Infirmée'),
        status:
          s === 'Confirmée'
            ? 'alerte'
            : s === 'Infirmée'
            ? 'ok'
            : s === 'Close'
            ? 'ok'
            : 'none',
        active: s === 'Confirmée' || s === 'Infirmée',
        completed: s === 'Close',
      },
      {
        id: 'step-close',
        title: 'Close',
        date: findDate('Close'),
        status: s === 'Close' ? 'ok' : 'none',
        active: s === 'Close',
        completed: s === 'Close',
      },
    ];
  };

  return (
    <div className="min-h-screen bg-bg text-ink">
      {/* Signature discrète : filet tricolore de 3 px tout en haut */}
      <div className="tricolor-bar sticky top-0 z-40" aria-hidden="true">
        <span />
        <span />
        <span />
      </div>

      <div className="flex min-h-[calc(100vh-3px)]">
        {/* Barre latérale fixe 240 px (sections regroupées, état actif par filet vert à gauche et fond bleu 50) */}
        <aside
          aria-label="Navigation principale du portail statistique"
          className="w-[240px] shrink-0 border-r border-border bg-surface flex flex-col justify-between"
        >
          <div className="flex flex-col gap-6 py-4">
            {/* Identité institutionnelle */}
            <div className="border-b border-border px-4 pb-4">
              <div className="flex items-center justify-between">
                <span className="text-18 font-semibold text-ink tracking-tight">
                  AgriTrack 241
                </span>
                <span className="rounded-sm border border-border bg-bg px-1.5 py-0.5 font-mono text-14 font-semibold text-ink tabular-nums">
                  POUFA
                </span>
              </div>
              <p className="mt-1 text-14 text-ink-muted">
                Portail statistique national · DGE & CGI Gabon
              </p>
            </div>

            {/* Groupe 1 : Pilotage & Statistiques */}
            <div className="flex flex-col gap-1">
              <span className="px-4 pb-1 text-14 font-semibold text-ink-muted">
                Pilotage national
              </span>
              {[
                {
                  id: 'dashboard' as const,
                  label: 'Tableau de bord',
                  icon: BarChart3,
                },
                {
                  id: 'repertoire' as const,
                  label: 'Répertoire (150 fermes)',
                  icon: Building2,
                },
              ].map((item) => {
                const Icon = item.icon;
                const active = section === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSection(item.id)}
                    aria-current={active ? 'page' : undefined}
                    className={`relative flex min-h-[2.75rem] w-full items-center gap-3 px-4 py-2 text-left text-14 transition-colors duration-150 cursor-pointer ${
                      active
                        ? 'bg-blue-50 font-semibold text-blue-700'
                        : 'font-medium text-ink hover:bg-bg'
                    }`}
                  >
                    {active && (
                      <span
                        className="absolute left-0 top-0 bottom-0 w-[3px] bg-green-700"
                        aria-hidden="true"
                      />
                    )}
                    <Icon size={24} strokeWidth={1.75} aria-hidden="true" className="shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Groupe 2 : Surveillance sanitaire */}
            <div className="flex flex-col gap-1">
              <span className="px-4 pb-1 text-14 font-semibold text-ink-muted">
                Surveillance & terrain
              </span>
              {[
                {
                  id: 'carte' as const,
                  label: 'Carte sanitaire Gabon',
                  icon: MapPin,
                },
                {
                  id: 'alertes' as const,
                  label: `Alertes sanitaires (${alerts.filter((a) => a.statutWorkflow !== 'Close').length})`,
                  icon: ShieldAlert,
                },
              ].map((item) => {
                const Icon = item.icon;
                const active = section === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSection(item.id)}
                    aria-current={active ? 'page' : undefined}
                    className={`relative flex min-h-[2.75rem] w-full items-center gap-3 px-4 py-2 text-left text-14 transition-colors duration-150 cursor-pointer ${
                      active
                        ? 'bg-blue-50 font-semibold text-blue-700'
                        : 'font-medium text-ink hover:bg-bg'
                    }`}
                  >
                    {active && (
                      <span
                        className="absolute left-0 top-0 bottom-0 w-[3px] bg-green-700"
                        aria-hidden="true"
                      />
                    )}
                    <Icon size={24} strokeWidth={1.75} aria-hidden="true" className="shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Groupe 3 : Bascule Éleveur / QR Public / Design System */}
            <div className="flex flex-col gap-1 border-t border-border pt-4">
              <span className="px-4 pb-1 text-14 font-semibold text-ink-muted">
                Interfaces & Référentiel
              </span>
              <button
                type="button"
                onClick={onSwitchToEleveur}
                className="flex min-h-[2.75rem] w-full items-center gap-3 px-4 py-2 text-left text-14 font-medium text-ink hover:bg-green-50 cursor-pointer"
              >
                <Smartphone size={24} strokeWidth={1.75} className="text-green-700 shrink-0" aria-hidden="true" />
                <span>Carnet Éleveur (EST-0014)</span>
              </button>
              <button
                type="button"
                onClick={() => onOpenQrLot('EST-0014-B03-L01')}
                className="flex min-h-[2.75rem] w-full items-center gap-3 px-4 py-2 text-left text-14 font-medium text-ink hover:bg-bg cursor-pointer"
              >
                <QrCode size={24} strokeWidth={1.75} className="text-blue-700 shrink-0" aria-hidden="true" />
                <span>Page publique QR (A5)</span>
              </button>
              <button
                type="button"
                onClick={onOpenDesignSystem}
                className="flex min-h-[2.75rem] w-full items-center gap-3 px-4 py-2 text-left text-14 font-medium text-ink hover:bg-bg cursor-pointer"
              >
                <Palette size={24} strokeWidth={1.75} className="text-ink-muted shrink-0" aria-hidden="true" />
                <span>Référentiel /design (Lot A)</span>
              </button>
            </div>
          </div>

          {/* Pied de barre latérale : fuseau et version */}
          <div className="border-t border-border bg-bg p-4 text-14 text-ink-muted tabular-nums">
            <p className="font-semibold text-ink">Fuseau : Africa/Libreville</p>
            <p>Arrêté statistique : 6 nov. 2026</p>
          </div>
        </aside>

        {/* Colonne principale : En-tête compact avec filtres globaux + Contenu 12 colonnes max 1440 px */}
        <div className="flex flex-1 flex-col min-w-0">
          {/* En-tête compact avec filtres globaux visibles (Province, Cohorte, Statut, Période) + Rôle actif */}
          <header className="sticky top-[3px] z-20 border-b border-border bg-surface px-6 py-3">
            <div className="mx-auto flex max-w-[1440px] flex-col gap-3">
              {/* Ligne supérieure de l'en-tête : Rôle actif & Synchronisation */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-2.5">
                <div className="flex flex-wrap items-center gap-2">
                  <label
                    htmlFor="select-role-bureau"
                    className="inline-flex items-center gap-1.5 text-14 font-semibold text-ink"
                  >
                    <UserCheck size={16} strokeWidth={1.75} className="text-green-700" aria-hidden="true" />
                    <span>Profil d’habilitation actif :</span>
                  </label>
                  <select
                    id="select-role-bureau"
                    value={activeRole}
                    onChange={(e) => onChangeRole(e.target.value as UserRole)}
                    className="min-h-[2.25rem] rounded-sm border border-border bg-bg px-2.5 py-1 text-14 font-semibold text-ink"
                  >
                    <option value="DGE">{ROLE_LABELS.DGE}</option>
                    <option value="VETERINAIRE">{ROLE_LABELS.VETERINAIRE}</option>
                    <option value="BCEG">{ROLE_LABELS.BCEG}</option>
                    <option value="ADMIN">{ROLE_LABELS.ADMIN}</option>
                  </select>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <SyncStatusBar
                    isOnline={isOnline}
                    pendingCount={pendingSyncItems.length}
                    lastSyncedAt={lastSyncedAt}
                    onClick={onOpenSyncDrawer}
                  />
                </div>
              </div>

              {/* Ligne des 4 filtres globaux obligatoires : Province, Cohorte, Statut, Période */}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5 items-end">
                <div className="flex flex-col gap-1">
                  <label htmlFor="filter-province" className="text-14 font-medium text-ink-muted">
                    Province (9 provinces)
                  </label>
                  <select
                    id="filter-province"
                    value={provinceFilter}
                    onChange={(e) => setProvinceFilter(e.target.value)}
                    className="min-h-[2.5rem] rounded-sm border border-border bg-surface px-3 py-1.5 text-14 font-medium text-ink tabular-nums"
                  >
                    <option value="ALL">Toutes les provinces (150 fermes)</option>
                    {PROVINCES_GABON.map((p: ProvinceGabon) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <label htmlFor="filter-cohorte" className="text-14 font-medium text-ink-muted">
                    Cohorte programme POUFA
                  </label>
                  <select
                    id="filter-cohorte"
                    value={cohorteFilter}
                    onChange={(e) => setCohorteFilter(e.target.value)}
                    className="min-h-[2.5rem] rounded-sm border border-border bg-surface px-3 py-1.5 text-14 font-medium text-ink tabular-nums"
                  >
                    <option value="ALL">Toutes les cohortes</option>
                    <option value="POUFA-2026-T4">Cohorte POUFA-2026-T4 (en cours)</option>
                    <option value="POUFA-2026-T3">Cohorte POUFA-2026-T3</option>
                    <option value="POUFA-2025-T4">Cohorte POUFA-2025-T4</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <label htmlFor="filter-statut" className="text-14 font-medium text-ink-muted">
                    Statut sanitaire
                  </label>
                  <select
                    id="filter-statut"
                    value={statutFilter}
                    onChange={(e) => setStatutFilter(e.target.value)}
                    className="min-h-[2.5rem] rounded-sm border border-border bg-surface px-3 py-1.5 text-14 font-medium text-ink"
                  >
                    <option value="ALL">Tous les statuts</option>
                    <option value="ok">Normal (disque vert)</option>
                    <option value="vigilance">À surveiller (triangle orange)</option>
                    <option value="alerte">Alerte (octogone rouge)</option>
                    <option value="none">Non renseigné (tiret)</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <label htmlFor="filter-periode" className="text-14 font-medium text-ink-muted">
                    Période d’observation
                  </label>
                  <select
                    id="filter-periode"
                    value={periodeFilter}
                    onChange={(e) => setPeriodeFilter(e.target.value)}
                    className="min-h-[2.5rem] rounded-sm border border-border bg-surface px-3 py-1.5 text-14 font-medium text-ink tabular-nums"
                  >
                    <option value="2026-T4">1 oct. – 6 nov. 2026 (T4)</option>
                    <option value="2026-T3">1 juil. – 30 sept. 2026 (T3)</option>
                    <option value="2026-ANNUEL">Cumul annuel 2026</option>
                  </select>
                </div>

                <div className="flex items-center justify-end gap-2">
                  <Button
                    variant="secondary"
                    size="bureau"
                    icon={RefreshCw}
                    onClick={resetGlobalFilters}
                  >
                    Réinitialiser ({formatInt(filteredFarms.length)}/150)
                  </Button>
                </div>
              </div>
            </div>
          </header>

          {/* Contenu principal en 12 colonnes, largeur max 1440 px */}
          <main className="mx-auto w-full max-w-[1440px] px-6 py-6">
            <div className="grid grid-cols-12 gap-6">
              {/* SECTION 1 : TABLEAU DE BORD NATIONAL */}
              {section === 'dashboard' && (
                <>
                  {/* En-tête de section */}
                  <div className="col-span-12 flex flex-wrap items-baseline justify-between gap-2">
                    <div>
                      <h1 className="text-24 font-semibold text-ink">
                        Suivi technico-économique national — Filière poulet de chair
                      </h1>
                      <p className="text-14 text-ink-muted tabular-nums">
                        Périmètre actif : {formatInt(filteredFarms.length)} exploitation(s) · Période : {periodeFilter} · Source : Direction Générale de l’Élevage (DGE) & BCEG
                      </p>
                    </div>
                    <Button
                      variant="primary"
                      size="bureau"
                      icon={FileSpreadsheet}
                      onClick={() => setSection('repertoire')}
                    >
                      Consulter le répertoire des {formatInt(filteredFarms.length)} fermes
                    </Button>
                  </div>

                  {/* Bandeau de 5 indicateurs (valeur + unité + variation + période + date maj) */}
                  <div className="col-span-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
                    <StatCard
                      label="Effectif actif en bande"
                      value={formatInt(kpiStats.effectifTotal)}
                      unit="sujets"
                      variation="+6,4 % vs T3 2026"
                      period={`${formatInt(filteredFarms.length)} bandes`}
                      updatedAt="6 nov. 2026 à 07:40"
                      status="ok"
                    />
                    <StatCard
                      label="Mortalité moyenne"
                      value={formatDec1(kpiStats.mortaliteMoy)}
                      unit="%"
                      variation="-0,3 pt vs cible 3,5 %"
                      period="Période T4 2026"
                      updatedAt="6 nov. 2026 à 07:40"
                      status={
                        kpiStats.mortaliteMoy >= 4.5
                          ? 'alerte'
                          : kpiStats.mortaliteMoy >= 3.5
                          ? 'vigilance'
                          : 'ok'
                      }
                    />
                    <StatCard
                      label="Poids vif moyen (lot actif)"
                      value={formatInt(kpiStats.poidsMoyen)}
                      unit="g"
                      variation="+18 g vs réf. Ross 308"
                      period="Moyenne inter-fermes"
                      updatedAt="6 nov. 2026 à 07:40"
                      status="ok"
                    />
                    <StatCard
                      label="Indice de consommation (IC)"
                      value={formatDec2(kpiStats.icMoyen)}
                      unit="kg/kg"
                      variation="-0,04 pt vs 2026-T3"
                      period="Cible POUFA ≤ 1,65"
                      updatedAt="6 nov. 2026 à 07:40"
                      status={kpiStats.icMoyen <= 1.65 ? 'ok' : 'vigilance'}
                    />
                    <StatCard
                      label="Coût de revient vif"
                      value={formatInt(kpiStats.coutMoyen)}
                      unit="FCFA / kg"
                      variation="-25 FCFA vs 2026-T3"
                      period="Observatoire BCEG"
                      updatedAt="6 nov. 2026 à 07:40"
                      status={kpiStats.alertCount > 0 ? 'vigilance' : 'ok'}
                    />
                  </div>

                  {/* Rangée 1 de graphiques (2 graphiques max par rangée : 6 col + 6 col) */}
                  <section className="col-span-12 lg:col-span-6 flex flex-col justify-between rounded-sm border border-border bg-surface p-4">
                    <div className="mb-3">
                      <h2 className="text-18 font-semibold text-ink">
                        Mortalité moyenne par province, en %
                      </h2>
                      <p className="text-14 text-ink-muted">
                        Comparaison au seuil de vigilance sanitaire national fixé à 4,0 %
                      </p>
                    </div>

                    <div className="h-72 w-full tabular-nums">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={PROVINCE_STATS_SUMMARY}
                          margin={{ top: 12, right: 16, left: 0, bottom: 24 }}
                        >
                          <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" vertical={false} />
                          <XAxis
                            dataKey="province"
                            tick={{ fill: 'var(--color-ink)', fontSize: 12 }}
                            angle={-20}
                            textAnchor="end"
                            height={48}
                          />
                          <YAxis
                            unit=" %"
                            domain={[0, 5]}
                            tick={{ fill: 'var(--color-ink-muted)', fontSize: 12 }}
                          />
                          <Tooltip
                            formatter={(val) => [`${formatDec1(Number(val ?? 0))} %`, 'Mortalité moyenne']}
                            contentStyle={{
                              backgroundColor: 'var(--color-surface)',
                              borderColor: 'var(--color-border)',
                              borderRadius: '4px',
                              fontSize: '14px',
                            }}
                          />
                          <ReferenceLine
                            y={4.0}
                            stroke="var(--color-orange-600)"
                            strokeDasharray="4 4"
                            label={{
                              value: 'Seuil vigilance 4,0 %',
                              position: 'insideTopRight',
                              fill: 'var(--color-orange-600)',
                              fontSize: 12,
                            }}
                          />
                          <Bar
                            dataKey="mortaliteMoyPct"
                            name="Mortalité moyenne (%)"
                            fill="var(--color-green-700)"
                            radius={[2, 2, 0, 0]}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <footer className="mt-2 border-t border-border pt-2 text-14 text-ink-muted tabular-nums">
                      Source : Direction Générale de l’Élevage (DGE) · Période : 1 oct. – 6 nov. 2026 (150 fermes POUFA)
                    </footer>
                  </section>

                  <section className="col-span-12 lg:col-span-6 flex flex-col justify-between rounded-sm border border-border bg-surface p-4">
                    <div className="mb-3">
                      <h2 className="text-18 font-semibold text-ink">
                        Évolution du poids vif moyen face au standard Ross 308, en g
                      </h2>
                      <p className="text-14 text-ink-muted">
                        Pesées hebdomadaires J7 à J42 (échantillon réglementaire de 100 sujets par bande)
                      </p>
                    </div>

                    <div className="h-72 w-full tabular-nums">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={GROWTH_CURVE_ROSS308}
                          margin={{ top: 12, right: 16, left: 8, bottom: 12 }}
                        >
                          <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" />
                          <XAxis
                            dataKey="jour"
                            tick={{ fill: 'var(--color-ink)', fontSize: 12 }}
                          />
                          <YAxis
                            unit=" g"
                            tick={{ fill: 'var(--color-ink-muted)', fontSize: 12 }}
                          />
                          <Tooltip
                            formatter={(val, name) => [
                              `${formatInt(Number(val ?? 0))} g`,
                              String(name ?? ''),
                            ]}
                            contentStyle={{
                              backgroundColor: 'var(--color-surface)',
                              borderColor: 'var(--color-border)',
                              borderRadius: '4px',
                              fontSize: '14px',
                            }}
                          />
                          <Legend wrapperStyle={{ fontSize: '13px' }} />
                          <Line
                            type="monotone"
                            dataKey="cibleRoss308G"
                            name="Standard cible Ross 308 (g)"
                            stroke="var(--color-blue-700)"
                            strokeWidth={2}
                            dot={{ r: 4 }}
                          />
                          <Line
                            type="monotone"
                            dataKey="moyenneNationaleG"
                            name="Moyenne nationale POUFA (g)"
                            stroke="var(--color-green-700)"
                            strokeWidth={2}
                            dot={{ r: 4 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>

                    <footer className="mt-2 border-t border-border pt-2 text-14 text-ink-muted tabular-nums">
                      Source : Réseau technico-économique DGE / CGI · Période : Cohortes 2026-T3 & 2026-T4 · Mis à jour le 6 nov. 2026
                    </footer>
                  </section>

                  {/* Rangée 2 de graphiques (2 graphiques max par rangée : 6 col + 6 col) */}
                  <section className="col-span-12 lg:col-span-6 flex flex-col justify-between rounded-sm border border-border bg-surface p-4">
                    <div className="mb-3">
                      <h2 className="text-18 font-semibold text-ink">
                        Indice de consommation (IC) moyen par cohorte trimestrielle, en kg/kg
                      </h2>
                      <p className="text-14 text-ink-muted">
                        Quantité d’aliment (kg) consommée par kilogramme de poids vif produit
                      </p>
                    </div>

                    <div className="h-64 w-full tabular-nums">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={COHORT_PERFORMANCE_SERIES}
                          margin={{ top: 12, right: 16, left: 0, bottom: 12 }}
                        >
                          <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" vertical={false} />
                          <XAxis
                            dataKey="cohorte"
                            tick={{ fill: 'var(--color-ink)', fontSize: 12 }}
                          />
                          <YAxis
                            domain={[1.3, 1.85]}
                            tick={{ fill: 'var(--color-ink-muted)', fontSize: 12 }}
                          />
                          <Tooltip
                            formatter={(val) => [`${formatDec2(Number(val ?? 0))} kg/kg`, 'Indice IC']}
                            contentStyle={{
                              backgroundColor: 'var(--color-surface)',
                              borderColor: 'var(--color-border)',
                              borderRadius: '4px',
                              fontSize: '14px',
                            }}
                          />
                          <Bar
                            dataKey="icMoyen"
                            name="Indice de consommation (IC)"
                            fill="var(--color-blue-700)"
                            radius={[2, 2, 0, 0]}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <footer className="mt-2 border-t border-border pt-2 text-14 text-ink-muted tabular-nums">
                      Source : Banque pour le Commerce et l’Entrepreneuriat du Gabon (BCEG) & DGE · Période : 2025-T3 à 2026-T4
                    </footer>
                  </section>

                  <section className="col-span-12 lg:col-span-6 flex flex-col justify-between rounded-sm border border-border bg-surface p-4">
                    <div className="mb-3">
                      <h2 className="text-18 font-semibold text-ink">
                        Répartition des bandes actives par statut sanitaire, en nombre de fermes
                      </h2>
                      <p className="text-14 text-ink-muted">
                        4 états réglementaires du programme POUFA sur le périmètre filtré ({formatInt(filteredFarms.length)} fermes)
                      </p>
                    </div>

                    <div className="h-64 w-full tabular-nums">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          layout="vertical"
                          data={statusDistributionData}
                          margin={{ top: 12, right: 24, left: 24, bottom: 12 }}
                        >
                          <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" horizontal={false} />
                          <XAxis
                            type="number"
                            tick={{ fill: 'var(--color-ink-muted)', fontSize: 12 }}
                          />
                          <YAxis
                            type="category"
                            dataKey="statut"
                            width={105}
                            tick={{ fill: 'var(--color-ink)', fontSize: 13 }}
                          />
                          <Tooltip
                            formatter={(val) => [`${formatInt(Number(val ?? 0))} fermes`, 'Effectif']}
                            contentStyle={{
                              backgroundColor: 'var(--color-surface)',
                              borderColor: 'var(--color-border)',
                              borderRadius: '4px',
                              fontSize: '14px',
                            }}
                          />
                          <Bar dataKey="fermes" name="Nombre d'exploitations" radius={[0, 2, 2, 0]}>
                            {statusDistributionData.map((entry) => (
                              <Cell key={entry.statut} fill={entry.color} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <footer className="mt-2 border-t border-border pt-2 text-14 text-ink-muted tabular-nums">
                      Source : Brigades provinciales de surveillance sanitaire DGE · Arrêté du 6 nov. 2026 à 07:40
                    </footer>
                  </section>
                </>
              )}

              {/* SECTION 2 : RÉPERTOIRE DES 150 EXPLOITATIONS & BANDES */}
              {section === 'repertoire' && (
                <div className="col-span-12 flex flex-col gap-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-sm border border-border bg-surface p-4">
                    <div className="relative flex-1 min-w-[260px]">
                      <Search
                        size={16}
                        strokeWidth={1.75}
                        className="pointer-events-none absolute left-3 top-3 text-ink-muted"
                        aria-hidden="true"
                      />
                      <input
                        type="search"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Rechercher par code (EST-0014), localité (Nkok, Franceville, Oyem) ou responsable…"
                        aria-label="Rechercher une exploitation"
                        className="min-h-[2.5rem] w-full rounded-sm border border-border bg-bg pl-9 pr-3 py-1.5 text-14 text-ink focus:border-blue-700"
                      />
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <Button
                        variant={simulateLoading ? 'primary' : 'secondary'}
                        size="bureau"
                        icon={Eye}
                        onClick={() => setSimulateLoading((v) => !v)}
                      >
                        {simulateLoading
                          ? 'Masquer le squelette de chargement'
                          : 'Tester l’état chargement (Squelette)'}
                      </Button>
                    </div>
                  </div>

                  <DataTable
                    caption="Répertoire officiel des exploitations avicoles suivies — Programme POUFA Gabon"
                    sourceLabel={`Source : Direction Générale de l'Élevage (DGE) · Fuseau Africa/Libreville · ${formatInt(
                      filteredFarms.length
                    )} exploitation(s) affichée(s)`}
                    data={filteredFarms}
                    columns={farmColumns}
                    loading={simulateLoading}
                    getRowId={(r) => r.code}
                    getRowStatus={(r) => r.statut}
                    onRowClick={(r) => setSelectedFarm(r)}
                    onResetFilters={resetGlobalFilters}
                    exportFileName="repertoire-150-fermes-poufa-gabon.csv"
                    onCopiedCode={onCopiedCode}
                  />
                </div>
              )}

              {/* SECTION 3 : CARTE NATIONALE DE VIGILANCE SANITAIRE */}
              {section === 'carte' && (
                <>
                  <div className="col-span-12 lg:col-span-8">
                    <GabonFarmsMap
                      farms={filteredFarms}
                      selectedFarmCode={selectedFarm?.code ?? null}
                      onSelectFarm={(farm) => setSelectedFarm(farm)}
                    />
                  </div>

                  <div className="col-span-12 lg:col-span-4 flex flex-col gap-4">
                    <section className="flex flex-col rounded-sm border border-border bg-surface">
                      <div className="border-b border-border bg-bg px-4 py-3">
                        <h2 className="text-16 font-semibold text-ink">
                          Exploitations en alerte ou sous vigilance ({
                            filteredFarms.filter(
                              (f) => f.statut === 'alerte' || f.statut === 'vigilance'
                            ).length
                          })
                        </h2>
                        <p className="text-14 text-ink-muted">
                          Cliquez sur une ligne pour ouvrir la fiche complète
                        </p>
                      </div>
                      <ul className="max-h-[430px] divide-y divide-border overflow-y-auto">
                        {filteredFarms
                          .filter((f) => f.statut === 'alerte' || f.statut === 'vigilance')
                          .map((f) => (
                            <li key={f.code}>
                              <button
                                type="button"
                                onClick={() => setSelectedFarm(f)}
                                className="flex w-full items-center justify-between gap-2 px-4 py-3 text-left text-14 hover:bg-blue-50/50 cursor-pointer tabular-nums"
                              >
                                <div className="flex flex-col gap-0.5">
                                  <div className="flex items-center gap-2">
                                    <StatusBadge status={f.statut} compact />
                                    <span className="font-mono font-semibold text-ink">
                                      {f.code}
                                    </span>
                                  </div>
                                  <span className="font-medium text-ink">{f.nom}</span>
                                  <span className="text-ink-muted">
                                    {f.province} · {f.localite}
                                  </span>
                                </div>
                                <div className="text-right">
                                  <span className="block font-semibold text-ink">
                                    {formatDec1(f.mortaliteCumuleePct)} %
                                  </span>
                                  <span className="text-ink-muted">J{f.jourBande}/45</span>
                                </div>
                              </button>
                            </li>
                          ))}
                      </ul>
                    </section>
                  </div>
                </>
              )}

              {/* SECTION 4 : ALERTES SANITAIRES (Liste à gauche, détail à droite, frise horizontale, actions réservées au rôle VETERINAIRE) */}
              {section === 'alertes' && (
                <>
                  {/* Liste des alertes à gauche (5 colonnes) */}
                  <div className="col-span-12 lg:col-span-5 flex flex-col rounded-sm border border-border bg-surface">
                    <div className="border-b border-border bg-bg px-4 py-3">
                      <h1 className="text-18 font-semibold text-ink">
                        Dossiers d’alerte sanitaire ({formatInt(filteredAlerts.length)})
                      </h1>
                      <p className="text-14 text-ink-muted">
                        Signalements terrains transmis par les carnets éleveurs
                      </p>
                    </div>

                    {filteredAlerts.length === 0 ? (
                      <div className="p-4">
                        <EmptyState
                          title="Aucune alerte sanitaire dans cette province."
                          description="Toutes les bandes de la province sélectionnée respectent les seuils de mortalité journalière (< 1,0 %)."
                          actionLabel="Afficher toutes les provinces"
                          onAction={() => setProvinceFilter('ALL')}
                        />
                      </div>
                    ) : (
                      <ul className="divide-y divide-border">
                        {filteredAlerts.map((alr) => {
                          const isSelected = activeAlert?.id === alr.id;
                          return (
                            <li key={alr.id}>
                              <button
                                type="button"
                                onClick={() => setSelectedAlertId(alr.id)}
                                className={`relative flex w-full flex-col gap-1.5 p-4 text-left transition-colors duration-150 cursor-pointer ${
                                  isSelected
                                    ? 'bg-blue-50'
                                    : 'bg-surface hover:bg-bg'
                                }`}
                              >
                                {isSelected && (
                                  <span
                                    className="absolute left-0 top-0 bottom-0 w-[3px] bg-green-700"
                                    aria-hidden="true"
                                  />
                                )}
                                <div className="flex flex-wrap items-center justify-between gap-2 tabular-nums">
                                  <div className="flex items-center gap-2">
                                    <StatusBadge status={alr.gravite} compact />
                                    <span className="font-mono text-14 font-semibold text-ink">
                                      {alr.id}
                                    </span>
                                  </div>
                                  <span className="rounded-sm border border-border bg-surface px-2 py-0.5 text-14 font-semibold text-ink">
                                    {alr.statutWorkflow}
                                  </span>
                                </div>

                                <div className="flex items-baseline justify-between gap-2">
                                  <span className="text-16 font-semibold text-ink">
                                    {alr.fermeNom} ({alr.fermeCode})
                                  </span>
                                  <span className="text-14 font-semibold text-red-700 tabular-nums">
                                    {formatInt(alr.mortalite24h)} morts / 24 h ({formatDec1(alr.mortalitePct24h)} %)
                                  </span>
                                </div>

                                <p className="text-14 text-ink-muted tabular-nums">
                                  {alr.province} · {alr.localite} · Déclarée le {alr.dateDeclaration}
                                </p>
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </div>

                  {/* Détail de l'alerte à droite (7 colonnes) */}
                  <div className="col-span-12 lg:col-span-7">
                    {activeAlert ? (
                      <section className="flex flex-col gap-6 rounded-sm border border-border bg-surface p-6">
                        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-border pb-4">
                          <div className="flex flex-col gap-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <CodeCopyBadge code={activeAlert.id} onCopied={onCopiedCode} />
                              <CodeCopyBadge code={activeAlert.bandeCode} onCopied={onCopiedCode} />
                              <StatusBadge status={activeAlert.gravite} />
                            </div>
                            <h2 className="mt-1 text-20 font-semibold text-ink">
                              {activeAlert.fermeNom} — {activeAlert.localite} ({activeAlert.province})
                            </h2>
                            <p className="text-14 text-ink-muted tabular-nums">
                              Vétérinaire assigné : {activeAlert.veterinaireAssigne}
                            </p>
                          </div>
                        </div>

                        {/* Frise horizontale des statuts (Nouvelle → En analyse → Confirmée/Infirmée → Close) */}
                        <div>
                          <h3 className="mb-2 text-14 font-semibold text-ink-muted">
                            Cycle de traitement réglementaire DGE :
                          </h3>
                          <Timeline
                            orientation="horizontal"
                            items={buildAlertHorizontalTimeline(activeAlert)}
                          />
                        </div>

                        {/* Détails cliniques et comptage */}
                        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 tabular-nums">
                          <div className="rounded-sm border border-border bg-bg p-3">
                            <span className="text-14 text-ink-muted">Morts sur 24 h</span>
                            <div className="mt-1 flex items-baseline gap-1">
                              <span className="text-24 font-semibold text-red-700">
                                {formatInt(activeAlert.mortalite24h)}
                              </span>
                              <span className="text-14 font-regular text-ink-muted">
                                sujets ({formatDec1(activeAlert.mortalitePct24h)} %)
                              </span>
                            </div>
                          </div>
                          <div className="rounded-sm border border-border bg-bg p-3">
                            <span className="text-14 text-ink-muted">Effectif présent</span>
                            <div className="mt-1 flex items-baseline gap-1">
                              <span className="text-24 font-semibold text-ink">
                                {formatInt(activeAlert.effectifPresent)}
                              </span>
                              <span className="text-14 font-regular text-ink-muted">sujets</span>
                            </div>
                          </div>
                          <div className="rounded-sm border border-border bg-bg p-3">
                            <span className="text-14 text-ink-muted">Statut dossier</span>
                            <div className="mt-1">
                              <span className="text-20 font-semibold text-ink">
                                {activeAlert.statutWorkflow}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col gap-3 rounded-sm border border-border bg-bg p-4 text-14">
                          <div>
                            <h4 className="font-semibold text-ink">
                              Signes cliniques déclarés par l’éleveur :
                            </h4>
                            <ul className="mt-1 list-disc pl-5 text-ink">
                              {activeAlert.symptomes.map((sym) => (
                                <li key={sym}>{sym}</li>
                              ))}
                            </ul>
                          </div>

                          <div>
                            <h4 className="font-semibold text-ink">
                              Observation terrain de l’éleveur :
                            </h4>
                            <p className="mt-0.5 text-ink-muted">{activeAlert.commentaireTerrain}</p>
                          </div>

                          {activeAlert.photoMetadata && (
                            <div className="rounded-sm border border-border bg-surface p-3 tabular-nums">
                              <span className="font-semibold text-ink">
                                Pièce jointe terrain : {activeAlert.photoMetadata.fileName}
                              </span>
                              <p className="text-ink-muted">
                                Format redimensionné : {activeAlert.photoMetadata.dimensions} · {formatInt(activeAlert.photoMetadata.sizeKb)} Ko · Capturée le {activeAlert.photoMetadata.capturedAt}
                              </p>
                            </div>
                          )}

                          {activeAlert.diagnosticVeterinaire && (
                            <div className="border-t border-border pt-3">
                              <h4 className="font-semibold text-ink">
                                Diagnostic et prescription vétérinaire :
                              </h4>
                              <p className="mt-0.5 text-ink">{activeAlert.diagnosticVeterinaire}</p>
                            </div>
                          )}
                        </div>

                        {/* CONDITION STRICTE : Les boutons d'action n'existent QUE pour le rôle VETERINAIRE */}
                        {activeRole === 'VETERINAIRE' ? (
                          <div className="flex flex-col gap-3 rounded-sm border border-green-700/40 bg-green-50/40 p-4">
                            <h3 className="text-16 font-semibold text-ink">
                              Décision sanitaire — Habilitation Vétérinaire inspecteur active
                            </h3>
                            <label
                              htmlFor="vet-diagnostic-note"
                              className="text-14 font-medium text-ink"
                            >
                              Compte-rendu d’inspection ou prescription (inscrit au registre DGE) :
                            </label>
                            <input
                              id="vet-diagnostic-note"
                              type="text"
                              value={vetNoteInput}
                              onChange={(e) => setVetNoteInput(e.target.value)}
                              placeholder="Ex. Prélèvements effectués, isolement bâtiment B2 et traitement anticoccidien 5 jours…"
                              className="min-h-[2.5rem] w-full rounded-sm border border-border bg-surface px-3 py-1.5 text-14 text-ink"
                            />
                            <div className="flex flex-wrap items-center gap-2 pt-1">
                              {activeAlert.statutWorkflow === 'Nouvelle' && (
                                <Button
                                  variant="primary"
                                  size="bureau"
                                  icon={RefreshCw}
                                  onClick={() =>
                                    setPendingVetDecision({
                                      alert: activeAlert,
                                      nextStatus: 'En analyse',
                                    })
                                  }
                                >
                                  Passer en analyse vétérinaire
                                </Button>
                              )}

                              {(activeAlert.statutWorkflow === 'Nouvelle' ||
                                activeAlert.statutWorkflow === 'En analyse') && (
                                <>
                                  <Button
                                    variant="danger"
                                    size="bureau"
                                    icon={ShieldAlert}
                                    onClick={() =>
                                      setPendingVetDecision({
                                        alert: activeAlert,
                                        nextStatus: 'Confirmée',
                                      })
                                    }
                                  >
                                    Confirmer l’alerte sanitaire
                                  </Button>
                                  <Button
                                    variant="secondary"
                                    size="bureau"
                                    icon={XCircle}
                                    onClick={() =>
                                      setPendingVetDecision({
                                        alert: activeAlert,
                                        nextStatus: 'Infirmée',
                                      })
                                    }
                                  >
                                    Infirmer (origine non infectieuse)
                                  </Button>
                                </>
                              )}

                              {activeAlert.statutWorkflow !== 'Close' && (
                                <Button
                                  variant="secondary"
                                  size="bureau"
                                  icon={Check}
                                  onClick={() =>
                                    setPendingVetDecision({
                                      alert: activeAlert,
                                      nextStatus: 'Close',
                                    })
                                  }
                                >
                                  Clore le dossier sanitaire
                                </Button>
                              )}
                            </div>
                          </div>
                        ) : (
                          /* État Permission refusée explicite pour les rôles non-vétérinaires (les boutons d'action vétérinaire n'existent pas) */
                          <div
                            role="region"
                            aria-label="Restriction d'habilitation sanitaire"
                            className="flex flex-wrap items-center justify-between gap-3 rounded-sm border border-border bg-bg p-4 text-14"
                          >
                            <div className="flex items-start gap-3">
                              <Lock
                                size={20}
                                strokeWidth={1.75}
                                className="mt-0.5 text-ink-muted shrink-0"
                                aria-hidden="true"
                              />
                              <div>
                                <p className="font-semibold text-ink">
                                  Consultation seule — Profil actuel : {ROLE_LABELS[activeRole]}
                                </p>
                                <p className="text-ink-muted">
                                  Conformément au protocole DGE, seuls les agents connectés avec le rôle Vétérinaire inspecteur disposent des actions de qualification et de clôture sanitaire.
                                </p>
                              </div>
                            </div>
                            <Button
                              variant="secondary"
                              size="bureau"
                              icon={UserCheck}
                              onClick={() => onChangeRole('VETERINAIRE')}
                            >
                              Activer le rôle Vétérinaire pour agir
                            </Button>
                          </div>
                        )}

                        {/* Journal d'audit du dossier */}
                        <div>
                          <h3 className="mb-2 text-14 font-semibold text-ink-muted">
                            Journal d’audit horodaté (Africa/Libreville) :
                          </h3>
                          <Timeline
                            orientation="vertical"
                            items={activeAlert.historique.map((h, i) => ({
                              id: `${activeAlert.id}-h-${i}`,
                              title: `Statut : ${h.etape}`,
                              date: h.date,
                              subtitle: h.auteur,
                              description: h.note,
                              status:
                                h.etape === 'Confirmée' || h.etape === 'Nouvelle'
                                  ? 'alerte'
                                  : h.etape === 'En analyse'
                                  ? 'vigilance'
                                  : 'ok',
                            }))}
                          />
                        </div>
                      </section>
                    ) : null}
                  </div>
                </>
              )}
            </div>
          </main>
        </div>
      </div>

      {/* Panneau latéral Drawer : Fiche détaillée d'une exploitation */}
      <Drawer
        isOpen={Boolean(selectedFarm)}
        onClose={() => setSelectedFarm(null)}
        title={selectedFarm ? `${selectedFarm.nom}` : 'Fiche exploitation'}
        subtitle={
          selectedFarm
            ? `${selectedFarm.province} · ${selectedFarm.localite} · Mise à jour : ${selectedFarm.derniereMaj}`
            : undefined
        }
        footer={
          selectedFarm && (
            <div className="flex flex-wrap items-center justify-between gap-2">
              <Button
                variant="secondary"
                size="bureau"
                icon={QrCode}
                onClick={() => {
                  const lot = selectedFarm.lotActifCode;
                  setSelectedFarm(null);
                  onOpenQrLot(lot);
                }}
              >
                Voir la fiche QR du lot
              </Button>
              <Button
                variant="primary"
                size="bureau"
                onClick={() => setSelectedFarm(null)}
              >
                Fermer la fiche
              </Button>
            </div>
          )
        }
      >
        {selectedFarm && (
          <div className="flex flex-col gap-4 text-14 tabular-nums">
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-sm border border-border bg-bg p-3">
              <StatusBadge status={selectedFarm.statut} />
              <div className="flex items-center gap-2">
                <CodeCopyBadge code={selectedFarm.code} onCopied={onCopiedCode} />
                <CodeCopyBadge code={selectedFarm.bandeActiveCode} onCopied={onCopiedCode} />
              </div>
            </div>

            <dl className="divide-y divide-border rounded-sm border border-border bg-surface px-4 py-2">
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Responsable d’exploitation</dt>
                <dd className="font-semibold text-ink">{selectedFarm.responsable}</dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Cohorte & Souche</dt>
                <dd className="font-semibold text-ink">
                  {selectedFarm.cohorte} · {selectedFarm.souche}
                </dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Avancement de la bande</dt>
                <dd className="font-semibold text-ink">
                  Jour {formatInt(selectedFarm.jourBande)} sur {formatInt(selectedFarm.dureeCibleJours)}
                </dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Effectif présent / initial</dt>
                <dd className="font-semibold text-ink">
                  {formatInt(selectedFarm.effectifPresent)} / {formatInt(selectedFarm.effectifInitial)} sujets
                </dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Mortalité cumulée</dt>
                <dd className="font-semibold text-ink">
                  {formatDec1(selectedFarm.mortaliteCumuleePct)} %
                </dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Poids vif moyen dernière pesée</dt>
                <dd className="font-semibold text-ink">
                  {formatInt(selectedFarm.poidsMoyenG)} g
                </dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Indice de consommation (IC)</dt>
                <dd className="font-semibold text-ink">
                  {formatDec2(selectedFarm.indiceConsommation)} kg/kg
                </dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Aliment cumulé distribué</dt>
                <dd className="font-semibold text-ink">
                  {formatInt(selectedFarm.alimentCumuleKg)} kg
                </dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Coût de revient estimé (BCEG)</dt>
                <dd className="font-semibold text-ink">
                  {formatFcfa(selectedFarm.coutProductionFcfaKg)} / kg vif
                </dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-ink-muted">Lot de traçabilité QR</dt>
                <dd>
                  <CodeCopyBadge code={selectedFarm.lotActifCode} compact onCopied={onCopiedCode} />
                </dd>
              </div>
            </dl>
          </div>
        )}
      </Drawer>

      {/* Dialogue de confirmation pour les décisions vétérinaires */}
      <ConfirmDialog
        isOpen={Boolean(pendingVetDecision)}
        title={
          pendingVetDecision
            ? `Passer l’alerte ${pendingVetDecision.alert.id} au statut « ${pendingVetDecision.nextStatus} »`
            : ''
        }
        description="Cette décision sanitaire sera horodatée (Africa/Libreville) et inscrite au registre national DGE."
        summaryItems={
          pendingVetDecision
            ? [
                {
                  label: 'Exploitation',
                  value: `${pendingVetDecision.alert.fermeNom} (${pendingVetDecision.alert.fermeCode})`,
                },
                {
                  label: 'Bande concernée',
                  value: pendingVetDecision.alert.bandeCode,
                },
                {
                  label: 'Nouveau statut',
                  value: pendingVetDecision.nextStatus,
                },
              ]
            : []
        }
        confirmLabel="Enregistrer la décision vétérinaire"
        variant={
          pendingVetDecision?.nextStatus === 'Confirmée' ? 'danger' : 'primary'
        }
        onConfirm={() => {
          if (!pendingVetDecision) return;
          const note =
            vetNoteInput.trim() ||
            `Statut mis à jour vers « ${pendingVetDecision.nextStatus} » par l'inspection vétérinaire DGE.`;
          onUpdateAlertStatus(
            pendingVetDecision.alert.id,
            pendingVetDecision.nextStatus,
            note
          );
          setVetNoteInput('');
          setPendingVetDecision(null);
        }}
        onCancel={() => setPendingVetDecision(null)}
      />
    </div>
  );
};
