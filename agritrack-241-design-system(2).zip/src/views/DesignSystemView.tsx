import React, { useState } from 'react';
import {
  Check,
  Download,
  Eye,
  Plus,
  RefreshCw,
  ShieldAlert,
  SlidersHorizontal,
  Trash2,
} from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Field } from '../components/ui/Field';
import { NumberStepper } from '../components/ui/NumberStepper';
import { DataTable, type DataTableColumn } from '../components/ui/DataTable';
import { StatCard } from '../components/ui/StatCard';
import { StatusBadge } from '../components/ui/StatusBadge';
import { EmptyState } from '../components/ui/EmptyState';
import { ErrorState } from '../components/ui/ErrorState';
import { Toast } from '../components/ui/Toast';
import { SyncStatusBar } from '../components/ui/SyncStatusBar';
import { Timeline } from '../components/ui/Timeline';
import { Drawer } from '../components/ui/Drawer';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { CodeCopyBadge } from '../components/ui/CodeCopyBadge';
import { INITIAL_FARMS_150 } from '../data/gabonSeedData';
import type { FarmRecord } from '../types/domain';
import { formatDec1, formatDec2, formatInt } from '../utils/formatters';

export interface DesignSystemViewProps {
  onNavigateBack?: () => void;
  squintMode: boolean;
  onToggleSquint: () => void;
  grayscaleMode: boolean;
  onToggleGrayscale: () => void;
}

export const DesignSystemView: React.FC<DesignSystemViewProps> = ({
  onNavigateBack,
  squintMode,
  onToggleSquint,
  grayscaleMode,
  onToggleGrayscale,
}) => {
  const [stepperVal, setStepperVal] = useState<number | null>(3);
  const [fieldVal, setFieldVal] = useState('222');
  const [errorFieldVal, setErrorFieldVal] = useState('45');
  const [tableState, setTableState] = useState<'data' | 'loading' | 'empty'>('data');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(
    'Enregistré sur ce téléphone. Envoi dès le retour du réseau.'
  );

  const sampleFarms = INITIAL_FARMS_150.slice(0, 6);

  const columns: DataTableColumn<FarmRecord>[] = [
    {
      key: 'nom',
      header: 'Exploitation avicole',
      sortable: true,
      sortAccessor: (r) => r.nom,
      csvAccessor: (r) => r.nom,
      render: (r) => <span className="font-medium text-ink">{r.nom}</span>,
    },
    {
      key: 'province',
      header: 'Province & localité',
      sortable: true,
      sortAccessor: (r) => r.province,
      csvAccessor: (r) => `${r.province} - ${r.localite}`,
      render: (r) => (
        <span className="text-ink-muted">
          {r.province} · {r.localite}
        </span>
      ),
    },
    {
      key: 'effectifPresent',
      header: 'Effectif présent',
      unit: 'sujets',
      align: 'right',
      sortable: true,
      sortAccessor: (r) => r.effectifPresent,
      csvAccessor: (r) => r.effectifPresent,
      render: (r) => formatInt(r.effectifPresent),
    },
    {
      key: 'mortaliteCumuleePct',
      header: 'Mortalité cumulée',
      unit: '%',
      align: 'right',
      sortable: true,
      sortAccessor: (r) => r.mortaliteCumuleePct,
      csvAccessor: (r) => r.mortaliteCumuleePct,
      render: (r) => formatDec1(r.mortaliteCumuleePct),
    },
    {
      key: 'indiceConsommation',
      header: 'Indice conso. (IC)',
      align: 'right',
      sortable: true,
      sortAccessor: (r) => r.indiceConsommation,
      csvAccessor: (r) => r.indiceConsommation,
      render: (r) => formatDec2(r.indiceConsommation),
    },
  ];

  return (
    <div className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6">
      {/* En-tête de la page de référence /design */}
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4 rounded-sm border border-border bg-surface p-4">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <CodeCopyBadge code="LOT-A · /design" />
            <span className="text-14 font-medium text-ink-muted">
              Référentiel visuel & 14 composants normalisés AgriTrack 241
            </span>
          </div>
          <h1 className="text-24 font-semibold text-ink">
            Système de design institutionnel — Programme POUFA · DGE Gabon
          </h1>
          <p className="text-14 text-ink-muted">
            Aucun dégradé, aucune ressource externe, aucun gris pur, chiffres tabulaires obligatoires, formes géométriques distinctes par état.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant={squintMode ? 'primary' : 'secondary'}
            size="bureau"
            icon={Eye}
            onClick={onToggleSquint}
          >
            {squintMode ? 'Désactiver plissement des yeux' : 'Test plissement des yeux (2 s)'}
          </Button>
          <Button
            variant={grayscaleMode ? 'primary' : 'secondary'}
            size="bureau"
            icon={SlidersHorizontal}
            onClick={onToggleGrayscale}
          >
            {grayscaleMode ? 'Couleurs normales' : 'Test niveaux de gris'}
          </Button>
          {onNavigateBack && (
            <Button variant="primary" size="bureau" onClick={onNavigateBack}>
              Retour à l’application
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* 1. Jetons de couleurs et règle 60/30/10 */}
        <section className="rounded-sm border border-border bg-surface p-6">
          <h2 className="mb-4 text-20 font-semibold text-ink">
            1. Jetons de couleurs (90 % neutres teintés vert, 8 % vert programme, 2 % accents)
          </h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
            {[
              { name: 'Fond (#F5F7F8)', cls: 'bg-bg text-ink border-border' },
              { name: 'Surface (#FFFFFF)', cls: 'bg-surface text-ink border-border' },
              { name: 'Encre (#14212B)', cls: 'bg-ink text-surface border-ink' },
              { name: 'Vert 700 (#1E6B45)', cls: 'bg-green-700 text-surface border-green-700' },
              { name: 'Bleu 700 (#1F5FA8)', cls: 'bg-blue-700 text-surface border-blue-700' },
              { name: 'Orange 600 (#C96F1B)', cls: 'bg-orange-600 text-surface border-orange-600' },
              { name: 'Rouge 700 (#B3261E)', cls: 'bg-red-700 text-surface border-red-700' },
            ].map((swatch) => (
              <div
                key={swatch.name}
                className={`flex h-16 items-end rounded-sm border p-2.5 text-14 font-medium tabular-nums ${swatch.cls}`}
              >
                {swatch.name}
              </div>
            ))}
          </div>
        </section>

        {/* 2. Composants StatusBadge & CodeCopyBadge */}
        <section className="rounded-sm border border-border bg-surface p-6">
          <h2 className="mb-4 text-20 font-semibold text-ink">
            2. États sémantiques (StatusBadge) & Identifiants techniques (CodeCopyBadge)
          </h2>
          <div className="flex flex-wrap items-center gap-4">
            <StatusBadge status="ok" />
            <StatusBadge status="vigilance" />
            <StatusBadge status="alerte" />
            <StatusBadge status="none" />
            <div className="h-6 w-[1px] bg-border" />
            <CodeCopyBadge code="EST-0014" />
            <CodeCopyBadge code="EST-0014-B03" />
            <CodeCopyBadge code="EST-0014-B03-L01" />
          </div>
        </section>

        {/* 3. Composant Button (Bureau 40 px vs Terrain ≥ 48 px) */}
        <section className="rounded-sm border border-border bg-surface p-6">
          <h2 className="mb-4 text-20 font-semibold text-ink">
            3. Boutons d’action (Button) — Toujours accompagnés d’un libellé
          </h2>
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <span className="w-36 text-14 font-medium text-ink-muted">Mode Bureau (40 px) :</span>
              <Button variant="primary" size="bureau" icon={Check}>
                Enregistrer la journée
              </Button>
              <Button variant="secondary" size="bureau" icon={Download}>
                Exporter la cohorte
              </Button>
              <Button variant="danger" size="bureau" icon={ShieldAlert}>
                Confirmer l’alerte sanitaire
              </Button>
              <Button variant="ghost" size="bureau" icon={RefreshCw}>
                Actualiser
              </Button>
              <Button variant="primary" size="bureau" icon={Plus} disabled>
                Action verrouillée
              </Button>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <span className="w-36 text-14 font-medium text-ink-muted">Mode Terrain (≥ 48 px) :</span>
              <Button variant="primary" size="terrain" icon={Check}>
                Saisir la journée (Jour 23)
              </Button>
              <Button variant="secondary" size="terrain" icon={ShieldAlert}>
                Déclarer un problème sanitaire
              </Button>
            </div>
          </div>
        </section>

        {/* 4. Composants Field & NumberStepper */}
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="rounded-sm border border-border bg-surface p-6">
            <h2 className="mb-4 text-20 font-semibold text-ink">
              4. Champs de saisie (Field — normal, terrain 18 px, erreur explicite)
            </h2>
            <div className="flex flex-col gap-4">
              <Field
                id="design-aliment"
                label="Aliment distribué ce jour"
                unit="kg"
                hint="Hier : 222 kg"
                mode="terrain"
                requiredLabel
                value={fieldVal}
                onChange={(e) => setFieldVal(e.target.value)}
              />
              <Field
                id="design-morts-err"
                label="Morts constatés (démonstration d’erreur)"
                unit="sujets"
                hint="Effectif présent : 38 sujets"
                mode="terrain"
                requiredLabel
                value={errorFieldVal}
                onChange={(e) => setErrorFieldVal(e.target.value)}
                error="Les morts du jour (45) dépassent l'effectif présent (38). Vérifiez le comptage du bâtiment."
              />
            </div>
          </div>

          <div className="rounded-sm border border-border bg-surface p-6">
            <h2 className="mb-4 text-20 font-semibold text-ink">
              5. Saisie tactile éleveur (NumberStepper avec rappel de la veille)
            </h2>
            <NumberStepper
              id="design-stepper"
              label="Morts du jour (Jour 23)"
              unit="sujets"
              value={stepperVal}
              onChange={setStepperVal}
              yesterdayValue={3}
              yesterdayLabel="Reprendre hier"
              max={2436}
            />
          </div>
        </section>

        {/* 6. Composant StatCard */}
        <section className="rounded-sm border border-border bg-surface p-6">
          <h2 className="mb-4 text-20 font-semibold text-ink">
            6. Cartes d’indicateurs (StatCard — valeur 600, unité 400 sur ligne de base, date de mise à jour)
          </h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Effectif présent en bande"
              value="2 436"
              unit="sujets"
              variation="Sur 2 500 mis en place"
              period="Jour 23 / 45"
              updatedAt="5 nov. 2026 à 18:14"
              status="ok"
              size="large"
            />
            <StatCard
              label="Mortalité cumulée"
              value="2,6"
              unit="%"
              variation="Seuil vigilance : 4,0 %"
              period="64 sujets cumulés"
              updatedAt="5 nov. 2026 à 18:14"
              status="ok"
              size="large"
            />
            <StatCard
              label="Poids moyen dernière pesée"
              value="940"
              unit="g"
              variation="+15 g vs cible Ross 308"
              period="Pesée S3 (J21)"
              updatedAt="4 nov. 2026 à 18:20"
              status="ok"
              size="large"
            />
            <StatCard
              label="Alerte sanitaire active"
              value="2,1"
              unit="% / 24 h"
              variation="48 morts en 24 h"
              period="Ferme EST-0009"
              updatedAt="6 nov. 2026 à 06:50"
              status="alerte"
              size="large"
            />
          </div>
        </section>

        {/* 7. SyncStatusBar & Toast */}
        <section className="rounded-sm border border-border bg-surface p-6">
          <h2 className="mb-4 text-20 font-semibold text-ink">
            7. Barre de synchronisation (SyncStatusBar) & Notifications (Toast aria-live)
          </h2>
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <SyncStatusBar
                isOnline={true}
                pendingCount={0}
                lastSyncedAt="6 nov. 2026 à 07:40"
                onClick={() => setDrawerOpen(true)}
              />
              <SyncStatusBar
                isOnline={false}
                pendingCount={3}
                lastSyncedAt="5 nov. 2026 à 18:14"
                onClick={() => setDrawerOpen(true)}
              />
              <SyncStatusBar
                isOnline={true}
                pendingCount={2}
                lastSyncedAt="6 nov. 2026 à 07:35"
                onClick={() => setDrawerOpen(true)}
              />
            </div>

            {toastMsg ? (
              <Toast
                message={toastMsg}
                detail="Bande EST-0014-B03 · Jour 23 · 2 morts · 228 kg d'aliment"
                status="vigilance"
                onClose={() => setToastMsg(null)}
              />
            ) : (
              <div>
                <Button
                  variant="secondary"
                  size="bureau"
                  onClick={() =>
                    setToastMsg('Enregistré sur ce téléphone. Envoi dès le retour du réseau.')
                  }
                >
                  Réafficher le Toast de démonstration
                </Button>
              </div>
            )}
          </div>
        </section>

        {/* 8. EmptyState & ErrorState */}
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="rounded-sm border border-border bg-surface p-6">
            <h2 className="mb-4 text-20 font-semibold text-ink">
              8. État vide utile (EmptyState)
            </h2>
            <EmptyState
              title="Aucune pesée enregistrée cette semaine."
              description="La prochaine pesée hebdomadaire (Semaine 4 — Jour 28) est attendue le mercredi 11 nov. 2026 sur un échantillon de 100 sujets."
              actionLabel="Saisir une pesée anticipée"
              actionIcon={Plus}
              onAction={() => {}}
            />
          </div>

          <div className="rounded-sm border border-border bg-surface p-6">
            <h2 className="mb-4 text-20 font-semibold text-ink">
              9. État d’erreur actionnable (ErrorState)
            </h2>
            <ErrorState
              title="Incohérence sur l’effectif de la bande EST-0014-B03"
              correctionInstruction="Les morts du jour (45) dépassent l'effectif présent (38). Corrigez le nombre de morts ou vérifiez le bon de livraison initial."
              actionLabel="Revenir au comptage du jour"
              onAction={() => {}}
            />
          </div>
        </section>

        {/* 10. Timeline horizontale et verticale */}
        <section className="rounded-sm border border-border bg-surface p-6">
          <h2 className="mb-4 text-20 font-semibold text-ink">
            10. Frises chronologiques (Timeline — Horizontale statuts d’alerte & Verticale traçabilité)
          </h2>
          <div className="flex flex-col gap-6">
            <div>
              <h3 className="mb-2 text-14 font-semibold text-ink-muted">
                Frise horizontale des alertes sanitaires :
              </h3>
              <Timeline
                orientation="horizontal"
                items={[
                  {
                    id: '1',
                    title: 'Nouvelle',
                    date: '5 nov. 2026 à 14:20',
                    subtitle: 'Éleveur HOG-0007',
                    status: 'alerte',
                    completed: true,
                  },
                  {
                    id: '2',
                    title: 'En analyse',
                    date: '5 nov. 2026 à 16:40',
                    subtitle: 'Dr. Estelle Mouélé',
                    status: 'vigilance',
                    active: true,
                  },
                  {
                    id: '3',
                    title: 'Confirmée / Infirmée',
                    status: 'none',
                  },
                  {
                    id: '4',
                    title: 'Close',
                    status: 'none',
                  },
                ]}
              />
            </div>

            <div>
              <h3 className="mb-2 text-14 font-semibold text-ink-muted">
                Frise verticale de parcours lot QR :
              </h3>
              <Timeline
                orientation="vertical"
                items={[
                  {
                    id: 'v1',
                    title: 'Mise en place poussins J1 (Couvoir National d’Akanda)',
                    date: '15 oct. 2026',
                    subtitle: 'Ferme Avicole Nkok-Sud (EST-0014)',
                    description: '2 500 poussins Ross 308 vaccinés Newcastle HB1 + Bronchite H120.',
                    status: 'ok',
                  },
                  {
                    id: 'v2',
                    title: 'Contrôle prophylactique J21 validé',
                    date: '4 nov. 2026',
                    subtitle: 'Brigade provinciale Estuaire',
                    description: 'Rappel LaSota effectué, pesée moyenne 940 g conforme.',
                    status: 'ok',
                  },
                ]}
              />
            </div>
          </div>
        </section>

        {/* 11. DataTable avec bascule Données / Squelette de chargement / Vide */}
        <section className="rounded-sm border border-border bg-surface p-6">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-20 font-semibold text-ink">
              11. Tableau de données institutionnel (DataTable — lignes 40 px, tri, export, états)
            </h2>
            <div className="flex items-center gap-2">
              <Button
                variant={tableState === 'data' ? 'primary' : 'secondary'}
                size="bureau"
                onClick={() => setTableState('data')}
              >
                État normal (données)
              </Button>
              <Button
                variant={tableState === 'loading' ? 'primary' : 'secondary'}
                size="bureau"
                onClick={() => setTableState('loading')}
              >
                État chargement (squelette)
              </Button>
              <Button
                variant={tableState === 'empty' ? 'primary' : 'secondary'}
                size="bureau"
                onClick={() => setTableState('empty')}
              >
                État vide
              </Button>
            </div>
          </div>

          <DataTable
            caption="Extrait du répertoire national des exploitations (Programme POUFA)"
            sourceLabel="Source : Direction Générale de l'Élevage (DGE) · Période : Cohorte 2026-T4 · Mis à jour le 6 nov. 2026"
            data={tableState === 'empty' ? [] : sampleFarms}
            loading={tableState === 'loading'}
            columns={columns}
            getRowId={(r) => r.code}
            getRowStatus={(r) => r.statut}
            onResetFilters={() => setTableState('data')}
          />
        </section>

        {/* 12. Drawer & ConfirmDialog */}
        <section className="rounded-sm border border-border bg-surface p-6">
          <h2 className="mb-4 text-20 font-semibold text-ink">
            12 & 13. Panneaux flottants (Drawer & ConfirmDialog — seuls composants avec ombre fine)
          </h2>
          <div className="flex flex-wrap items-center gap-3">
            <Button
              variant="secondary"
              size="bureau"
              onClick={() => setDrawerOpen(true)}
            >
              Ouvrir le panneau latéral (Drawer)
            </Button>
            <Button
              variant="danger"
              size="bureau"
              icon={Trash2}
              onClick={() => setConfirmOpen(true)}
            >
              Ouvrir le dialogue de confirmation (ConfirmDialog)
            </Button>
          </div>
        </section>
      </div>

      <Drawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title="Fiche d’exploitation EST-0014"
        subtitle="Ferme Avicole Nkok-Sud · Bande active EST-0014-B03"
        footer={
          <div className="flex justify-end">
            <Button variant="primary" size="bureau" onClick={() => setDrawerOpen(false)}>
              Fermer le panneau
            </Button>
          </div>
        }
      >
        <div className="flex flex-col gap-4 text-14">
          <p className="text-ink-muted">
            Ce panneau latéral (`Drawer`) utilise l’ombre flottante `--shadow-floating` et une transition sobre de 150 ms.
          </p>
          <div className="rounded-sm border border-border bg-bg p-3 tabular-nums">
            <p className="font-semibold text-ink">Responsable : Jean-Bosco Ndong Mba</p>
            <p className="text-ink-muted">Localité : Zone Économique Spéciale de Nkok (Estuaire)</p>
            <p className="text-ink-muted">Effectif présent : 2 436 sujets (Jour 23 / 45)</p>
          </div>
        </div>
      </Drawer>

      <ConfirmDialog
        isOpen={confirmOpen}
        title="Confirmer la clôture sanitaire de l’alerte ALR-2026-088"
        description="Cette opération inscrit la décision vétérinaire au registre national DGE et notifie l'éleveur sur son carnet mobile."
        summaryItems={[
          { label: 'Exploitation concernée', value: 'HOG-0007 (Franceville)' },
          { label: 'Bande active', value: 'HOG-0007-B02' },
          { label: 'Mortalité 24 h constatée', value: '34 sujets (1,7 %)' },
        ]}
        confirmLabel="Valider la décision vétérinaire"
        onConfirm={() => setConfirmOpen(false)}
        onCancel={() => setConfirmOpen(false)}
      />
    </div>
  );
};
