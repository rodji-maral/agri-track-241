import React, { useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import { Layers, Maximize2, Minimize2, WifiOff } from 'lucide-react';
import type { FarmRecord, HealthStatus, ProvinceGabon } from '../../types/domain';
import { Button } from '../ui/Button';
import { StatusShapeSvg } from '../ui/StatusBadge';
import { formatDec1, formatInt } from '../../utils/formatters';

export interface GabonFarmsMapProps {
  farms: FarmRecord[];
  selectedFarmCode: string | null;
  onSelectFarm: (farm: FarmRecord) => void;
}

interface ProvincePolygon {
  province: ProvinceGabon;
  code: string;
  center: [number, number];
  coords: [number, number][];
}

// Contours simplifiés auto-hébergés des 9 provinces du Gabon (aucune tuile distante requise)
const GABON_PROVINCE_POLYGONS: ProvincePolygon[] = [
  {
    province: 'Estuaire',
    code: 'G1',
    center: [0.45, 9.75],
    coords: [
      [1.05, 9.3],
      [1.05, 10.45],
      [-0.15, 10.45],
      [-0.15, 9.25],
    ],
  },
  {
    province: 'Woleu-Ntem',
    code: 'G9',
    center: [1.6, 11.6],
    coords: [
      [2.3, 10.45],
      [2.3, 12.6],
      [0.65, 12.4],
      [0.65, 10.45],
    ],
  },
  {
    province: 'Ogooué-Ivindo',
    code: 'G6',
    center: [0.55, 12.85],
    coords: [
      [1.35, 12.4],
      [1.35, 14.4],
      [-0.45, 14.1],
      [-0.45, 11.6],
      [0.65, 11.6],
    ],
  },
  {
    province: 'Moyen-Ogooué',
    code: 'G3',
    center: [-0.65, 10.45],
    coords: [
      [-0.15, 9.8],
      [0.45, 11.6],
      [-1.25, 11.3],
      [-1.25, 9.8],
    ],
  },
  {
    province: 'Ogooué-Maritime',
    code: 'G8',
    center: [-1.15, 9.15],
    coords: [
      [-0.15, 8.7],
      [-0.15, 9.8],
      [-2.35, 9.95],
      [-2.35, 8.85],
    ],
  },
  {
    province: 'Ngounié',
    code: 'G4',
    center: [-1.85, 11.05],
    coords: [
      [-1.25, 9.95],
      [-1.0, 11.9],
      [-2.55, 12.1],
      [-2.55, 10.3],
    ],
  },
  {
    province: 'Ogooué-Lolo',
    code: 'G7',
    center: [-1.1, 12.5],
    coords: [
      [-0.45, 11.6],
      [-0.45, 13.4],
      [-1.9, 13.1],
      [-1.85, 11.9],
    ],
  },
  {
    province: 'Haut-Ogooué',
    code: 'G2',
    center: [-1.55, 13.65],
    coords: [
      [-0.45, 13.4],
      [-0.45, 14.5],
      [-2.5, 14.4],
      [-2.4, 13.0],
    ],
  },
  {
    province: 'Nyanga',
    code: 'G5',
    center: [-2.95, 10.95],
    coords: [
      [-2.35, 9.95],
      [-2.55, 11.9],
      [-3.9, 11.3],
      [-3.7, 10.1],
    ],
  },
];

function getMarkerSvgHtml(status: HealthStatus, isSelected: boolean): string {
  const size = isSelected ? 22 : 16;
  const stroke = 'var(--color-surface)';
  const strokeW = isSelected ? 2.5 : 1.5;

  if (status === 'ok') {
    return `<svg width="${size}" height="${size}" viewBox="0 0 20 20"><circle cx="10" cy="10" r="7.5" fill="var(--color-green-700)" stroke="${stroke}" stroke-width="${strokeW}"/></svg>`;
  }
  if (status === 'vigilance') {
    return `<svg width="${size}" height="${size}" viewBox="0 0 20 20"><polygon points="10,2 18.5,17.5 1.5,17.5" fill="var(--color-orange-600)" stroke="${stroke}" stroke-width="${strokeW}"/></svg>`;
  }
  if (status === 'alerte') {
    return `<svg width="${size}" height="${size}" viewBox="0 0 20 20"><polygon points="6.2,1.5 13.8,1.5 18.5,6.2 18.5,13.8 13.8,18.5 6.2,18.5 1.5,13.8 1.5,6.2" fill="var(--color-red-700)" stroke="${stroke}" stroke-width="${strokeW}"/></svg>`;
  }
  return `<svg width="${size}" height="${size}" viewBox="0 0 20 20"><rect x="2" y="7" width="16" height="6" rx="1.5" fill="var(--color-ink-muted)" stroke="${stroke}" stroke-width="${strokeW}"/></svg>`;
}

export const GabonFarmsMap: React.FC<GabonFarmsMapProps> = ({
  farms,
  selectedFarmCode,
  onSelectFarm,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  const [zoomLevel, setZoomLevel] = useState<number>(6);
  const [forceClusterView, setForceClusterView] = useState<boolean>(false);
  const [fallbackTileNotice, setFallbackTileNotice] = useState<boolean>(true);

  const isClustered = forceClusterView || zoomLevel <= 5;

  const provinceClusters = useMemo(() => {
    return GABON_PROVINCE_POLYGONS.map((poly) => {
      const pFarms = farms.filter((f) => f.province === poly.province);
      const alertCount = pFarms.filter((f) => f.statut === 'alerte').length;
      const vigCount = pFarms.filter((f) => f.statut === 'vigilance').length;
      const worstStatus: HealthStatus =
        alertCount > 0 ? 'alerte' : vigCount > 0 ? 'vigilance' : pFarms.length > 0 ? 'ok' : 'none';
      return {
        ...poly,
        count: pFarms.length,
        alertCount,
        vigCount,
        worstStatus,
        sampleFarm: pFarms[0],
      };
    });
  }, [farms]);

  // Initialisation de la carte Leaflet 100 % locale sans appel réseau
  useEffect(() => {
    if (!mapContainerRef.current || leafletMapRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [-0.85, 11.6],
      zoom: 6,
      minZoom: 5,
      maxZoom: 10,
      attributionControl: false,
    });

    // Couche vectorielle locale des 9 provinces du Gabon
    GABON_PROVINCE_POLYGONS.forEach((poly) => {
      const polygon = L.polygon(poly.coords, {
        color: 'var(--color-border)',
        weight: 1.5,
        fillColor: 'var(--color-surface)',
        fillOpacity: 0.92,
      }).addTo(map);

      polygon.bindTooltip(poly.province, {
        permanent: false,
        direction: 'center',
        className: 'agritrack-province-tooltip',
      });
    });

    const markersGroup = L.layerGroup().addTo(map);
    markersLayerRef.current = markersGroup;
    leafletMapRef.current = map;

    map.on('zoomend', () => {
      setZoomLevel(map.getZoom());
    });

    return () => {
      map.remove();
      leafletMapRef.current = null;
      markersLayerRef.current = null;
    };
  }, []);

  // Mise à jour des marqueurs (individuels ou clusters provinciaux au dézoom)
  useEffect(() => {
    const map = leafletMapRef.current;
    const group = markersLayerRef.current;
    if (!map || !group) return;

    group.clearLayers();

    if (isClustered) {
      provinceClusters.forEach((cluster) => {
        if (cluster.count === 0) return;
        const bgToken =
          cluster.worstStatus === 'alerte'
            ? 'var(--color-red-700)'
            : cluster.worstStatus === 'vigilance'
            ? 'var(--color-orange-600)'
            : 'var(--color-green-700)';

        const icon = L.divIcon({
          className: 'agritrack-cluster-icon',
          html: `<div style="display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:var(--radius-sm);background:${bgToken};color:var(--color-surface);border:2px solid var(--color-surface);font-weight:var(--weight-semibold);font-size:var(--text-14);font-variant-numeric:tabular-nums;">${cluster.count}</div>`,
          iconSize: [36, 36],
          iconAnchor: [18, 18],
        });

        const m = L.marker(cluster.center, { icon }).addTo(group);
        m.bindTooltip(
          `${cluster.province} : ${cluster.count} fermes (${cluster.alertCount} alerte, ${cluster.vigCount} à surveiller)`,
          { direction: 'top' }
        );
        m.on('click', () => {
          setForceClusterView(false);
          map.setView(cluster.center, 7);
        });
      });
    } else {
      farms.forEach((farm) => {
        const isSelected = farm.code === selectedFarmCode;
        const size = isSelected ? 22 : 16;
        const icon = L.divIcon({
          className: 'agritrack-farm-marker',
          html: getMarkerSvgHtml(farm.statut, isSelected),
          iconSize: [size, size],
          iconAnchor: [size / 2, size / 2],
        });

        const marker = L.marker([farm.lat, farm.lng], { icon }).addTo(group);
        marker.bindTooltip(
          `${farm.code} · ${farm.nom} (${farm.localite}) — Mortalité : ${formatDec1(
            farm.mortaliteCumuleePct
          )} %`,
          { direction: 'top' }
        );
        marker.on('click', () => {
          onSelectFarm(farm);
        });
      });
    }
  }, [farms, isClustered, provinceClusters, selectedFarmCode, onSelectFarm]);

  const counts = useMemo(() => {
    return {
      ok: farms.filter((f) => f.statut === 'ok').length,
      vigilance: farms.filter((f) => f.statut === 'vigilance').length,
      alerte: farms.filter((f) => f.statut === 'alerte').length,
      none: farms.filter((f) => f.statut === 'none').length,
    };
  }, [farms]);

  return (
    <div className="flex flex-col rounded-sm border border-border bg-surface">
      {/* Barre d'outils de la carte */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
        <div>
          <h3 className="text-16 font-semibold text-ink">
            Répartition géographique et statut sanitaire des exploitations suivies ({formatInt(farms.length)} fermes)
          </h3>
          <p className="text-14 text-ink-muted tabular-nums">
            Source : Système d’information géographique DGE Gabon · Projection WGS84 · Cliquer sur un marqueur pour ouvrir la fiche ferme
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant={isClustered ? 'primary' : 'secondary'}
            size="bureau"
            icon={Layers}
            onClick={() => setForceClusterView((v) => !v)}
          >
            {isClustered ? 'Vue agrégée par province (Clusters)' : 'Regrouper par province (Clusters)'}
          </Button>
          <Button
            variant="secondary"
            size="bureau"
            icon={zoomLevel > 6 ? Minimize2 : Maximize2}
            onClick={() => {
              const map = leafletMapRef.current;
              if (!map) return;
              if (map.getZoom() > 6) {
                map.setView([-0.85, 11.6], 6);
              } else {
                map.setView([0.4162, 9.4673], 8);
              }
            }}
          >
            {zoomLevel > 6 ? 'Vue nationale Gabon' : 'Zoomer sur l’Estuaire (Nkok)'}
          </Button>
        </div>
      </div>

      {/* Bandeau discret de repli vectoriel hors-cache */}
      {fallbackTileNotice && (
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border bg-bg px-4 py-2 text-14 text-ink-muted">
          <div className="flex items-center gap-2">
            <WifiOff size={16} strokeWidth={1.75} className="text-ink-muted shrink-0" aria-hidden="true" />
            <span>
              Fond cartographique vectoriel autonome actif (aucune tuile distante requise — conforme au mode hors-ligne DGE).
            </span>
          </div>
          <button
            type="button"
            onClick={() => setFallbackTileNotice(false)}
            className="text-14 font-medium text-blue-700 hover:underline cursor-pointer"
          >
            Masquer l’avis
          </button>
        </div>
      )}

      {/* Conteneur Carte + Légende fixe */}
      <div className="relative h-[480px] w-full bg-bg">
        <div ref={mapContainerRef} className="h-full w-full z-0" />

        {/* Légende fixe avec les 4 états de couleur ET de forme */}
        <div
          aria-label="Légende des états sanitaires"
          className="absolute bottom-4 left-4 z-[400] flex flex-col gap-2 rounded-sm border border-border bg-surface p-3 shadow-floating text-14 tabular-nums"
        >
          <span className="font-semibold text-ink">
            Légende (forme + couleur)
          </span>
          <div className="flex items-center justify-between gap-4">
            <span className="inline-flex items-center gap-2 text-ink">
              <StatusShapeSvg status="ok" size={12} className="text-green-700" />
              <span>Normal (disque)</span>
            </span>
            <strong className="font-semibold text-ink">{formatInt(counts.ok)}</strong>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="inline-flex items-center gap-2 text-ink">
              <StatusShapeSvg status="vigilance" size={12} className="text-orange-600" />
              <span>À surveiller (triangle)</span>
            </span>
            <strong className="font-semibold text-ink">{formatInt(counts.vigilance)}</strong>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="inline-flex items-center gap-2 text-ink">
              <StatusShapeSvg status="alerte" size={12} className="text-red-700" />
              <span>Alerte (octogone)</span>
            </span>
            <strong className="font-semibold text-ink">{formatInt(counts.alerte)}</strong>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="inline-flex items-center gap-2 text-ink-muted">
              <StatusShapeSvg status="none" size={12} className="text-ink-muted" />
              <span>Non renseigné (tiret)</span>
            </span>
            <strong className="font-semibold text-ink-muted">{formatInt(counts.none)}</strong>
          </div>
        </div>
      </div>
    </div>
  );
};
