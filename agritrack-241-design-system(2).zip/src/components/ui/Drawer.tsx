import React, { useEffect } from 'react';
import { X } from 'lucide-react';

export interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  widthClass?: string;
}

export const Drawer: React.FC<DrawerProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  footer,
  widthClass = 'max-w-lg',
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-ink/35 transition-opacity duration-150"
      role="dialog"
      aria-modal="true"
      aria-labelledby="drawer-title"
    >
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />
      <aside
        className={`relative z-10 flex h-full w-full ${widthClass} flex-col border-l border-border bg-surface shadow-floating transition-transform duration-150`}
      >
        <div className="tricolor-bar" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>
        <header className="flex items-start justify-between gap-4 border-b border-border px-6 py-4">
          <div className="flex flex-col gap-1">
            <h2 id="drawer-title" className="text-20 font-semibold text-ink">
              {title}
            </h2>
            {subtitle && (
              <p className="text-14 text-ink-muted tabular-nums">{subtitle}</p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex min-h-[2.5rem] items-center gap-1.5 rounded-sm border border-border bg-surface px-3 py-1.5 text-14 font-medium text-ink hover:bg-bg cursor-pointer shrink-0"
          >
            <X size={20} strokeWidth={1.75} aria-hidden="true" />
            <span>Fermer</span>
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-6">{children}</div>

        {footer && (
          <footer className="border-t border-border bg-bg px-6 py-4">
            {footer}
          </footer>
        )}
      </aside>
    </div>
  );
};
