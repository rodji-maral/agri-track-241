import React from 'react';
import { FileSpreadsheet } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Button } from './Button';

export interface EmptyStateProps {
  title: string;
  description: string;
  actionLabel?: string;
  actionIcon?: LucideIcon;
  onAction?: () => void;
  mode?: 'bureau' | 'terrain';
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  actionLabel,
  actionIcon,
  onAction,
  mode = 'bureau',
}) => {
  return (
    <div className="flex flex-col items-start justify-between gap-3 rounded-sm border border-border bg-surface p-4">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-sm border border-border bg-bg text-ink-muted">
          <FileSpreadsheet size={16} strokeWidth={1.75} aria-hidden="true" />
        </div>
        <div className="flex flex-col gap-1">
          <h3 className="text-16 font-semibold text-ink">{title}</h3>
          <p className="text-14 text-ink-muted">{description}</p>
        </div>
      </div>

      {actionLabel && onAction && (
        <div className="pl-11">
          <Button
            variant="secondary"
            size={mode}
            icon={actionIcon}
            onClick={onAction}
          >
            {actionLabel}
          </Button>
        </div>
      )}
    </div>
  );
};
