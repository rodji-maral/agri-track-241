import React from 'react';
import { X } from 'lucide-react';
import type { HealthStatus } from '../../types/domain';
import { StatusShapeSvg } from './StatusBadge';

export interface ToastProps {
  message: string;
  detail?: string;
  status?: HealthStatus;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({
  message,
  detail,
  status = 'ok',
  onClose,
}) => {
  const borderClass =
    status === 'alerte'
      ? 'border-red-700 bg-red-50'
      : status === 'vigilance'
      ? 'border-orange-600 bg-orange-50'
      : 'border-green-700 bg-surface';

  const shapeColor =
    status === 'alerte'
      ? 'text-red-700'
      : status === 'vigilance'
      ? 'text-orange-600'
      : 'text-green-700';

  return (
    <div
      role="status"
      aria-live="polite"
      className={`flex items-start justify-between gap-3 rounded-sm border p-3 shadow-floating ${borderClass}`}
    >
      <div className="flex items-start gap-2.5">
        <div className="mt-1">
          <StatusShapeSvg status={status} size={14} className={shapeColor} />
        </div>
        <div className="flex flex-col gap-0.5">
          <p className="text-14 font-semibold text-ink">{message}</p>
          {detail && <p className="text-14 text-ink-muted tabular-nums">{detail}</p>}
        </div>
      </div>

      <button
        type="button"
        onClick={onClose}
        className="inline-flex items-center gap-1 rounded-sm border border-border bg-surface px-2 py-1 text-14 font-medium text-ink hover:bg-bg cursor-pointer shrink-0"
      >
        <X size={16} strokeWidth={1.75} aria-hidden="true" />
        <span>Fermer</span>
      </button>
    </div>
  );
};
