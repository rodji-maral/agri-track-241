import React from 'react';
import type { HealthStatus } from '../../types/domain';

export interface StatusBadgeProps {
  status: HealthStatus;
  customLabel?: string;
  compact?: boolean;
}

const STATUS_META: Record<
  HealthStatus,
  {
    label: string;
    containerClass: string;
    shapeColorClass: string;
  }
> = {
  ok: {
    label: 'Normal',
    containerClass: 'bg-green-50 text-ink border-green-100',
    shapeColorClass: 'text-green-700',
  },
  vigilance: {
    label: 'À surveiller',
    containerClass: 'bg-orange-50 text-ink border-orange-600/30',
    shapeColorClass: 'text-orange-600',
  },
  alerte: {
    label: 'Alerte',
    containerClass: 'bg-red-50 text-ink border-red-700/30',
    shapeColorClass: 'text-red-700',
  },
  none: {
    label: 'Non renseigné',
    containerClass: 'bg-bg text-ink-muted border-border',
    shapeColorClass: 'text-ink-muted',
  },
};

export function StatusShapeSvg({
  status,
  size = 12,
  className = '',
}: {
  status: HealthStatus;
  size?: number;
  className?: string;
}) {
  if (status === 'ok') {
    // Disque plein
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 16 16"
        aria-hidden="true"
        className={`shrink-0 ${className}`}
      >
        <circle cx="8" cy="8" r="6" fill="currentColor" />
      </svg>
    );
  }
  if (status === 'vigilance') {
    // Triangle plein
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 16 16"
        aria-hidden="true"
        className={`shrink-0 ${className}`}
      >
        <polygon points="8,2 15,14 1,14" fill="currentColor" />
      </svg>
    );
  }
  if (status === 'alerte') {
    // Octogone plein
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 16 16"
        aria-hidden="true"
        className={`shrink-0 ${className}`}
      >
        <polygon
          points="5.2,1.5 10.8,1.5 14.5,5.2 14.5,10.8 10.8,14.5 5.2,14.5 1.5,10.8 1.5,5.2"
          fill="currentColor"
        />
      </svg>
    );
  }
  // Tiret épais horizontal (Pas de donnée)
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 16 16"
      aria-hidden="true"
      className={`shrink-0 ${className}`}
    >
      <rect x="2" y="6.5" width="12" height="3" rx="1" fill="currentColor" />
    </svg>
  );
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  customLabel,
  compact = false,
}) => {
  const meta = STATUS_META[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 border rounded-sm font-medium ${
        compact ? 'px-2 py-0.5 text-14' : 'px-2.5 py-1 text-14'
      } ${meta.containerClass}`}
    >
      <StatusShapeSvg status={status} size={12} className={meta.shapeColorClass} />
      <span>{customLabel ?? meta.label}</span>
    </span>
  );
};
