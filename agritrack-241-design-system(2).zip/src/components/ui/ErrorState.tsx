import React from 'react';
import { AlertOctagon, RefreshCw } from 'lucide-react';
import { Button } from './Button';

export interface ErrorStateProps {
  title: string;
  correctionInstruction: string;
  actionLabel?: string;
  onAction?: () => void;
  mode?: 'bureau' | 'terrain';
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  title,
  correctionInstruction,
  actionLabel = 'Corriger la saisie',
  onAction,
  mode = 'bureau',
}) => {
  return (
    <div
      role="alert"
      className="flex flex-col gap-3 rounded-sm border border-red-700 bg-red-50 p-4"
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-sm border border-red-700 bg-surface text-red-700">
          <AlertOctagon size={16} strokeWidth={1.75} aria-hidden="true" />
        </div>
        <div className="flex flex-col gap-1">
          <h3 className="text-16 font-semibold text-red-700">{title}</h3>
          <p className="text-14 text-ink tabular-nums">{correctionInstruction}</p>
        </div>
      </div>

      {onAction && (
        <div className="pl-11">
          <Button
            variant="secondary"
            size={mode}
            icon={RefreshCw}
            onClick={onAction}
          >
            {actionLabel}
          </Button>
        </div>
      )}
    </div>
  );
};
