import React from 'react';
import { AlertOctagon } from 'lucide-react';

export interface FieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  id: string;
  label: string;
  unit?: string;
  hint?: string;
  error?: string;
  mode?: 'bureau' | 'terrain';
  requiredLabel?: boolean;
}

export const Field: React.FC<FieldProps> = ({
  id,
  label,
  unit,
  hint,
  error,
  mode = 'bureau',
  requiredLabel = false,
  className = '',
  ...inputProps
}) => {
  const isTerrain = mode === 'terrain';

  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      <div className="flex items-baseline justify-between gap-2">
        <label
          htmlFor={id}
          className={`${isTerrain ? 'text-16 font-semibold' : 'text-14 font-medium'} text-ink`}
        >
          {label}
          {requiredLabel && (
            <span className="ml-1.5 text-14 font-regular text-ink-muted">(obligatoire)</span>
          )}
        </label>
        {hint && <span className="text-14 text-ink-muted tabular-nums">{hint}</span>}
      </div>

      <div className="relative flex items-center">
        <input
          id={id}
          aria-invalid={Boolean(error)}
          aria-describedby={error ? `${id}-error` : hint ? `${id}-hint` : undefined}
          className={`w-full bg-surface text-ink border rounded-sm transition-colors duration-150 tabular-nums ${
            isTerrain
              ? 'min-h-[3.25rem] px-3.5 py-2.5 text-18 font-medium'
              : 'min-h-[2.5rem] px-3 py-1.5 text-14 font-regular'
          } ${unit ? 'pr-14' : ''} ${
            error
              ? 'border-red-700 bg-red-50/40'
              : 'border-border focus:border-blue-700'
          }`}
          {...inputProps}
        />
        {unit && (
          <span
            className={`pointer-events-none absolute right-3 select-none text-ink-muted ${
              isTerrain ? 'text-16 font-regular' : 'text-14 font-regular'
            }`}
          >
            {unit}
          </span>
        )}
      </div>

      {error && (
        <div
          id={`${id}-error`}
          role="alert"
          className="flex items-start gap-2 rounded-sm border border-red-700 bg-red-50 px-3 py-2 text-14 text-red-700"
        >
          <AlertOctagon size={16} strokeWidth={1.75} className="mt-0.5 shrink-0" aria-hidden="true" />
          <span className="font-medium">{error}</span>
        </div>
      )}
    </div>
  );
};
