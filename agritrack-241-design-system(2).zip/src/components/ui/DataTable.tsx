import React, { useMemo, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Download,
} from 'lucide-react';
import type { HealthStatus } from '../../types/domain';
import { CodeCopyBadge } from './CodeCopyBadge';
import { EmptyState } from './EmptyState';
import { StatusBadge } from './StatusBadge';
import { Button } from './Button';
import { formatInt } from '../../utils/formatters';

export interface DataTableColumn<T> {
  key: string;
  header: string;
  unit?: string;
  align?: 'left' | 'right';
  sortable?: boolean;
  sortAccessor?: (row: T) => string | number;
  render: (row: T) => React.ReactNode;
  csvAccessor?: (row: T) => string | number;
  widthClass?: string;
}

export interface DataTableProps<T> {
  caption: string;
  sourceLabel?: string;
  data: T[];
  columns: DataTableColumn<T>[];
  getRowId: (row: T) => string;
  getRowStatus?: (row: T) => HealthStatus;
  onRowClick?: (row: T) => void;
  loading?: boolean;
  emptyTitle?: string;
  emptyDescription?: string;
  onResetFilters?: () => void;
  pageSize?: number;
  enableVirtualizationOption?: boolean;
  exportFileName?: string;
  onCopiedCode?: (code: string) => void;
}

export function DataTable<T>({
  caption,
  sourceLabel,
  data,
  columns,
  getRowId,
  getRowStatus,
  onRowClick,
  loading = false,
  emptyTitle = 'Aucun enregistrement ne correspond aux filtres actifs.',
  emptyDescription = 'Modifiez la province, la cohorte ou le statut sélectionné pour afficher les bandes suivies.',
  onResetFilters,
  pageSize = 15,
  enableVirtualizationOption = true,
  exportFileName = 'agritrack241-export.csv',
  onCopiedCode,
}: DataTableProps<T>) {
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const [virtualMode, setVirtualMode] = useState(false);
  const [scrollTop, setScrollTop] = useState(0);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const handleSort = (col: DataTableColumn<T>) => {
    if (!col.sortable) return;
    if (sortKey === col.key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(col.key);
      setSortDir('asc');
    }
    setPage(1);
  };

  const sortedData = useMemo(() => {
    if (!sortKey) return data;
    const col = columns.find((c) => c.key === sortKey);
    if (!col || !col.sortAccessor) return data;
    const accessor = col.sortAccessor;
    return [...data].sort((a, b) => {
      const va = accessor(a);
      const vb = accessor(b);
      if (typeof va === 'number' && typeof vb === 'number') {
        return sortDir === 'asc' ? va - vb : vb - va;
      }
      return sortDir === 'asc'
        ? String(va).localeCompare(String(vb), 'fr')
        : String(vb).localeCompare(String(va), 'fr');
    });
  }, [data, columns, sortKey, sortDir]);

  const isVirtualized = virtualMode && sortedData.length > 100;
  const totalPages = Math.max(1, Math.ceil(sortedData.length / pageSize));
  const safePage = Math.min(page, totalPages);

  const paginatedRows = useMemo(() => {
    if (isVirtualized) return sortedData;
    const start = (safePage - 1) * pageSize;
    return sortedData.slice(start, start + pageSize);
  }, [sortedData, safePage, pageSize, isVirtualized]);

  // Paramètres de virtualisation (hauteur de ligne 40 px stricte)
  const ROW_HEIGHT = 40;
  const VIEWPORT_HEIGHT = 480;
  const totalVirtualHeight = sortedData.length * ROW_HEIGHT;
  const startIndex = isVirtualized ? Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - 4) : 0;
  const endIndex = isVirtualized
    ? Math.min(sortedData.length, Math.ceil((scrollTop + VIEWPORT_HEIGHT) / ROW_HEIGHT) + 4)
    : paginatedRows.length;
  const visibleRows = isVirtualized
    ? sortedData.slice(startIndex, endIndex)
    : paginatedRows;

  const handleExportCsv = () => {
    const headers = [
      'Identifiant',
      ...(getRowStatus ? ['Statut'] : []),
      ...columns.map((c) => (c.unit ? `${c.header} (${c.unit})` : c.header)),
    ];
    const lines = sortedData.map((row) => {
      const id = getRowId(row);
      const st = getRowStatus ? getRowStatus(row) : undefined;
      const cells = columns.map((c) => {
        const raw = c.csvAccessor ? c.csvAccessor(row) : '';
        return `"${String(raw).replace(/"/g, '""')}"`;
      });
      return [`"${id}"`, ...(st ? [`"${st}"`] : []), ...cells].join(';');
    });
    const csvContent = '\uFEFF' + [headers.join(';'), ...lines].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = exportFileName;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col rounded-sm border border-border bg-surface">
      {/* Barre supérieure du tableau : titre, compteur, bascule virtualisation > 100 lignes, export CSV */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-2">
            <h3 className="text-16 font-semibold text-ink">{caption}</h3>
            <span className="rounded-sm border border-border bg-bg px-2 py-0.5 text-14 font-medium text-ink-muted tabular-nums">
              {formatInt(sortedData.length)} {sortedData.length > 1 ? 'lignes' : 'ligne'}
            </span>
          </div>
          {sourceLabel && (
            <p className="text-14 text-ink-muted tabular-nums">{sourceLabel}</p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {enableVirtualizationOption && sortedData.length > 100 && (
            <button
              type="button"
              onClick={() => setVirtualMode((v) => !v)}
              className={`min-h-[2.5rem] rounded-sm border px-3 py-1.5 text-14 font-medium transition-colors duration-150 cursor-pointer ${
                virtualMode
                  ? 'border-blue-700 bg-blue-50 text-blue-700'
                  : 'border-border bg-surface text-ink hover:bg-bg'
              }`}
            >
              {virtualMode
                ? `Liste virtualisée active (${formatInt(sortedData.length)} lignes)`
                : `Afficher les ${formatInt(sortedData.length)} lignes (virtualisé)`}
            </button>
          )}

          <Button
            variant="secondary"
            size="bureau"
            icon={Download}
            onClick={handleExportCsv}
            disabled={loading || sortedData.length === 0}
          >
            Exporter CSV
          </Button>
        </div>
      </div>

      {/* Corps du tableau : état chargement (squelette exact), état vide ou lignes de 40 px */}
      {loading ? (
        <div className="overflow-x-auto" aria-busy="true" aria-label="Chargement des données du tableau">
          <table className="w-full border-collapse text-left text-14">
            <thead className="border-b border-border bg-bg text-ink-muted">
              <tr className="h-10">
                <th className="px-3 font-semibold">Identifiant & État</th>
                {columns.map((col) => (
                  <th
                    key={col.key}
                    className={`px-3 font-semibold ${
                      col.align === 'right' ? 'text-right' : 'text-left'
                    }`}
                  >
                    <span>{col.header}</span>
                    {col.unit && (
                      <span className="ml-1 font-regular text-ink-muted">({col.unit})</span>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {Array.from({ length: 8 }).map((_, rIdx) => (
                <tr key={rIdx} className="h-10">
                  <td className="px-3">
                    <div className="flex items-center gap-2">
                      <span className="inline-block h-5 w-24 rounded-sm bg-bg" />
                      <span className="inline-block h-5 w-20 rounded-sm bg-bg" />
                    </div>
                  </td>
                  {columns.map((col) => (
                    <td
                      key={col.key}
                      className={`px-3 ${col.align === 'right' ? 'text-right' : 'text-left'}`}
                    >
                      <span
                        className={`inline-block h-4 rounded-sm bg-bg ${
                          col.align === 'right' ? 'w-16' : 'w-28'
                        }`}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : sortedData.length === 0 ? (
        <div className="p-4">
          <EmptyState
            title={emptyTitle}
            description={emptyDescription}
            actionLabel={onResetFilters ? 'Réinitialiser les filtres' : undefined}
            onAction={onResetFilters}
          />
        </div>
      ) : (
        <div
          ref={scrollContainerRef}
          onScroll={(e) => {
            if (isVirtualized) {
              setScrollTop(e.currentTarget.scrollTop);
            }
          }}
          className={`overflow-x-auto ${
            isVirtualized ? 'max-h-[30rem] overflow-y-auto' : ''
          }`}
        >
          <table className="w-full border-collapse text-left text-14 tabular-nums">
            <thead className="sticky top-0 z-10 border-b border-border bg-bg text-ink">
              <tr className="h-10">
                <th scope="col" className="whitespace-nowrap px-3 font-semibold">
                  Identifiant & État
                </th>
                {columns.map((col) => {
                  const isSorted = sortKey === col.key;
                  return (
                    <th
                      key={col.key}
                      scope="col"
                      aria-sort={
                        isSorted
                          ? sortDir === 'asc'
                            ? 'ascending'
                            : 'descending'
                          : 'none'
                      }
                      className={`whitespace-nowrap px-3 font-semibold ${
                        col.align === 'right' ? 'text-right' : 'text-left'
                      } ${col.widthClass ?? ''}`}
                    >
                      {col.sortable ? (
                        <button
                          type="button"
                          onClick={() => handleSort(col)}
                          className={`inline-flex items-center gap-1 rounded-sm py-1 hover:text-blue-700 cursor-pointer ${
                            col.align === 'right' ? 'ml-auto' : ''
                          }`}
                        >
                          <span>{col.header}</span>
                          {col.unit && (
                            <span className="font-regular text-ink-muted">({col.unit})</span>
                          )}
                          {isSorted ? (
                            sortDir === 'asc' ? (
                              <ArrowUp size={16} strokeWidth={1.75} className="text-blue-700" aria-hidden="true" />
                            ) : (
                              <ArrowDown size={16} strokeWidth={1.75} className="text-blue-700" aria-hidden="true" />
                            )
                          ) : (
                            <ArrowUpDown size={16} strokeWidth={1.75} className="text-ink-muted" aria-hidden="true" />
                          )}
                        </button>
                      ) : (
                        <span>
                          {col.header}
                          {col.unit && (
                            <span className="ml-1 font-regular text-ink-muted">({col.unit})</span>
                          )}
                        </span>
                      )}
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isVirtualized && startIndex > 0 && (
                <tr style={{ height: `${startIndex * ROW_HEIGHT}px` }} aria-hidden="true">
                  <td colSpan={columns.length + 1} />
                </tr>
              )}

              {visibleRows.map((row) => {
                const rowId = getRowId(row);
                const status = getRowStatus ? getRowStatus(row) : undefined;
                const hasProblem = status === 'alerte' || status === 'vigilance';

                return (
                  <tr
                    key={rowId}
                    onClick={onRowClick ? () => onRowClick(row) : undefined}
                    className={`h-10 transition-colors duration-150 ${
                      onRowClick ? 'cursor-pointer hover:bg-blue-50/60' : 'hover:bg-bg/60'
                    } ${hasProblem ? 'bg-orange-50/20' : ''}`}
                  >
                    <td className="whitespace-nowrap px-3 py-1">
                      <div className="flex items-center gap-2">
                        {status && <StatusBadge status={status} compact />}
                        <CodeCopyBadge
                          code={rowId}
                          compact
                          onCopied={onCopiedCode}
                        />
                      </div>
                    </td>
                    {columns.map((col) => (
                      <td
                        key={col.key}
                        className={`whitespace-nowrap px-3 py-1 tabular-nums ${
                          col.align === 'right'
                            ? 'text-right font-medium'
                            : 'text-left'
                        }`}
                      >
                        {col.render(row)}
                      </td>
                    ))}
                  </tr>
                );
              })}

              {isVirtualized && endIndex < sortedData.length && (
                <tr
                  style={{ height: `${totalVirtualHeight - endIndex * ROW_HEIGHT}px` }}
                  aria-hidden="true"
                >
                  <td colSpan={columns.length + 1} />
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Pied de tableau : pagination sobre */}
      {!loading && sortedData.length > 0 && !isVirtualized && (
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border bg-bg px-4 py-2.5 text-14 tabular-nums">
          <span className="text-ink-muted">
            Affichage de{' '}
            <strong className="font-semibold text-ink">
              {formatInt((safePage - 1) * pageSize + 1)}
            </strong>{' '}
            à{' '}
            <strong className="font-semibold text-ink">
              {formatInt(Math.min(safePage * pageSize, sortedData.length))}
            </strong>{' '}
            sur <strong className="font-semibold text-ink">{formatInt(sortedData.length)}</strong>
          </span>

          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              size="bureau"
              icon={ChevronLeft}
              disabled={safePage <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              Précédent
            </Button>
            <span className="px-2 font-medium text-ink tabular-nums">
              Page {formatInt(safePage)} / {formatInt(totalPages)}
            </span>
            <Button
              variant="secondary"
              size="bureau"
              icon={ChevronRight}
              iconPosition="right"
              disabled={safePage >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            >
              Suivant
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
