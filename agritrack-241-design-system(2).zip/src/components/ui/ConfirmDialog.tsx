import React, { useEffect } from 'react';
import { Check, X } from 'lucide-react';
import { Button } from './Button';

export interface ConfirmDialogProps {
  isOpen: boolean;
  title: string;
  description: string;
  summaryItems?: { label: string; value: string }[];
  confirmLabel: string;
  cancelLabel?: string;
  variant?: 'primary' | 'danger';
  mode?: 'bureau' | 'terrain';
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  isOpen,
  title,
  description,
  summaryItems,
  confirmLabel,
  cancelLabel = 'Annuler',
  variant = 'primary',
  mode = 'bureau',
  onConfirm,
  onCancel,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onCancel();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onCancel]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/35 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-dialog-title"
    >
      <div className="fixed inset-0" onClick={onCancel} aria-hidden="true" />
      <div className="relative z-10 w-full max-w-md rounded-md border border-border bg-surface shadow-floating">
        <div className="tricolor-bar" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>
        <div className="flex flex-col gap-4 p-6">
          <div className="flex flex-col gap-1.5">
            <h2 id="confirm-dialog-title" className="text-20 font-semibold text-ink">
              {title}
            </h2>
            <p className="text-14 text-ink-muted">{description}</p>
          </div>

          {summaryItems && summaryItems.length > 0 && (
            <dl className="divide-y divide-border rounded-sm border border-border bg-bg px-3.5 py-2">
              {summaryItems.map((item) => (
                <div
                  key={item.label}
                  className="flex items-baseline justify-between gap-4 py-1.5 text-14 tabular-nums"
                >
                  <dt className="text-ink-muted">{item.label}</dt>
                  <dd className="font-semibold text-ink tabular-nums">{item.value}</dd>
                </div>
              ))}
            </dl>
          )}

          <div className="flex flex-wrap items-center justify-end gap-2 pt-2">
            <Button
              variant="secondary"
              size={mode}
              icon={X}
              onClick={onCancel}
            >
              {cancelLabel}
            </Button>
            <Button
              variant={variant}
              size={mode}
              icon={Check}
              onClick={onConfirm}
            >
              {confirmLabel}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
