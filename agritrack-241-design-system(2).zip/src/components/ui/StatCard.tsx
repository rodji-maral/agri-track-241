import React from 'react';
import type { HealthStatus } from '../../types/domain';
import { StatusBadge } from './StatusBadge';

export interface StatCardProps {
  label: string;
  value: string;
  unit?: string;
  variation?: string;
  period?: string;
  updatedAt: string;
  status?: HealthStatus;
  size?: 'compact' | 'large';
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  unit,
  variation,
  period,
  updatedAt,
  status,
  size = 'compact',
}) => {
  return (
    <article className="flex flex-col justify-between gap-2 rounded-sm border border-border bg-surface p-4">
      <div className="flex items-start justify-between gap-2">
        <span className="text-14 font-medium text-ink-muted">{label}</span>
        {status && <StatusBadge status={status} compact />}
      </div>

      <div className="flex items-baseline gap-1.5 tabular-nums">
        <span
          className={`${
            size === 'large' ? 'text-32' : 'text-24'
          } font-semibold text-ink tabular-nums`}
        >
          {value}
        </span>
        {unit && (
          <span className="text-14 font-regular text-ink-muted">{unit}</span>
        )}
      </div>

      {(variation || period) && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-14 tabular-nums">
          {variation && <span className="font-medium text-ink">{variation}</span>}
          {period && <span className="text-ink-muted">{period}</span>}
        </div>
      )}

      <div className="border-t border-border pt-2 text-14 text-ink-muted tabular-nums">
        Maj : {updatedAt}
      </div>
    </article>
  );
};
