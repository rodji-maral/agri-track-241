import React from 'react';
import type { LucideIcon } from 'lucide-react';

export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';
export type ButtonSize = 'bureau' | 'terrain';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: LucideIcon;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  children: React.ReactNode;
}

const VARIANT_CLASSES: Record<ButtonVariant, string> = {
  primary:
    'bg-green-700 text-surface border-green-700 hover:bg-green-600 active:bg-green-700 disabled:bg-border disabled:text-ink-muted disabled:border-border',
  secondary:
    'bg-surface text-ink border-border hover:bg-bg active:bg-green-50 disabled:bg-bg disabled:text-ink-muted',
  danger:
    'bg-red-700 text-surface border-red-700 hover:bg-red-700/90 active:bg-red-700 disabled:bg-border disabled:text-ink-muted disabled:border-border',
  ghost:
    'bg-transparent text-ink border-transparent hover:bg-bg active:bg-green-50 disabled:text-ink-muted',
};

const SIZE_CLASSES: Record<ButtonSize, string> = {
  bureau: 'min-h-[2.5rem] px-3.5 py-1.5 text-14 font-medium',
  terrain: 'min-h-[3.25rem] px-4 py-2.5 text-16 font-semibold',
};

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'bureau',
  icon: Icon,
  iconPosition = 'left',
  fullWidth = false,
  className = '',
  children,
  type = 'button',
  ...rest
}) => {
  return (
    <button
      type={type}
      className={`inline-flex items-center justify-center gap-2 border rounded-sm transition-colors duration-150 active:translate-y-[1px] cursor-pointer disabled:cursor-not-allowed select-none ${
        VARIANT_CLASSES[variant]
      } ${SIZE_CLASSES[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...rest}
    >
      {Icon && iconPosition === 'left' && (
        <Icon size={20} strokeWidth={1.75} aria-hidden="true" className="shrink-0" />
      )}
      <span>{children}</span>
      {Icon && iconPosition === 'right' && (
        <Icon size={20} strokeWidth={1.75} aria-hidden="true" className="shrink-0" />
      )}
    </button>
  );
};
