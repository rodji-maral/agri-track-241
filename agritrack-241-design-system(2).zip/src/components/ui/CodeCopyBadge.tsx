import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

export interface CodeCopyBadgeProps {
  code: string;
  compact?: boolean;
  onCopied?: (code: string) => void;
}

export const CodeCopyBadge: React.FC<CodeCopyBadgeProps> = ({
  code,
  compact = false,
  onCopied,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      // Repli si clipboard API restreinte
    }
    setCopied(true);
    onCopied?.(code);
    window.setTimeout(() => setCopied(false), 1500);
  };

  return (
    <span className="inline-flex items-center gap-1.5 rounded-sm border border-border bg-bg px-2 py-0.5 font-mono text-14 font-medium text-ink tabular-nums">
      <span className="tracking-tight">{code}</span>
      <button
        type="button"
        onClick={handleCopy}
        aria-label={`Copier l'identifiant ${code}`}
        className={`inline-flex items-center gap-1 rounded-sm px-1.5 py-0.5 text-14 font-medium transition-colors duration-150 cursor-pointer ${
          copied
            ? 'bg-green-100 text-green-700'
            : 'text-blue-700 hover:bg-blue-50'
        }`}
      >
        {copied ? (
          <>
            <Check size={16} strokeWidth={1.75} aria-hidden="true" />
            <span>Copié</span>
          </>
        ) : (
          <>
            <Copy size={16} strokeWidth={1.75} aria-hidden="true" />
            {!compact && <span>Copier</span>}
            {compact && <span className="sr-only">Copier</span>}
          </>
        )}
      </button>
    </span>
  );
};
