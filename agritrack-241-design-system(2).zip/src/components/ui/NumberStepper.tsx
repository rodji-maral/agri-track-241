import React from 'react';
import { Minus, Plus, RotateCcw, Delete } from 'lucide-react';
import { formatInt } from '../../utils/formatters';

export interface NumberStepperProps {
  id: string;
  label: string;
  value: number | null;
  onChange: (nextValue: number | null) => void;
  unit: string;
  yesterdayValue?: number;
  yesterdayLabel?: string;
  min?: number;
  max?: number;
  step?: number;
  error?: string;
  showKeypad?: boolean;
}

export const NumberStepper: React.FC<NumberStepperProps> = ({
  id,
  label,
  value,
  onChange,
  unit,
  yesterdayValue,
  yesterdayLabel = 'Hier',
  min = 0,
  max = 99999,
  step = 1,
  error,
  showKeypad = true,
}) => {
  const numericVal = value ?? 0;

  const handleStep = (delta: number) => {
    const next = Math.max(min, Math.min(max, numericVal + delta));
    onChange(next);
  };

  const handleDigitPress = (digit: number) => {
    const currentStr = value === null || value === 0 ? '' : String(value);
    const nextStr = `${currentStr}${digit}`;
    const parsed = Number(nextStr);
    if (!Number.isNaN(parsed) && parsed <= max) {
      onChange(parsed);
    }
  };

  const handleBackspace = () => {
    if (value === null) return;
    const str = String(value);
    if (str.length <= 1) {
      onChange(0);
    } else {
      onChange(Number(str.slice(0, -1)));
    }
  };

  return (
    <div className="flex flex-col gap-3 rounded-md border border-border bg-surface p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <label htmlFor={id} className="text-18 font-semibold text-ink">
          {label}
        </label>
        {yesterdayValue !== undefined && (
          <button
            type="button"
            onClick={() => onChange(yesterdayValue)}
            className="inline-flex min-h-[2.5rem] items-center gap-1.5 rounded-sm border border-border bg-bg px-3 py-1 text-14 font-medium text-ink hover:bg-green-50 active:translate-y-[1px] cursor-pointer"
          >
            <RotateCcw size={16} strokeWidth={1.75} aria-hidden="true" />
            <span>
              {yesterdayLabel} : <strong className="font-semibold tabular-nums">{formatInt(yesterdayValue)}</strong> {unit}
            </span>
          </button>
        )}
      </div>

      {/* Contrôle principal − / Valeur / + */}
      <div className="grid grid-cols-[3.5rem_1fr_3.5rem] items-stretch gap-2">
        <button
          type="button"
          onClick={() => handleStep(-step)}
          disabled={numericVal <= min}
          aria-label={`Diminuer de ${step} ${unit}`}
          className="flex min-h-[3.5rem] items-center justify-center rounded-sm border border-border bg-bg text-ink hover:bg-green-50 active:translate-y-[1px] disabled:opacity-40 cursor-pointer"
        >
          <Minus size={20} strokeWidth={1.75} aria-hidden="true" />
          <span className="sr-only">Moins</span>
        </button>

        <div
          id={id}
          role="spinbutton"
          aria-valuenow={value ?? undefined}
          aria-valuemin={min}
          aria-valuemax={max}
          tabIndex={0}
          className={`flex min-h-[3.5rem] items-baseline justify-center gap-2 rounded-sm border px-4 py-2 tabular-nums ${
            error ? 'border-red-700 bg-red-50' : 'border-border bg-bg/50'
          }`}
        >
          <span className="text-32 font-semibold text-ink tabular-nums">
            {value === null ? '—' : formatInt(value)}
          </span>
          <span className="text-16 font-regular text-ink-muted">{unit}</span>
        </div>

        <button
          type="button"
          onClick={() => handleStep(step)}
          disabled={numericVal >= max}
          aria-label={`Augmenter de ${step} ${unit}`}
          className="flex min-h-[3.5rem] items-center justify-center rounded-sm border border-green-700 bg-green-50 text-green-700 hover:bg-green-100 active:translate-y-[1px] disabled:opacity-40 cursor-pointer"
        >
          <Plus size={20} strokeWidth={1.75} aria-hidden="true" />
          <span className="sr-only">Plus</span>
        </button>
      </div>

      {error && (
        <div
          role="alert"
          className="rounded-sm border border-red-700 bg-red-50 px-3 py-2 text-14 font-medium text-red-700"
        >
          {error}
        </div>
      )}

      {/* Pavé numérique tactile rapide (cibles ≥ 48 px) */}
      {showKeypad && (
        <div className="grid grid-cols-4 gap-1.5 pt-1" aria-label="Pavé numérique">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleDigitPress(digit)}
              className="flex min-h-[3rem] items-center justify-center rounded-sm border border-border bg-bg text-18 font-semibold text-ink tabular-nums hover:bg-green-50 active:translate-y-[1px] cursor-pointer"
            >
              {digit}
            </button>
          ))}
          <button
            type="button"
            onClick={() => onChange(0)}
            className="flex min-h-[3rem] items-center justify-center rounded-sm border border-border bg-surface text-14 font-medium text-ink-muted hover:bg-bg active:translate-y-[1px] cursor-pointer"
          >
            Zéro (0)
          </button>
          <button
            type="button"
            onClick={() => handleDigitPress(0)}
            className="flex min-h-[3rem] items-center justify-center rounded-sm border border-border bg-bg text-18 font-semibold text-ink tabular-nums hover:bg-green-50 active:translate-y-[1px] cursor-pointer"
          >
            0
          </button>
          <button
            type="button"
            onClick={handleBackspace}
            className="col-span-2 flex min-h-[3rem] items-center justify-center gap-1.5 rounded-sm border border-border bg-surface text-14 font-medium text-ink hover:bg-bg active:translate-y-[1px] cursor-pointer"
          >
            <Delete size={20} strokeWidth={1.75} aria-hidden="true" />
            <span>Corriger chiffre</span>
          </button>
        </div>
      )}
    </div>
  );
};
