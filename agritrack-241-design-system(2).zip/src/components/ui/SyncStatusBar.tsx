import React from 'react';
import { RefreshCw, Wifi, WifiOff } from 'lucide-react';
import { StatusShapeSvg } from './StatusBadge';
import { formatInt } from '../../utils/formatters';

export interface SyncStatusBarProps {
  isOnline: boolean;
  pendingCount: number;
  lastSyncedAt: string;
  onClick: () => void;
  compact?: boolean;
}

export const SyncStatusBar: React.FC<SyncStatusBarProps> = ({
  isOnline,
  pendingCount,
  lastSyncedAt,
  onClick,
  compact = false,
}) => {
  const status = !isOnline || pendingCount > 0 ? 'vigilance' : 'ok';

  return (
    <button
      type="button"
      onClick={onClick}
      aria-live="polite"
      title={`Dernière synchronisation : ${lastSyncedAt}. Cliquer pour ouvrir le journal d'envoi.`}
      className={`inline-flex min-h-[2.5rem] items-center gap-2 rounded-sm border px-3 py-1.5 text-14 font-medium transition-colors duration-150 active:translate-y-[1px] cursor-pointer tabular-nums ${
        !isOnline
          ? 'border-orange-600 bg-orange-50 text-ink hover:bg-orange-50/80'
          : pendingCount > 0
          ? 'border-orange-600 bg-orange-50 text-ink hover:bg-orange-50/80'
          : 'border-border bg-bg text-ink hover:bg-green-50'
      }`}
    >
      <StatusShapeSvg
        status={status}
        size={12}
        className={status === 'ok' ? 'text-green-700' : 'text-orange-600'}
      />

      {isOnline ? (
        <Wifi size={16} strokeWidth={1.75} className="text-green-700 shrink-0" aria-hidden="true" />
      ) : (
        <WifiOff size={16} strokeWidth={1.75} className="text-orange-600 shrink-0" aria-hidden="true" />
      )}

      <span className="tabular-nums">
        {!isOnline
          ? pendingCount > 0
            ? `Hors ligne · ${formatInt(pendingCount)} en attente`
            : 'Hors ligne · Stocké localement'
          : pendingCount > 0
          ? `En ligne · ${formatInt(pendingCount)} en attente`
          : 'En ligne · Synchronisé'}
      </span>

      {!compact && (
        <span className="hidden sm:inline-flex items-center gap-1 border-l border-border pl-2 text-14 text-ink-muted">
          <RefreshCw size={16} strokeWidth={1.75} aria-hidden="true" />
          <span>Détail</span>
        </span>
      )}
    </button>
  );
};
