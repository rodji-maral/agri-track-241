import React from 'react';
import type { HealthStatus } from '../../types/domain';
import { StatusShapeSvg } from './StatusBadge';

export interface TimelineItem {
  id: string;
  title: string;
  date?: string;
  subtitle?: string;
  description?: string;
  status: HealthStatus;
  active?: boolean;
  completed?: boolean;
}

export interface TimelineProps {
  items: TimelineItem[];
  orientation?: 'horizontal' | 'vertical';
}

export const Timeline: React.FC<TimelineProps> = ({
  items,
  orientation = 'vertical',
}) => {
  if (orientation === 'horizontal') {
    return (
      <ol
        aria-label="Progression du statut"
        className="grid grid-cols-1 gap-2 sm:grid-cols-4"
      >
        {items.map((item, idx) => {
          const isCurrent = item.active;
          const isDone = item.completed;
          return (
            <li
              key={item.id}
              className={`flex flex-col justify-between gap-1.5 rounded-sm border p-3 ${
                isCurrent
                  ? 'border-blue-700 bg-blue-50'
                  : isDone
                  ? 'border-green-700/40 bg-green-50/50'
                  : 'border-border bg-bg/60'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-14 font-semibold text-ink tabular-nums">
                  {idx + 1}. {item.title}
                </span>
                <StatusShapeSvg
                  status={item.status}
                  size={12}
                  className={
                    item.status === 'ok'
                      ? 'text-green-700'
                      : item.status === 'vigilance'
                      ? 'text-orange-600'
                      : item.status === 'alerte'
                      ? 'text-red-700'
                      : 'text-ink-muted'
                  }
                />
              </div>
              {item.date ? (
                <span className="text-14 text-ink-muted tabular-nums">{item.date}</span>
              ) : (
                <span className="text-14 text-ink-muted">En attente</span>
              )}
              {item.subtitle && (
                <span className="text-14 font-medium text-ink">{item.subtitle}</span>
              )}
            </li>
          );
        })}
      </ol>
    );
  }

  return (
    <ol className="relative flex flex-col gap-3 border-l border-border pl-4 ml-2">
      {items.map((item) => (
        <li key={item.id} className="relative flex flex-col gap-1 rounded-sm border border-border bg-surface p-3">
          <span
            aria-hidden="true"
            className="absolute -left-[1.45rem] top-3.5 flex h-4 w-4 items-center justify-center rounded-sm border border-border bg-surface"
          >
            <StatusShapeSvg
              status={item.status}
              size={10}
              className={
                item.status === 'ok'
                  ? 'text-green-700'
                  : item.status === 'vigilance'
                  ? 'text-orange-600'
                  : item.status === 'alerte'
                  ? 'text-red-700'
                  : 'text-ink-muted'
              }
            />
          </span>

          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h4 className="text-16 font-semibold text-ink">{item.title}</h4>
            {item.date && (
              <span className="text-14 font-medium text-ink-muted tabular-nums">
                {item.date}
              </span>
            )}
          </div>

          {item.subtitle && (
            <p className="text-14 font-medium text-ink">{item.subtitle}</p>
          )}
          {item.description && (
            <p className="text-14 text-ink-muted">{item.description}</p>
          )}
        </li>
      ))}
    </ol>
  );
};
