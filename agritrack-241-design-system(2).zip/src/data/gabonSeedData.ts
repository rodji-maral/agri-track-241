import type {
  DailyLogEntry,
  FarmRecord,
  HealthStatus,
  ProphylaxisStep,
  ProvinceGabon,
  PublicQrLotData,
  SanitaryAlert,
} from '../types/domain';

export const PROVINCES_GABON: ProvinceGabon[] = [
  'Estuaire',
  'Haut-Ogooué',
  'Ogooué-Maritime',
  'Woleu-Ntem',
  'Moyen-Ogooué',
  'Ngounié',
  'Nyanga',
  'Ogooué-Ivindo',
  'Ogooué-Lolo',
];

export const INITIAL_DAILY_LOGS_EST0014: DailyLogEntry[] = [
  {
    id: 'EST-0014-B03-J16',
    bandeCode: 'EST-0014-B03',
    dayNumber: 16,
    dateIso: '2026-10-30',
    dateLabel: '30 oct. 2026',
    mortalite: 2,
    alimentKg: 172,
    effectifPresent: 2450,
    synced: true,
    updatedAt: '30 oct. 2026 à 18:05',
  },
  {
    id: 'EST-0014-B03-J17',
    bandeCode: 'EST-0014-B03',
    dayNumber: 17,
    dateIso: '2026-10-31',
    dateLabel: '31 oct. 2026',
    mortalite: 3,
    alimentKg: 180,
    effectifPresent: 2447,
    synced: true,
    updatedAt: '31 oct. 2026 à 17:52',
  },
  {
    id: 'EST-0014-B03-J18',
    bandeCode: 'EST-0014-B03',
    dayNumber: 18,
    dateIso: '2026-11-01',
    dateLabel: '1 nov. 2026',
    mortalite: 2,
    alimentKg: 188,
    effectifPresent: 2445,
    synced: true,
    updatedAt: '1 nov. 2026 à 18:10',
  },
  {
    id: 'EST-0014-B03-J19',
    bandeCode: 'EST-0014-B03',
    dayNumber: 19,
    dateIso: '2026-11-02',
    dateLabel: '2 nov. 2026',
    mortalite: 1,
    alimentKg: 196,
    effectifPresent: 2444,
    synced: true,
    updatedAt: '2 nov. 2026 à 18:02',
  },
  {
    id: 'EST-0014-B03-J20',
    bandeCode: 'EST-0014-B03',
    dayNumber: 20,
    dateIso: '2026-11-03',
    dateLabel: '3 nov. 2026',
    mortalite: 3,
    alimentKg: 205,
    effectifPresent: 2441,
    synced: true,
    updatedAt: '3 nov. 2026 à 17:48',
  },
  {
    id: 'EST-0014-B03-J21',
    bandeCode: 'EST-0014-B03',
    dayNumber: 21,
    dateIso: '2026-11-04',
    dateLabel: '4 nov. 2026',
    mortalite: 2,
    alimentKg: 214,
    effectifPresent: 2439,
    poidsMoyenG: 940,
    observation: 'Pesée hebdomadaire S3 effectuée sur 100 sujets (lot homogène CV 8,4 %).',
    synced: true,
    updatedAt: '4 nov. 2026 à 18:20',
  },
  {
    id: 'EST-0014-B03-J22',
    bandeCode: 'EST-0014-B03',
    dayNumber: 22,
    dateIso: '2026-11-05',
    dateLabel: '5 nov. 2026',
    mortalite: 3,
    alimentKg: 222,
    effectifPresent: 2436,
    synced: true,
    updatedAt: '5 nov. 2026 à 18:14',
  },
];

export const INITIAL_PROPHYLAXIS_EST0014: ProphylaxisStep[] = [
  {
    id: 'PROPH-J1',
    dayNumber: 1,
    dateLabel: '15 oct. 2026',
    vaccineOrCare: 'Newcastle (Hitchner B1) + Bronchite infectieuse H120',
    route: 'Nébulisation couvoir / mise en place',
    lotVaccin: 'CEVA-HB1-2608',
    completed: true,
    completedAt: '15 oct. 2026 à 09:30',
  },
  {
    id: 'PROPH-J7',
    dayNumber: 7,
    dateLabel: '21 oct. 2026',
    vaccineOrCare: 'Gumboro (Bursine 2 — 1re prise) + complexe vitaminé AD3E',
    route: 'Eau de boisson (2 h après privation hydrique)',
    lotVaccin: 'MERIAL-GMB-991',
    completed: true,
    completedAt: '21 oct. 2026 à 07:15',
  },
  {
    id: 'PROPH-J14',
    dayNumber: 14,
    dateLabel: '28 oct. 2026',
    vaccineOrCare: 'Gumboro (Rappel souche intermédiaire)',
    route: 'Eau de boisson',
    lotVaccin: 'MERIAL-GMB-994',
    completed: true,
    completedAt: '28 oct. 2026 à 07:10',
  },
  {
    id: 'PROPH-J21',
    dayNumber: 21,
    dateLabel: '4 nov. 2026',
    vaccineOrCare: 'Newcastle (Rappel LaSota) + anticoccidien préventif',
    route: 'Eau de boisson',
    lotVaccin: 'CEVA-LAS-442',
    completed: true,
    completedAt: '4 nov. 2026 à 07:25',
  },
  {
    id: 'PROPH-J28',
    dayNumber: 28,
    dateLabel: '11 nov. 2026',
    vaccineOrCare: 'Hépato-protecteur & contrôle litière transition finition',
    route: 'Eau de boisson (3 jours)',
    lotVaccin: 'BIOGAB-HEP-112',
    completed: false,
  },
];

interface ProvinceSeedConfig {
  province: ProvinceGabon;
  prefix: string;
  count: number;
  baseLat: number;
  baseLng: number;
  localites: string[];
}

const PROVINCE_SEED_CONFIGS: ProvinceSeedConfig[] = [
  {
    province: 'Estuaire',
    prefix: 'EST',
    count: 42,
    baseLat: 0.4162,
    baseLng: 9.4673,
    localites: ['Nkok (ZES)', 'Akanda - Malibé', 'Owendo - Igoumié', 'Kango', 'Ntoum - Essassa', 'Cocobeach'],
  },
  {
    province: 'Haut-Ogooué',
    prefix: 'HOG',
    count: 26,
    baseLat: -1.6333,
    baseLng: 13.5836,
    localites: ['Franceville - Potos', 'Moanda', 'Mounana', 'Lékoni', 'Okondja', 'Bongoville'],
  },
  {
    province: 'Ogooué-Maritime',
    prefix: 'OGM',
    count: 18,
    baseLat: -0.7193,
    baseLng: 8.7815,
    localites: ['Port-Gentil - Ntchengué', 'Omboué', 'Gamba'],
  },
  {
    province: 'Woleu-Ntem',
    prefix: 'WNT',
    count: 20,
    baseLat: 1.5995,
    baseLng: 11.5793,
    localites: ['Oyem - Methui', 'Bitam - Nkolabona', 'Mitzic', 'Minvoul', 'Medouneu'],
  },
  {
    province: 'Moyen-Ogooué',
    prefix: 'MOG',
    count: 12,
    baseLat: -0.7001,
    baseLng: 10.2406,
    localites: ['Lambaréné - Isaac', 'Ndjolé', 'Bifoun'],
  },
  {
    province: 'Ngounié',
    prefix: 'NGO',
    count: 11,
    baseLat: -1.8685,
    baseLng: 11.0559,
    localites: ['Mouila - Doubou', 'Ndendé', 'Fougamou', 'Lébamba'],
  },
  {
    province: 'Nyanga',
    prefix: 'NYA',
    count: 8,
    baseLat: -2.9332,
    baseLng: 10.9818,
    localites: ['Tchibanga - Ibanga', 'Mayumba', 'Moabi'],
  },
  {
    province: 'Ogooué-Ivindo',
    prefix: 'OGI',
    count: 7,
    baseLat: 0.5738,
    baseLng: 12.8642,
    localites: ['Makokou - Epassengué', 'Booué', 'Mékambo'],
  },
  {
    province: 'Ogooué-Lolo',
    prefix: 'OLO',
    count: 6,
    baseLat: -1.1343,
    baseLng: 12.464,
    localites: ['Koulamoutou - Kougna', 'Lastoursville', 'Pana'],
  },
];

const FARMER_NAMES = [
  'Jean-Bosco Ndong Mba',
  'Sylvie Moussavou',
  'Patrice Obame Ella',
  'Clarisse Nzé Bekale',
  'Hilaire Bourobou',
  'Mireille Kombila',
  'Arsène Mba Allogho',
  'Prisca Ondo Mvé',
  'Landry Nkoghe Assoumou',
  'Nadège Mihindou',
  'Théophile Nzengui',
  'Paulette Maganga',
  'Dieudonné Ovono',
  'Chantal Ibinga',
  'Gervais Moukagni',
  'Séraphine Biyoghe',
  'Rodrigue Essono',
  'Brigitte Koumba',
  'Célestin Mayombo',
  'Raïssa Ntoutoume',
];

const FARM_NAME_PREFIXES = [
  'Ferme Avicole',
  'Exploitation POUFA',
  'Coopérative Avicole',
  'Unité de Chair',
  'Domaine Avicole',
];

function generateAll150Farms(): FarmRecord[] {
  const farms: FarmRecord[] = [];
  let globalIndex = 0;

  for (const cfg of PROVINCE_SEED_CONFIGS) {
    for (let i = 1; i <= cfg.count; i++) {
      globalIndex++;
      const numStr = String(i).padStart(4, '0');
      const code = `${cfg.prefix}-${numStr}`;
      const localite = cfg.localites[(i - 1) % cfg.localites.length];
      const prefixNom = FARM_NAME_PREFIXES[(globalIndex - 1) % FARM_NAME_PREFIXES.length];
      const shortLoc = localite.split(' - ')[0].replace(' (ZES)', '');
      const nom =
        code === 'EST-0014'
          ? 'Ferme Avicole Nkok-Sud'
          : `${prefixNom} ${shortLoc} ${i}`;

      const bandeNum = ((globalIndex % 5) + 1).toString().padStart(2, '0');
      const bandeActiveCode = `${code}-B${bandeNum}`;
      const lotActifCode = `${bandeActiveCode}-L01`;

      // Répartition réaliste des statuts : majorité OK, quelques vigilances, 4 alertes, 5 non renseignés
      let statut: HealthStatus = 'ok';
      let mortaliteCumuleePct = Number((1.4 + ((globalIndex * 7) % 24) * 0.1).toFixed(1));

      if (code === 'EST-0009' || code === 'HOG-0007' || code === 'WNT-0004' || code === 'OGM-0005') {
        statut = 'alerte';
        mortaliteCumuleePct = Number((6.4 + (globalIndex % 4) * 0.7).toFixed(1));
      } else if (globalIndex % 11 === 0 || globalIndex % 17 === 0) {
        statut = 'vigilance';
        mortaliteCumuleePct = Number((4.2 + (globalIndex % 3) * 0.4).toFixed(1));
      } else if (globalIndex % 29 === 0) {
        statut = 'none';
      }

      if (code === 'EST-0014') {
        statut = 'ok';
        mortaliteCumuleePct = 2.6;
      }

      const effectifInitial =
        code === 'EST-0014'
          ? 2500
          : 1000 + ((globalIndex * 3) % 7) * 500;

      const jourBande =
        code === 'EST-0014'
          ? 23
          : 7 + ((globalIndex * 5) % 36);

      const mortsCount = Math.round((effectifInitial * mortaliteCumuleePct) / 100);
      const effectifPresent = effectifInitial - mortsCount;

      const poidsMoyenG =
        code === 'EST-0014'
          ? 940
          : Math.round(160 + jourBande * 48 + ((globalIndex % 5) - 2) * 25);

      const indiceConsommation =
        code === 'EST-0014'
          ? 1.54
          : Number((1.48 + ((globalIndex * 3) % 35) * 0.01).toFixed(2));

      const alimentCumuleKg = Math.round((effectifPresent * poidsMoyenG * indiceConsommation) / 1000);
      const coutProductionFcfaKg = 1320 + ((globalIndex * 19) % 280);

      // Coordonnées dispersées autour du chef-lieu de province
      const angle = (i / cfg.count) * Math.PI * 2;
      const radius = 0.08 + ((i * 7) % 10) * 0.035;
      const lat = Number((cfg.baseLat + Math.sin(angle) * radius).toFixed(4));
      const lng = Number((cfg.baseLng + Math.cos(angle) * radius).toFixed(4));

      const cohorteOptions: FarmRecord['cohorte'][] = [
        'POUFA-2026-T4',
        'POUFA-2026-T3',
        'POUFA-2025-T4',
      ];
      const cohorte =
        code === 'EST-0014'
          ? 'POUFA-2026-T4'
          : cohorteOptions[globalIndex % cohorteOptions.length];

      const heures = ['06:45', '07:15', '07:40', '08:10', '17:50', '18:14'];
      const derniereMaj =
        statut === 'none'
          ? '1 nov. 2026 à 18:00'
          : code === 'EST-0014'
          ? '5 nov. 2026 à 18:14'
          : `6 nov. 2026 à ${heures[globalIndex % heures.length]}`;

      farms.push({
        code,
        nom,
        province: cfg.province,
        localite: code === 'EST-0014' ? 'Nkok (ZES)' : localite,
        responsable:
          code === 'EST-0014'
            ? 'Jean-Bosco Ndong Mba'
            : FARMER_NAMES[(globalIndex - 1) % FARMER_NAMES.length],
        cohorte,
        bandeActiveCode: code === 'EST-0014' ? 'EST-0014-B03' : bandeActiveCode,
        lotActifCode: code === 'EST-0014' ? 'EST-0014-B03-L01' : lotActifCode,
        souche: globalIndex % 4 === 0 ? 'Cobb 500' : 'Ross 308',
        jourBande,
        dureeCibleJours: 45,
        effectifInitial,
        effectifPresent,
        mortaliteCumuleePct,
        poidsMoyenG,
        indiceConsommation,
        alimentCumuleKg,
        coutProductionFcfaKg,
        statut,
        derniereMaj,
        lat,
        lng,
      });
    }
  }

  return farms;
}

export const INITIAL_FARMS_150: FarmRecord[] = generateAll150Farms();

export const INITIAL_SANITARY_ALERTS: SanitaryAlert[] = [
  {
    id: 'ALR-2026-089',
    fermeCode: 'EST-0009',
    fermeNom: 'Coopérative Avicole Owendo 9',
    bandeCode: 'EST-0009-B05',
    province: 'Estuaire',
    localite: 'Owendo - Igoumié',
    dateDeclaration: '6 nov. 2026 à 06:50',
    symptomes: [
      'Mortalité journalière > 1,5 %',
      'Râles respiratoires marqués',
      'Baisse brutale de consommation d’eau (-28 %)',
    ],
    mortalite24h: 48,
    mortalitePct24h: 2.1,
    effectifPresent: 2240,
    statutWorkflow: 'Nouvelle',
    gravite: 'alerte',
    veterinaireAssigne: 'Dr. Marc-Aurèle Obiang (Brigade Vétérinaire Estuaire)',
    commentaireTerrain:
      'Hausse soudaine des mortalités constatée à l’ouverture du bâtiment B2 à 06h15 après forte pluie nocturne. Litière humide côté sud.',
    photoMetadata: {
      fileName: 'litiere-bat2-1280p.jpg',
      dimensions: '1280 × 960 px (JPEG 0.7)',
      sizeKb: 142,
      capturedAt: '6 nov. 2026 à 06:44',
    },
    historique: [
      {
        etape: 'Nouvelle',
        date: '6 nov. 2026 à 06:50',
        auteur: 'Clarisse Nzé Bekale (Éleveur EST-0009)',
        note: 'Déclaration transmise depuis le carnet mobile avec cliché compressé.',
      },
    ],
  },
  {
    id: 'ALR-2026-088',
    fermeCode: 'HOG-0007',
    fermeNom: 'Exploitation POUFA Franceville 7',
    bandeCode: 'HOG-0007-B02',
    province: 'Haut-Ogooué',
    localite: 'Franceville - Potos',
    dateDeclaration: '5 nov. 2026 à 14:20',
    symptomes: [
      'Diarrhées blanchâtres crayeuses',
      'Prostration et plumes ébouriffées',
      'Retard de croissance J26 (-180 g sous cible)',
    ],
    mortalite24h: 34,
    mortalitePct24h: 1.7,
    effectifPresent: 1966,
    statutWorkflow: 'En analyse',
    gravite: 'alerte',
    veterinaireAssigne: 'Dr. Estelle Mouélé (Antenne DGE Franceville)',
    commentaireTerrain:
      'Suspicion de réaction post-vaccinale tardive ou atteinte bursale sur le lot livré le 11 oct.',
    diagnosticVeterinaire:
      'Prélèvements cloacaux et autopsie de 4 sujets réalisés à 16h30. Isolement sanitaire du bâtiment prescrit en attente du laboratoire provincial.',
    historique: [
      {
        etape: 'Nouvelle',
        date: '5 nov. 2026 à 14:20',
        auteur: 'Patrice Obame Ella (Éleveur HOG-0007)',
        note: 'Alerte générée suite au dépassement du seuil de mortalité sur 48 h.',
      },
      {
        etape: 'En analyse',
        date: '5 nov. 2026 à 16:40',
        auteur: 'Dr. Estelle Mouélé (Vétérinaire DGE)',
        note: 'Visite sur site effectuée, prélèvements transmis au laboratoire de Franceville.',
      },
    ],
  },
  {
    id: 'ALR-2026-085',
    fermeCode: 'WNT-0004',
    fermeNom: 'Unité de Chair Oyem 4',
    bandeCode: 'WNT-0004-B04',
    province: 'Woleu-Ntem',
    localite: 'Oyem - Methui',
    dateDeclaration: '4 nov. 2026 à 08:15',
    symptomes: [
      'Fientes sanguinolentes (suspicion coccidiose)',
      'Consommation alimentaire en repli (-14 %)',
    ],
    mortalite24h: 29,
    mortalitePct24h: 1.6,
    effectifPresent: 1780,
    statutWorkflow: 'Confirmée',
    gravite: 'alerte',
    veterinaireAssigne: 'Dr. Christian Emane (Secteur Nord Oyem)',
    commentaireTerrain: 'Apparition de fientes brun-rouge au jour 24 dans la travée centrale.',
    diagnosticVeterinaire:
      'Coccidiose caecale (Eimeria tenella) confirmée à l’examen lésionnel. Traitement anticoccidien (Amprolium + Vitamine K3) dans l’eau de boisson pendant 5 jours et renouvellement complet des copeaux.',
    historique: [
      {
        etape: 'Nouvelle',
        date: '4 nov. 2026 à 08:15',
        auteur: 'Hilaire Bourobou (Éleveur WNT-0004)',
        note: 'Signalement depuis le carnet terrain.',
      },
      {
        etape: 'En analyse',
        date: '4 nov. 2026 à 11:05',
        auteur: 'Dr. Christian Emane (Vétérinaire DGE)',
        note: 'Inspection sanitaire engagée.',
      },
      {
        etape: 'Confirmée',
        date: '4 nov. 2026 à 15:30',
        auteur: 'Dr. Christian Emane (Vétérinaire DGE)',
        note: 'Protocole thérapeutique Amprolium 5 jours validé. Suivi quotidien exigé.',
      },
    ],
  },
  {
    id: 'ALR-2026-081',
    fermeCode: 'EST-0022',
    fermeNom: 'Exploitation POUFA Akanda 22',
    bandeCode: 'EST-0022-B03',
    province: 'Estuaire',
    localite: 'Akanda - Malibé',
    dateDeclaration: '2 nov. 2026 à 13:45',
    symptomes: ['Halètement diurne prononcé', 'Surmortalité ponctuelle (19 sujets en 4 h)'],
    mortalite24h: 19,
    mortalitePct24h: 0.9,
    effectifPresent: 1950,
    statutWorkflow: 'Infirmée',
    gravite: 'vigilance',
    veterinaireAssigne: 'Dr. Marc-Aurèle Obiang (Brigade Vétérinaire Estuaire)',
    commentaireTerrain: 'Pic de chaleur à 34 °C sous tôle entre 12h00 et 15h00.',
    diagnosticVeterinaire:
      'Origine infectieuse écartée. Coup de chaleur lié à l’arrêt d’un brasseur d’air. Électrolytes + Vitamine C administrés, brasseur remplacé.',
    historique: [
      {
        etape: 'Nouvelle',
        date: '2 nov. 2026 à 13:45',
        auteur: 'Sylvie Moussavou (Éleveur EST-0022)',
        note: 'Déclaration préventive.',
      },
      {
        etape: 'En analyse',
        date: '2 nov. 2026 à 15:10',
        auteur: 'Dr. Marc-Aurèle Obiang (Vétérinaire DGE)',
        note: 'Vérification des paramètres d’ambiance et autopsie de contrôle.',
      },
      {
        etape: 'Infirmée',
        date: '2 nov. 2026 à 17:45',
        auteur: 'Dr. Marc-Aurèle Obiang (Vétérinaire DGE)',
        note: 'Stress thermique non contagieux. Retour à la normale dès J+1.',
      },
    ],
  },
  {
    id: 'ALR-2026-077',
    fermeCode: 'MOG-0003',
    fermeNom: 'Coopérative Avicole Lambaréné 3',
    bandeCode: 'MOG-0003-B04',
    province: 'Moyen-Ogooué',
    localite: 'Lambaréné - Isaac',
    dateDeclaration: '28 oct. 2026 à 09:00',
    symptomes: ['Boiteries légères sur 3 % du lot'],
    mortalite24h: 6,
    mortalitePct24h: 0.4,
    effectifPresent: 1475,
    statutWorkflow: 'Close',
    gravite: 'ok',
    veterinaireAssigne: 'Dr. Alain Ndong (Secteur Moyen-Ogooué)',
    commentaireTerrain: 'Sujets assis sur les jarrets en fin de phase croissance.',
    diagnosticVeterinaire:
      'Carence transitoire phospho-calcique corrigée par supplémentation minérale. Dossier clos après 7 jours sans récidive.',
    historique: [
      {
        etape: 'Nouvelle',
        date: '28 oct. 2026 à 09:00',
        auteur: 'Arsène Mba Allogho (Éleveur MOG-0003)',
        note: 'Signalement boiteries.',
      },
      {
        etape: 'En analyse',
        date: '28 oct. 2026 à 14:00',
        auteur: 'Dr. Alain Ndong (Vétérinaire DGE)',
        note: 'Analyse du lot d’aliment croissance.',
      },
      {
        etape: 'Confirmée',
        date: '29 oct. 2026 à 10:20',
        auteur: 'Dr. Alain Ndong (Vétérinaire DGE)',
        note: 'Ajustement minéral prescrit.',
      },
      {
        etape: 'Close',
        date: '4 nov. 2026 à 16:00',
        auteur: 'Dr. Alain Ndong (Vétérinaire DGE)',
        note: 'Lot rétabli, mobilité normale constatée au contrôle J35.',
      },
    ],
  },
];

export const PUBLIC_QR_LOTS: Record<string, PublicQrLotData> = {
  'EST-0014-B03-L01': {
    codeLot: 'EST-0014-B03-L01',
    reconnu: true,
    clos: false,
    produit: {
      designation: 'Poulet de chair entier prêt à cuire (Programme POUFA Gabon)',
      souche: 'Ross 308',
      modeElevage: 'Élevage au sol sur copeaux de bois locaux — Bâtiment ventilé',
      calibreMoyenKg: 2.15,
      conditionnement: 'Caisse scellée de 10 unités · Chaîne du froid +2 °C / +4 °C',
      dateAbattageOuSortie: '5 nov. 2026',
      dateLimiteConsommation: '12 nov. 2026',
    },
    origine: {
      codeFerme: 'EST-0014',
      nomFerme: 'Ferme Avicole Nkok-Sud',
      localite: 'Zone Économique Spéciale de Nkok',
      province: 'Estuaire',
      codeBande: 'EST-0014-B03',
      couvoirOrigine: 'Couvoir National d’Akanda (Lot poussins CNA-2026-41)',
      provenderie: 'Provenderie SMAG / Nkok Aliment Volaille (Sans farine animale)',
    },
    parcours: [
      {
        etape: 'Mise en place des poussins d’un jour (J1)',
        date: '15 oct. 2026',
        lieu: 'Nkok (ZES), Estuaire',
        detail: 'Réception de 2 500 poussins Ross 308 vaccinés couvoir (Newcastle HB1 + Bronchite H120).',
        statut: 'ok',
      },
      {
        etape: 'Protocole prophylactique complet (J7, J14, J21)',
        date: '4 nov. 2026',
        lieu: 'Ferme Avicole Nkok-Sud (EST-0014)',
        detail: 'Rappels Gumboro et Newcastle LaSota validés dans le registre numérique DGE.',
        statut: 'ok',
      },
      {
        etape: 'Contrôle du délai d’attente avant sortie',
        date: '5 nov. 2026',
        lieu: 'Brigade provinciale DGE — Estuaire',
        detail: 'Aucun traitement antibiotique en cours. Délai d’attente réglementaire respecté.',
        statut: 'ok',
      },
      {
        etape: 'Validation du lot pour mise en marché',
        date: '6 nov. 2026',
        lieu: 'Unité de conditionnement agréée d’Owendo',
        detail: 'Lot EST-0014-B03-L01 enregistré et étiqueté pour la distribution Grand Libreville.',
        statut: 'ok',
      },
    ],
  },
  'EST-0002-B01-L01': {
    codeLot: 'EST-0002-B01-L01',
    reconnu: false,
    clos: true,
    produit: {
      designation: 'Lot archivé — Bande clôturée en août 2026',
      souche: 'Ross 308',
      modeElevage: 'Élevage au sol',
      calibreMoyenKg: 2.05,
      conditionnement: 'Archivé',
      dateAbattageOuSortie: '18 août 2026',
      dateLimiteConsommation: '25 août 2026',
    },
    origine: {
      codeFerme: 'EST-0002',
      nomFerme: 'Exploitation POUFA Akanda 2',
      localite: 'Akanda - Malibé',
      province: 'Estuaire',
      codeBande: 'EST-0002-B01',
      couvoirOrigine: 'Couvoir National d’Akanda',
      provenderie: 'Provenderie SMAG',
    },
    parcours: [],
  },
};

export const PROVINCE_STATS_SUMMARY = [
  { province: 'Estuaire', fermes: 42, effectifActif: 98400, mortaliteMoyPct: 2.8, icMoyen: 1.58, poidsMoyenJ35: 1940 },
  { province: 'Haut-Ogooué', fermes: 26, effectifActif: 56200, mortaliteMoyPct: 3.1, icMoyen: 1.63, poidsMoyenJ35: 1890 },
  { province: 'Woleu-Ntem', fermes: 20, effectifActif: 41500, mortaliteMoyPct: 3.4, icMoyen: 1.66, poidsMoyenJ35: 1850 },
  { province: 'Ogooué-Maritime', fermes: 18, effectifActif: 38900, mortaliteMoyPct: 2.9, icMoyen: 1.60, poidsMoyenJ35: 1910 },
  { province: 'Moyen-Ogooué', fermes: 12, effectifActif: 24600, mortaliteMoyPct: 2.7, icMoyen: 1.59, poidsMoyenJ35: 1920 },
  { province: 'Ngounié', fermes: 11, effectifActif: 21800, mortaliteMoyPct: 3.3, icMoyen: 1.67, poidsMoyenJ35: 1840 },
  { province: 'Nyanga', fermes: 8, effectifActif: 15200, mortaliteMoyPct: 3.5, icMoyen: 1.69, poidsMoyenJ35: 1810 },
  { province: 'Ogooué-Ivindo', fermes: 7, effectifActif: 12900, mortaliteMoyPct: 3.6, icMoyen: 1.71, poidsMoyenJ35: 1790 },
  { province: 'Ogooué-Lolo', fermes: 6, effectifActif: 11400, mortaliteMoyPct: 3.2, icMoyen: 1.65, poidsMoyenJ35: 1860 },
];

export const GROWTH_CURVE_ROSS308 = [
  { jour: 'J7', cibleRoss308G: 185, moyenneNationaleG: 182, fermeEst0014G: 188 },
  { jour: 'J14', cibleRoss308G: 465, moyenneNationaleG: 452, fermeEst0014G: 472 },
  { jour: 'J21', cibleRoss308G: 925, moyenneNationaleG: 898, fermeEst0014G: 940 },
  { jour: 'J28', cibleRoss308G: 1480, moyenneNationaleG: 1435, fermeEst0014G: null },
  { jour: 'J35', cibleRoss308G: 2060, moyenneNationaleG: 1915, fermeEst0014G: null },
  { jour: 'J42', cibleRoss308G: 2640, moyenneNationaleG: 2490, fermeEst0014G: null },
];

export const COHORT_PERFORMANCE_SERIES = [
  { cohorte: '2025-T3', icMoyen: 1.74, mortalitePct: 4.1, coutKgFcfa: 1490 },
  { cohorte: '2025-T4', icMoyen: 1.69, mortalitePct: 3.7, coutKgFcfa: 1445 },
  { cohorte: '2026-T1', icMoyen: 1.65, mortalitePct: 3.4, coutKgFcfa: 1410 },
  { cohorte: '2026-T2', icMoyen: 1.62, mortalitePct: 3.2, coutKgFcfa: 1385 },
  { cohorte: '2026-T3', icMoyen: 1.60, mortalitePct: 3.1, coutKgFcfa: 1360 },
  { cohorte: '2026-T4 (en cours)', icMoyen: 1.58, mortalitePct: 2.9, coutKgFcfa: 1340 },
];
