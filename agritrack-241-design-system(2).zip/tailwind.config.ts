import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    colors: {
      transparent: 'transparent',
      current: 'currentColor',
      ink: {
        DEFAULT: 'var(--color-ink)',
        muted: 'var(--color-ink-muted)',
      },
      border: 'var(--color-border)',
      bg: 'var(--color-bg)',
      surface: 'var(--color-surface)',
      green: {
        700: 'var(--color-green-700)',
        600: 'var(--color-green-600)',
        100: 'var(--color-green-100)',
        50: 'var(--color-green-50)',
      },
      blue: {
        700: 'var(--color-blue-700)',
        50: 'var(--color-blue-50)',
      },
      orange: {
        600: 'var(--color-orange-600)',
        50: 'var(--color-orange-50)',
      },
      red: {
        700: 'var(--color-red-700)',
        50: 'var(--color-red-50)',
      },
      flag: {
        green: 'var(--color-flag-green)',
        yellow: 'var(--color-flag-yellow)',
        blue: 'var(--color-flag-blue)',
      },
    },
    fontSize: {
      14: ['var(--text-14)', { lineHeight: 'var(--leading-body)' }],
      16: ['var(--text-16)', { lineHeight: 'var(--leading-body)' }],
      18: ['var(--text-18)', { lineHeight: 'var(--leading-body)' }],
      20: ['var(--text-20)', { lineHeight: 'var(--leading-heading)' }],
      24: ['var(--text-24)', { lineHeight: 'var(--leading-heading)' }],
      32: ['var(--text-32)', { lineHeight: 'var(--leading-heading)' }],
    },
    fontWeight: {
      regular: '400',
      medium: '500',
      semibold: '600',
    },
    borderRadius: {
      none: '0px',
      sm: 'var(--radius-sm)',
      DEFAULT: 'var(--radius-sm)',
      md: 'var(--radius-md)',
      full: '9999px',
    },
    boxShadow: {
      none: 'none',
      floating: 'var(--shadow-floating)',
    },
    extend: {
      fontFamily: {
        sans: ['var(--font-sans)'],
        mono: ['var(--font-mono)'],
      },
      transitionDuration: {
        DEFAULT: '150ms',
        150: '150ms',
      },
    },
  },
  plugins: [],
};

export default config;
