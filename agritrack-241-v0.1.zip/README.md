# AgriTrack 241

Prototype mobile-first de suivi technico-économique et de traçabilité de la filière poulet de chair. Les dates sont enregistrées en UTC ; l’affichage et les opérations calendaires utilisent `Africa/Libreville` (`fr-FR`).

## Démarrage local

Prérequis : Node.js 20.11+, pnpm 9, Docker Compose.

```sh
cp .env.example .env
pnpm install
docker compose up -d postgres
pnpm db:generate
pnpm db:migrate
pnpm db:seed
pnpm dev
```

API Swagger : <http://localhost:3000/api/docs> en développement. Web : <http://localhost:5173>. Pour lancer les trois services conteneurisés : `docker compose up --build` après avoir créé `.env`.

## Comptes de démonstration

Tous les comptes de démonstration ont le mot de passe temporaire `PoufaDemo2026!`. Identifiants : `eleveur@agritrack.ga`, `agent@agritrack.ga`, `dge@agritrack.ga`, `veterinaire@agritrack.ga`, `bceg@agritrack.ga`, `maedr@agritrack.ga`, `operateur@agritrack.ga`, `auditeur@agritrack.ga`, `admin@agritrack.ga`. Le compte opérateur utilise une convention de démonstration ; aucune donnée de production ne doit être saisie avec ces identifiants. Changez ces valeurs avant toute exposition réseau.

## Guides et contrats

- [Installation](docs/installation.md)
- [Démonstration en 10 minutes](docs/demo-10-minutes.md)
- [Matrice endpoint × rôle](docs/endpoint-role-matrix.md)
- [Formats API et EMA-i Plus](docs/data-exchange.md)
- [Règles à valider par la DGE et les services vétérinaires](docs/rules-to-validate.md)
- [Audit des 68 fonctionnalités](docs/phase7-compliance-68.md)
- [Collection Postman](apps/api/postman/AgriTrack-241.postman_collection.json)

## Sécurité et limites du prototype

- Les identifiants et mots de passe de démonstration ne sont pas des secrets de production. Les secrets JWT doivent être remplacés dans `.env`.
- Les endpoints appliquent des guards RBAC et des scopes serveur; consulter la matrice pour les rôles effectifs issus du seed.
- Audit append-only et protection des bandes clôturées sont imposés par triggers PostgreSQL.
- Le QR n’est pas un certificat sanitaire. Le connecteur EMA-i Plus et l’envoi email restent simulés.
- Le lot front-end offline/sync et les écrans métier PWA sont encore incomplets; consulter l’audit de conformité.
- Ne pas modifier/supprimer une migration déjà appliquée; créer une nouvelle migration.

## Structure

```text
apps/
  api/                 NestJS, Prisma, PostgreSQL, tests
  web/                 React, Vite, PWA, IndexedDB/Dexie
docs/
  data-model.mmd       Diagramme des relations
```

## Diagramme de relations

Voir [`docs/data-model.mmd`](docs/data-model.mmd).

## Sécurité avant tout hébergement
Remplacer JWT_ACCESS_SECRET, JWT_REFRESH_SECRET, POSTGRES_PASSWORD et le mot de passe des comptes de démo.
Générer un secret : openssl rand -hex 32
Ne jamais déployer avec les valeurs de .env.example.
