#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a
DBU=$(echo "$DATABASE_URL" | sed -E 's#^[a-z]+://([^:]+):.*#\1#')
DBN=$(echo "$DATABASE_URL" | sed -E 's#.*/([^/?]+)(\?.*)?$#\1#')
TEST_URL=$(echo "$DATABASE_URL" | sed -E "s#/$DBN(\?|\$)#/agritrack_test\1#")

docker compose exec -T postgres psql -U "$DBU" -d postgres -c 'DROP DATABASE IF EXISTS agritrack_test WITH (FORCE);'
docker compose exec -T postgres psql -U "$DBU" -d postgres -c 'CREATE DATABASE agritrack_test;'

export DATABASE_URL="$TEST_URL"
corepack pnpm --filter @agritrack/api exec prisma migrate deploy
corepack pnpm --filter @agritrack/api prisma:seed
RUN_E2E=true corepack pnpm test:e2e
