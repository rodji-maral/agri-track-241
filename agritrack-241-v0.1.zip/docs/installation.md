# Installation AgriTrack 241

## Prérequis

- Node.js 20.11 ou supérieur.
- Corepack et pnpm 9.
- Docker Compose v2.
- Accès local à PostgreSQL 16 via Docker.

## Développement local

```sh
cp .env.example .env
openssl rand -base64 48
```

Utilisez deux valeurs différentes d’au moins 32 caractères pour `JWT_ACCESS_SECRET` et `JWT_REFRESH_SECRET` dans `.env`. En développement local, conservez `DATABASE_URL` sur `localhost:5432`.

```sh
corepack pnpm install
docker compose up -d postgres
corepack pnpm db:generate
corepack pnpm db:migrate
corepack pnpm db:seed
corepack pnpm dev
```

Web : <http://localhost:5173>. API : <http://localhost:3000/api>. Swagger est exposé en développement sur <http://localhost:3000/api/docs> et son document JSON sur `/api/docs-json`.

Pour lancer les services entièrement conteneurisés : `docker compose up --build`. Compose remplace l’URL locale de PostgreSQL par le nom du service `postgres` à l’intérieur du réseau Docker.

## Réinitialisation de la démo

Le reset est destructif pour les données métier locales. Il refuse les environnements autres que `development`/`test` et les bases distantes ou dont le nom n’est pas `agritrack`, `agritrack_demo` ou `agritrack_test`.

```sh
ALLOW_DEMO_RESET=true NODE_ENV=development corepack pnpm --filter @agritrack/api prisma:reset-demo
```

Le reset conserve le journal d’audit append-only et les compteurs d’identifiants. Il recrée ensuite les données de démonstration par le seed.

## Tests

```sh
corepack pnpm --filter @agritrack/api test
corepack pnpm --filter @agritrack/api build
corepack pnpm --filter @agritrack/web build
```

Les tests e2e exigent une base locale migrée et seedée. Ils créent des données de parcours et ne les suppriment pas, conformément à l’immutabilité de l’audit.
Pour rejouer le parcours à volonté : `pnpm test:e2e:fresh` (base jetable recréée à chaque exécution, évite les refus de doublon).

```sh
RUN_E2E=true corepack pnpm --filter @agritrack/api test:e2e
```

## Production

- Ne pas utiliser les comptes ou le mot de passe de démonstration.
- Fournir les secrets et URL via un gestionnaire de secrets/environnement, jamais dans l’image ou le dépôt.
- Définir `NODE_ENV=production`, `CORS_ORIGIN` avec les origines HTTPS précises et `PUBLIC_API_URL` avec l’URL publique HTTPS.
- Exécuter `prisma migrate deploy`; ne pas utiliser `migrate dev` en production.
- Sauvegarder PostgreSQL et tester la restauration. Le journal d’audit doit rester en append-only.
- Les tuiles de carte et les services externes ne sont pas inclus dans le socle hors-ligne.