# Démonstration en 10 minutes

Tous les comptes du seed ont le mot de passe temporaire `PoufaDemo2026!`. Ces comptes sont réservés au poste de démonstration.

1. Démarrer PostgreSQL et les applications avec les commandes de [installation](installation.md). Ouvrir le web sur <http://localhost:5173> et l’API Swagger en développement sur `/api/docs`.
2. Se connecter avec `dge@agritrack.ga`. Présenter le périmètre DGE, les neuf provinces et les fermes seedées.
3. Créer une ferme de démonstration dans l’Estuaire avec des coordonnées de Libreville/Nkok, puis l’activer. Vérifier son code automatique `EST-xxxx`.
4. Ouvrir une bande, mettre 1 000 sujets et un poids initial. Vérifier le code `EST-xxxx-Bxx`.
5. Soumettre une fiche quotidienne de 50 morts et 90 kg d’aliment avec un UUID client. Rejouer la même requête pour illustrer l’idempotence.
6. Se déconnecter et se connecter avec `veterinaire@agritrack.ga`. Montrer l’alerte créée, la faire passer en analyse, confirmer, puis publier.
7. Revenir au compte DGE, enregistrer une sortie d’abattage avec l’opérateur conventionné `OPER-DEMO-001` et destination « Abattoir de démonstration ». Un lot et son QR sont créés automatiquement.
8. Clôturer la bande. Consulter le lot et exporter son QR PNG/SVG.
9. Ouvrir l’URL publique du lot dans une fenêtre privée, vérifier l’origine et la mention « Ce QR code n’est pas un certificat sanitaire ». Le scan doit apparaître dans `ScanLog`.
10. Présenter l’export de données et le circuit d’agrégat : soumission DGE, puis validation/publication avec `maedr@agritrack.ga`.

Les valeurs de formules/seuils seedées sont `Proposé`. Pour une démonstration des alertes automatiques, le seuil sanitaire doit être validé par le compte vétérinaire avant la saisie anormale. La démo e2e fait cette préparation automatiquement sur la base de test.