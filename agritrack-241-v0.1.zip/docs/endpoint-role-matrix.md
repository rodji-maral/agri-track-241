# Matrice endpoint × rôle

## Légende

`E` ÉLEVEUR · `AT` AGENT_TECHNIQUE · `DGE` POUFA_DGE · `VET` VETERINAIRE · `B` BCEG · `M` MAEDR · `O` OPERATEUR · `AUD` AUDITEUR_ANINF · `ADM` ADMIN · `Public` sans jeton.

Les rôles indiqués doivent aussi posséder la permission `resource:action` chargée depuis `RolePermission`. Les accès listés sont en plus filtrés par ferme/province, propriétaire, affectation opérateur ou consentement BCEG. Les contrôles sont confirmés par les guards globaux et/ou les services.

| Endpoint | Rôles admis | Permission / restriction supplémentaire |
|---|---|---|
| `POST /api/auth/login` | Public | 5 requêtes/minute/IP; compte actif |
| `POST /api/auth/refresh` | Public | 10 requêtes/minute/IP; session refresh active et rotation atomique |
| `POST /api/auth/logout` | Tout compte authentifié | Révoque uniquement sa propre session |
| `GET /api/farms`, `GET /api/farms/:id` | E, AT, DGE, VET, B, ADM | `farm:CONSULT`; périmètre ferme/province; B limité au financement et au consentement actif |
| `POST /api/farms`, `POST /api/farms/import` | E, AT, DGE, VET, ADM | `farm:CREATE`; périmètre province; cohérence GPS et doublons contrôlés |
| `PATCH /api/farms/:id`, `PATCH /api/farms/:id/status` | E, AT, DGE, VET, ADM | `farm:MODIFY`; scope ferme; transitions paramétrées |
| `GET /api/batches`, `GET /api/batches/:id` | E, AT, DGE, VET, ADM | `batch:CONSULT`; scope ferme/province |
| `POST /api/farms/:farmId/batches` | E, AT, DGE, VET, ADM | `batch:CREATE`; scope ferme, capacité et UUID client |
| `POST /api/batches/:id/close` | E, AT, DGE, VET, ADM | `batch:MODIFY`; bande en lecture seule après clôture |
| `GET /api/batches/:id/performance` | E, AT, DGE, VET, ADM | `batch:CONSULT`; scope ferme |
| `GET /api/batches/:id/weighing-reminder` | E, AT, DGE, ADM | `weighing:CONSULT`; fréquence approuvée |
| `GET,POST /api/batches/:batchId/daily-records` | E, AT, DGE, VET, ADM | `daily_record:CONSULT/CREATE`; morts ≤ effectif, bande ouverte, UUID idempotent |
| `GET,POST /api/batches/:batchId/weighings` | E, AT, DGE, ADM | `weighing:CONSULT/CREATE`; scope ferme, bande ouverte |
| `GET,POST /api/batches/:batchId/outflows` | E, AT, DGE, ADM | `outflow:CONSULT/CREATE`; quantité ≤ effectif; destinataire/convention selon type |
| `GET /api/inputs/receipts`, `GET /api/inputs/stock`, `GET /api/inputs/discrepancies` | E, AT, DGE, ADM | `input:CONSULT`; scope ferme |
| `POST /api/inputs/receipts`, `POST /api/inputs/usages`, `POST /api/inputs/orders` | E, AT, DGE, ADM | `input:CREATE`; stock non négatif; commande encore stub |
| `PATCH /api/inputs/receipts/:id/confirm` | E uniquement | `input:MODIFY`; confirmation limitée à sa ferme |
| `POST /api/health/declarations` | E, AT, DGE, VET, ADM | `health:CREATE`; le déclarant ne reçoit que son accusé de dépôt |
| `GET /api/health/declarations`, `PUT /api/health/declarations/:id/review` | VET uniquement | `health:CONSULT/VALIDATE`; scope vétérinaire |
| `GET,POST /api/health/batches/:batchId/vaccinations`, `GET /api/health/batches/:batchId/vaccination-calendar` | E, AT, DGE, VET, ADM | `health:CONSULT/CREATE`; scope bande |
| `GET,POST /api/health/batches/:batchId/treatments` | E, AT, DGE, VET, ADM | `health:CONSULT/CREATE`; bande/lot cohérents |
| `GET,POST /api/health/interventions` | VET uniquement | `health:CONSULT/CREATE`; intervention vétérinaire et scope province/ferme |
| `GET,PUT /api/alerts`, `PUT /api/alerts/:id/status`, `POST /api/alerts/:id/publish` | VET uniquement | `alert:CONSULT/VALIDATE`; publication après confirmation |
| `GET /api/economics/batches/:batchId/economics` | E, AT, DGE, B, ADM | `finance:CONSULT`; B limité par consentement actif |
| `GET /api/sales` | E, AT, DGE, B, O, ADM | `finance:CONSULT`; O limité à ses ventes/acheteurs affectés; B aux fermes consentantes |
| `POST /api/batches/:batchId/sales` | E, AT, DGE, ADM | `finance:CREATE`; bande accessible et acheteur valide |
| `GET /api/expenses` | E, AT, DGE, B, ADM | `finance:CONSULT`; B limité aux fermes consentantes |
| `POST /api/farms/:farmId/expenses` | E, AT, DGE, ADM | `finance:CREATE`; ferme accessible, postes paramétrés |
| `GET /api/dashboards/farmer` | E, AT, DGE, ADM | `batch:CONSULT`; scope ferme |
| `GET /api/dashboards/overview` | DGE, M, ADM | `aggregate:CONSULT`; M ne reçoit que des données publiées |
| `GET /api/dashboards/ranking` | DGE, ADM | `farm:CONSULT`; critères approuvés |
| `POST /api/dashboards/aggregates` | DGE, ADM | `aggregate:CREATE`; crée une soumission non publique |
| `POST /api/dashboards/aggregates/:id/approve` | M uniquement | `aggregate:VALIDATE`; publie l’agrégat soumis |
| `GET /api/reports/templates` | DGE, M, ADM | `report:CONSULT` |
| `POST /api/reports/templates` | ADM uniquement | `report:ADMINISTER`; crée une nouvelle version |
| `GET /api/reports/:key/export` | E, AT, DGE, M, B, ADM | `report:EXPORT`; chaque export est audité, scope selon datasource |
| `GET /api/traceability/lots/:id`, `GET /api/traceability/lots/:id/qr`, `GET /api/traceability/search`, `GET /api/traceability/indicators` | E, AT, DGE, O, ADM | `lot:CONSULT`; O limité aux lots qui lui sont affectés |
| `POST /api/traceability/lots/:id/verify-transfer` | E, AT, DGE | `lot:MODIFY`; référence doit correspondre à la sortie du lot |
| `POST /api/traceability/lots/:id/receive` | O uniquement | `lot:MODIFY`; convention active et compte affecté à l’opérateur destinataire |
| `GET /api/operators` | DGE, ADM, O | O voit uniquement ses affectations |
| `POST /api/operators`, `POST /api/operators/:id/accounts` | DGE, ADM | Convention signée et valide; utilisateur cible doit avoir OPERATEUR |
| `GET /api/configuration/parameters`, `GET /api/configuration/formulas`, `GET /api/configuration/thresholds`, `GET /api/configuration/lists` | DGE, VET, ADM | `parameter:CONSULT` |
| `POST /api/configuration/parameters`, `POST /api/configuration/formulas`, `POST /api/configuration/lists` | DGE, VET, ADM | `parameter:MODIFY`; nouvelles versions proposées |
| `POST /api/configuration/thresholds` | DGE, VET, ADM | `parameter:MODIFY`; clé `health.*` refusée sauf VET |
| `POST /api/configuration/formulas/evaluate` | DGE, VET, ADM | `parameter:CONSULT`; formule approuvée seulement |
| `POST /api/configuration/:kind/:id/approve` | VET, ADM | `parameter:VALIDATE`; seuil sanitaire toujours VET uniquement |
| `GET /api/notifications` | Tout rôle authentifié | `notification:CONSULT`; uniquement ses notifications |
| `PATCH /api/notifications/:id/read` | E, AT, DGE, VET, O, ADM | `notification:MODIFY`; uniquement sa notification |
| `GET /api/audit/integrity`, `GET /api/audit/export` | AUD, ADM | `audit:CONSULT/EXPORT`; lecture/export audités |
| `GET,POST /api/integrations/ema-i-plus/*` | DGE, ADM | Permission `health`; adaptateur stub local |
| `GET /api/public/lots/:code` | Public | QR reconnu/actif, scan journalisé, 30 requêtes/minute/IP, aucun champ privé |
| Swagger `/api/docs` et `/api/docs-json` | Non exposé en production | Disponible en développement/test uniquement |

## Surface non encore implémentée

Il n’existe pas encore de contrôleur de gestion de comptes/roles/assignations administratives. Ces tables existent, mais leur administration UI/API reste à réaliser. Le moteur PWA offline/sync n’est pas encore livré; les endpoints de saisie acceptent les UUID idempotents, mais ne constituent pas une API de synchronisation complète.