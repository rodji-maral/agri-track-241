# Audit de conformité — 68 fonctionnalités

`Fait` = API/contrainte effectivement présente et testée ou compilée. `Stub` = structure ou contrat présent, parcours incomplet. `Hors périmètre` = explicitement non réalisé dans ce prototype. `P0` sécurité/intégrité, `P1` parcours MVP, `P2` évolution/pilotage.

| # | Fonctionnalité | Statut | Priorité | Note de conformité |
|---:|---|---|---|---|
| 1 | Monorepo pnpm workspaces | Fait | P0 | API et web dans `apps/*` |
| 2 | PostgreSQL 16 via Docker Compose | Fait | P0 | Conteneur et healthcheck définis |
| 3 | Secrets via variables d’environnement | Fait | P0 | Joi valide JWT et URL DB |
| 4 | Schéma Prisma des domaines POUFA | Fait | P0 | Tables couvrant les modules des phases 0–5 |
| 5 | Migration initiale et migration SQL | Fait | P0 | Appliquée et vérifiée en base ; triggers prouvés par apps/api/test/security-triggers.e2e-spec.ts |
| 6 | API NestJS TypeScript strict | Fait | P0 | Build vérifié |
| 7 | Validation DTO et Swagger | Fait | P0 | Validation globale; Swagger dev/test |
| 8 | Application React/Vite/TypeScript | Fait | P1 | Build vérifié |
| 9 | Base PWA installable | Stub | P1 | Plugin/manifest/service worker; écrans et parcours incomplets |
| 10 | Polices et icônes locales | Fait | P1 | Inter auto-hébergée, lucide-react |
| 11 | UI française et dates locales | Stub | P1 | Base globale posée; écrans métier non livrés |
| 12 | Tokens visuels institutionnels | Fait | P1 | Palette et composants du lot 1 |
| 13 | Composants communs accessibles | Fait | P1 | Bibliothèque UI initiale |
| 14 | Cache lecture IndexedDB/Dexie | Stub | P1 | Dépendance présente, store métier non réalisé |
| 15 | Outbox offline et synchronisation | Stub | P0 | UUID idempotents côté API; moteur client/API de sync incomplet |
| 16 | Connexion JWT | Fait | P0 | Login, compte actif, hash mot de passe |
| 17 | Refresh/logout révocable | Fait | P0 | Sessions persistées/rotation |
| 18 | RBAC paramétré | Fait | P0 | Permission/RolePermission en base et guards globaux |
| 19 | Filtrage par périmètre requête | Fait | P0 | Fermes/provinces, affectations opérateur |
| 20 | Consentement BCEG révocable | Fait | P0 | Historique, scope actif et lecture domiciliation BCEG |
| 21 | Audit SHA-256 chaîné | Fait | P0 | Service de hachage et vérification |
| 22 | Audit non modifiable en base | Fait | P0 | Trigger UPDATE/DELETE dans migration ; preuve : security-triggers.e2e-spec.ts |
| 23 | Exports/consultations sensibles audités | Fait | P0 | Intercepteur et exports explicites |
| 24 | Référentiel des 9 provinces | Fait | P1 | Seed et bornes GPS configurées |
| 25 | Registre ferme/code automatique | Fait | P1 | Préfixes et compteurs atomiques |
| 26 | Doublons et GPS incohérent bloqués | Fait | P1 | Tests de cohérence et bornes paramétrées |
| 27 | Statut ferme et historique | Fait | P1 | Transitions en ListValue |
| 28 | Bande/code et UUID client | Fait | P1 | Compteur atomique, idempotence d’ouverture |
| 29 | Ouverture en cours de cycle | Fait | P1 | Date de mise en place fournie |
| 30 | Clôture et lecture seule de bande | Fait | P0 | Soft-lock applicatif et trigger SQL ; preuve : security-triggers.e2e-spec.ts |
| 31 | Fiche quotidienne morts/aliment | Fait | P1 | Cohérence effectif et clé jour/bande |
| 32 | Performance/GMQ/IC/complétude | Fait | P1 | FormulaEngine, valeurs chiffrées testées |
| 33 | Rappel de pesée paramétré | Fait | P1 | Fréquence lue en base |
| 34 | Sorties ≤ effectif, lien vente/lot | Fait | P1 | Contrôle transactionnel et tests |
| 35 | Réception d’intrant confirmée | Fait | P1 | Confirmeur éleveur |
| 36 | Stock intrant et non-négativité | Fait | P1 | Agrégé des quantités confirmées, verrou transactionnel |
| 37 | Écart intrant paramétrable | Fait | P1 | Formule/seuil approuvés |
| 38 | Commande d’intrants | Stub | P2 | Enregistrement de commande sans workflow fournisseur |
| 39 | Déclaration sanitaire privée | Fait | P0 | Consultation/qualification vétérinaire seulement |
| 40 | Seuil sanitaire réservé vétérinaire | Fait | P0 | Guard de service et permission |
| 41 | Alerte précoce sur mortalité | Fait | P0 | Test seuil dépassé |
| 42 | Workflow d’alerte et historique | Fait | P0 | Transitions ListValue, historique horodaté |
| 43 | Publication vétérinaire | Fait | P0 | Confirmation requise; action vétérinaire seulement |
| 44 | Calendrier vaccinal et retards | Fait | P1 | Calculé depuis l’âge de bande |
| 45 | Traitement lié bande/lot | Fait | P1 | Validation appartenance |
| 46 | Interventions vétérinaires privées | Fait | P0 | Actions vétérinaires uniquement |
| 47 | Notifications in-app/email | Stub | P1 | In-app réel, email simulé |
| 48 | Adaptateur EMA-i Plus | Stub | P2 | Contrat OpenAPI; aucun appel externe |
| 49 | Registre opérateurs/convention | Fait | P1 | Activation et affectation contrôlées |
| 50 | Lot/sous-lot et QR auto | Fait | P1 | Lots générés sur sortie, QR unique |
| 51 | QR public sans donnée personnelle | Fait | P0 | Producteur/localité/parcours/disclaimer |
| 52 | Scan journalisé/lot clos rejeté | Fait | P0 | Tests inconnu, clos et scan actif |
| 53 | Réception abattoir et écart | Fait | P1 | Quantités, seuil et événement vérifié |
| 54 | Recherche/export amont-aval | Fait | P1 | Farm/batch/operator/période, CSV/JSON |
| 55 | Indicateurs couverture 95 % | Fait | P1 | Formules/cible paramétrées |
| 56 | Ventes par tête ou kg | Fait | P1 | Acheteur et prix réutilisables |
| 57 | Charges paramétrées | Fait | P1 | ListValue des catégories |
| 58 | Reprise coût d’intrant dans charge | Fait | P1 | Coût source et unicité expense/usage |
| 59 | CA/coût/marge/taux via formules | Fait | P1 | Test chiffré; sans formule approuvée, résultat nul/refusé |
| 60 | Dashboard éleveur | Stub | P1 | Endpoint API présent; écran web absent |
| 61 | Dashboard province/national et filtres | Stub | P1 | API présente; graphiques UI absents |
| 62 | Classement pondéré configurable | Fait | P2 | Critères et poids issus de Parameter |
| 63 | Agrégat soumis DGE | Fait | P0 | Données non publiées avant MAEDR |
| 64 | Validation/publication MAEDR | Fait | P0 | Endpoint et audit de validation |
| 65 | Modèles de rapports versionnés | Fait | P2 | Seed hebdo/fin de bande/mensuel |
| 66 | Export PDF/XLSX/CSV | Fait | P1 | Filtré selon rôles; export audité |
| 67 | Carte ferme et tuiles offline | Stub | P2 | Modèle GPS existe; carte web et cache de tuiles absents |
| 68 | Écrans PWA métier complets par rôle | Stub | P1 | Lot 1 UI seulement; lots suivants à livrer |

Les statuts `Stub` des écrans web ne signifient pas que les API correspondantes sont absentes; ils distinguent le backend existant de l’expérience utilisateur encore non livrée.