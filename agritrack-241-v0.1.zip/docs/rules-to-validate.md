# Règles à valider

Les valeurs ci-dessous sont des propositions de démonstration, pas des normes vétérinaires ni des décisions réglementaires. Elles restent en état `PROPOSED` jusqu’à validation par le rôle habilité.

| Règle | Valeur proposée | Validation attendue |
|---|---:|---|
| Durée de référence d’une bande | 45 jours | DGE |
| Fréquence de pesée | 1 par semaine | DGE / services vétérinaires |
| Seuil de mortalité journalière | 3 % | Services vétérinaires uniquement |
| Écart intrants | 5 % | DGE |
| Écart réception abattoir | 5 % | DGE / abattoir / services vétérinaires |
| Couverture minimale de traçabilité | 95 % | DGE / MAEDR |
| Calendrier vaccinal seed | J1, J7, J14, J21 | Services vétérinaires |
| Formules de performance et rentabilité | Expressions seedées, toutes `PROPOSED` | DGE; seuil sanitaire uniquement vétérinaire |
| Classement des fermes | Viabilité 35 %, mortalité 30 %, complétude 20 %, occupation 15 % | DGE; critères et poids à approuver |
| Statuts et transitions ferme/alerte | Listes seedées | DGE et services vétérinaires selon le domaine |

## Formules `PROPOSED`

Chaque expression ci-dessous est versionnée dans `Formula` et ne devient active qu’après approbation. Les variables listées sont les seules variables accessibles au moteur sécurisé.

| Clé | Expression proposée | Variables |
|---|---|---|
| `present_count` | `placed - cumulative_deaths - cumulative_outflows` | `placed`, `cumulative_deaths`, `cumulative_outflows` |
| `mortality_rate` | `cumulative_deaths / placed * 100` | `cumulative_deaths`, `placed` |
| `viability_rate` | `100 - mortality_rate` | `mortality_rate` |
| `daily_gain` | `(current_average_weight - initial_weight) / age_days * 1000` | `current_average_weight`, `initial_weight`, `age_days` |
| `live_weight_produced` | `outflow_weight + present_count * current_average_weight - placed * initial_weight` | `outflow_weight`, `present_count`, `current_average_weight`, `placed`, `initial_weight` |
| `feed_conversion` | `feed_consumed_kg / live_weight_produced_kg` | `feed_consumed_kg`, `live_weight_produced_kg` |
| `occupancy_rate` | `placed / capacity * 100` | `placed`, `capacity` |
| `input_stock` | `received - used` | `received`, `used` |
| `input_variance_rate` | `(delivered - used - stock) / delivered * 100` | `delivered`, `used`, `stock` |
| `revenue` | `quantity * unit_price` | `quantity`, `unit_price` |
| `production_cost_per_kg` | `charges / live_weight_produced_kg` | `charges`, `live_weight_produced_kg` |
| `margin` | `revenue - charges` | `revenue`, `charges` |
| `margin_rate` | `margin / revenue * 100` | `margin`, `revenue` |
| `entry_completeness` | `recorded_days / elapsed_days * 100` | `recorded_days`, `elapsed_days` |
| `early_health_alert` | `daily_deaths / present_count * 100` | `daily_deaths`, `present_count` |
| `biosecurity_score` | `compliant_points / checked_points * 100` | `compliant_points`, `checked_points` |
| `sale_traceability_rate` | `linked_sales / total_sales * 100` | `linked_sales`, `total_sales` |
| `lot_qr_coverage_rate` | `lots_with_qr / total_lots * 100` | `lots_with_qr`, `total_lots` |

## Listes et seuils `PROPOSED`

Les unités de vente (`sujet`, `kg`), postes de dépense, préfixes des neuf provinces, transitions d’état et calendriers vaccinaux sont des valeurs seedées modifiables selon les droits. Les seuils seedés sont mortalité 3 % (vétérinaire seul), écart intrants 5 % et écart de réception abattoir 5 %. Les bornes GPS utilisées pour les provinces sont des rectangles de démonstration et doivent être remplacées/validées par des géométries officielles.

Les formules sont évaluées par `FormulaEngine` sans `eval`. Une formule absente/non approuvée ne doit pas être remplacée silencieusement par une formule codée en dur.