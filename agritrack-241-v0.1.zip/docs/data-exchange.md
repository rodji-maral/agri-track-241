# Formats API et échanges

## API AgriTrack

- Transport : HTTPS en déploiement, JSON UTF-8 pour les requêtes/réponses.
- Dates : ISO 8601 avec fuseau (`2026-11-06T14:30:00Z`); stockage UTC, affichage `fr-FR` et calendrier `Africa/Libreville`.
- Montants : XAF par défaut, décimaux transmis comme nombres JSON; `quantity` et `unit` restent distincts.
- Saisie hors-ligne : un UUID `clientUuid` stable par enregistrement; le même UUID doit être réutilisé à chaque rejeu réseau.
- Erreurs : objet avec `statusCode`, `error`, `path`, `timestamp`, `requestId`.
- Authentification : `Authorization: Bearer <accessToken>`; le refresh token est envoyé au endpoint dédié et stocké côté serveur sous forme de hash.
- CSV : UTF-8, première ligne en-têtes; les cellules commençant par `=`, `+`, `-` ou `@` sont échappées à l’export pour limiter l’injection de formules tableur.

## Conflits de synchronisation

La règle fonctionnelle cible du cahier des charges est « dernière saisie horodatée gagnante », avec un signalement/audit du conflit. Le rejeu des opérations déjà prises en charge utilise `clientUuid` pour éviter les doublons.

À ce stade, le schéma `SyncConflict` et les endpoints d’écriture idempotente sont en place, mais le moteur PWA de détection/résolution complète n’est pas livré. Les consommateurs ne doivent pas considérer `last-write-wins` comme opérationnel tant que le lot front-end offline/sync et son API de synchronisation ne sont pas activés.

## EMA-i Plus

Le contrat stub est décrit par [l’OpenAPI EMA-i Plus](ema-i-plus-openapi.yaml). Le corps `EmaiPlusEvent` contient `eventId` UUID, `farmCode`, `eventType`, `occurredAt` ISO 8601 et un objet `payload`. L’adaptateur courant retourne `accepted: false`, n’effectue aucun appel distant et audite la tentative. Toute intégration réelle devra faire l’objet d’une configuration de secrets, d’un accord d’interopérabilité et de tests de contrat.

## OpenAPI/Postman

En développement, Swagger est disponible sur `/api/docs` et le document généré sur `/api/docs-json`. La collection d’exemples importable dans Postman est `apps/api/postman/AgriTrack-241.postman_collection.json`.