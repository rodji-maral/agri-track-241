/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        program: {
          50: 'var(--program-50)',
          600: 'var(--program-600)',
          700: 'var(--program-700)',
        },
        institutional: {
          50: 'var(--institutional-50)',
          700: 'var(--institutional-700)',
        },
        accent: {
          50: 'var(--accent-50)',
          600: 'var(--accent-600)',
        },
        critical: {
          50: 'var(--critical-50)',
          700: 'var(--critical-700)',
        },
        ink: 'var(--ink)',
        muted: 'var(--muted)',
        border: 'var(--border)',
        canvas: 'var(--canvas)',
        surface: 'var(--surface)',
        overlay: 'var(--overlay)',
        neutral: {
          100: 'var(--neutral-100)',
          200: 'var(--neutral-200)',
          300: 'var(--neutral-300)',
          600: 'var(--neutral-600)',
          700: 'var(--neutral-700)',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      borderRadius: {
        sm: '4px',
        DEFAULT: '4px',
        md: '6px',
      },
      boxShadow: {
        panel: 'var(--shadow-panel)',
      },
      minHeight: {
        touch: '48px',
      },
      minWidth: {
        touch: '48px',
      },
    },
  },
  plugins: [],
};
