import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: [],
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
      },
      manifest: {
        name: 'AgriTrack 241',
        short_name: 'AgriTrack',
        description: 'Suivi des élevages de poulets de chair au Gabon',
        theme_color: '#1E6B45',
        background_color: '#F5F7F8',
        display: 'standalone',
        start_url: '/',
        icons: [],
      },
    }),
  ],
  server: { host: '0.0.0.0' },
});
