import {
  AlertCircle,
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Cloud,
  CloudOff,
  Info,
  LoaderCircle,
  Minus,
  Plus,
  RefreshCw,
  Wifi,
  X,
} from 'lucide-react';
import {
  createContext,
  forwardRef,
  useContext,
  useId,
  useState,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
} from 'react';

type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  loading?: boolean;
  icon?: ReactNode;
  fullWidth?: boolean;
}

const buttonVariants: Record<ButtonVariant, string> = {
  primary: 'border-program-700 bg-program-700 text-surface hover:bg-program-600',
  secondary: 'border-border bg-surface text-ink hover:bg-neutral-100',
  danger: 'border-critical-700 bg-critical-700 text-surface hover:bg-critical-700',
  ghost: 'border-transparent bg-transparent text-institutional-700 hover:bg-institutional-50',
};

export function Button({
  variant = 'primary',
  loading = false,
  icon,
  fullWidth = false,
  disabled,
  className = '',
  children,
  ...props
}: ButtonProps): JSX.Element {
  return (
    <button
      className={`touch-target inline-flex items-center justify-center gap-2 rounded border px-4 py-2 text-base font-semibold transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-60 ${buttonVariants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      disabled={disabled || loading}
      aria-busy={loading}
      {...props}
    >
      {loading ? <LoaderCircle aria-hidden="true" size={20} /> : icon}
      <span>{children}</span>
    </button>
  );
}

export interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  help?: string;
  error?: string;
  wrapperClassName?: string;
}

export const Field = forwardRef<HTMLInputElement, FieldProps>(function Field(
  { label, help, error, id, className = '', wrapperClassName = '', ...props },
  ref,
): JSX.Element {
  const generatedId = useId();
  const fieldId = id ?? generatedId;
  const helpId = `${fieldId}-help`;
  const errorId = `${fieldId}-error`;
  return (
    <div className={`grid gap-1 ${wrapperClassName}`}>
      <label className="text-base font-semibold text-ink" htmlFor={fieldId}>{label}</label>
      {help && <p className="text-base text-muted" id={helpId}>{help}</p>}
      <input
        {...props}
        ref={ref}
        id={fieldId}
        className={`min-h-touch w-full rounded border bg-surface px-3 text-lg text-ink placeholder:text-muted disabled:bg-neutral-100 ${error ? 'border-critical-700' : 'border-border'} ${className}`}
        aria-invalid={Boolean(error)}
        aria-describedby={[help ? helpId : '', error ? errorId : ''].filter(Boolean).join(' ') || undefined}
      />
      {error && <p className="text-base font-semibold text-critical-700" id={errorId} role="alert">{error}</p>}
    </div>
  );
});

export interface SelectOption {
  value: string;
  label: string;
}

export interface SelectProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'children'> {
  label: string;
  options: SelectOption[];
  placeholder?: string;
  help?: string;
  error?: string;
}

export function Select({ label, options, placeholder, help, error, id, className = '', ...props }: SelectProps): JSX.Element {
  const generatedId = useId();
  const selectId = id ?? generatedId;
  const helpId = `${selectId}-help`;
  const errorId = `${selectId}-error`;
  return (
    <div className="grid gap-1">
      <label className="text-base font-semibold text-ink" htmlFor={selectId}>{label}</label>
      {help && <p className="text-base text-muted" id={helpId}>{help}</p>}
      <div className="relative">
        <select
          {...props}
          id={selectId}
          className={`min-h-touch w-full appearance-none rounded border bg-surface px-3 pr-10 text-base text-ink ${error ? 'border-critical-700' : 'border-border'} ${className}`}
          aria-invalid={Boolean(error)}
          aria-describedby={[help ? helpId : '', error ? errorId : ''].filter(Boolean).join(' ') || undefined}
        >
          {placeholder && <option value="">{placeholder}</option>}
          {options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
        </select>
        <ChevronDown aria-hidden="true" className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted" size={18} />
      </div>
      {error && <p className="text-base font-semibold text-critical-700" id={errorId} role="alert">{error}</p>}
    </div>
  );
}

export interface NumberStepperProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  previousValue?: string;
  unit?: string;
  step?: number;
  mode?: 'numeric' | 'decimal';
  error?: string;
  sameAsPreviousLabel?: string;
}

export function NumberStepper({
  label,
  value,
  onChange,
  previousValue,
  unit,
  step = 1,
  mode = 'numeric',
  error,
  sameAsPreviousLabel = 'Même qu’hier',
}: NumberStepperProps): JSX.Element {
  const inputId = useId();
  const errorId = `${inputId}-error`;
  const numericValue = Number(value.replace(',', '.')) || 0;
  const decimals = String(step).includes('.') ? String(step).split('.')[1].length : 0;
  const adjust = (direction: -1 | 1) => onChange(Math.max(0, numericValue + step * direction).toFixed(decimals));
  return (
    <div className="grid gap-2">
      <label className="text-base font-semibold text-ink" htmlFor={inputId}>{label}{unit ? ` (${unit})` : ''}</label>
      <div className="grid grid-cols-[48px_minmax(0,1fr)_48px] gap-2">
        <Button type="button" variant="secondary" aria-label={`Diminuer ${label}`} onClick={() => adjust(-1)}>
          <Minus aria-hidden="true" size={20} />
        </Button>
        <input
          id={inputId}
          type="text"
          inputMode={mode}
          value={value}
          onChange={(event) => onChange(event.currentTarget.value)}
          className={`min-h-touch min-w-0 rounded border bg-surface px-3 text-center text-2xl font-semibold text-ink ${error ? 'border-critical-700' : 'border-border'}`}
          aria-invalid={Boolean(error)}
          aria-describedby={error ? errorId : undefined}
        />
        <Button type="button" variant="secondary" aria-label={`Augmenter ${label}`} onClick={() => adjust(1)}>
          <Plus aria-hidden="true" size={20} />
        </Button>
      </div>
      {previousValue !== undefined && (
        <Button type="button" variant="ghost" className="justify-self-start" onClick={() => onChange(previousValue)}>
          {sameAsPreviousLabel} : {previousValue}{unit ? ` ${unit}` : ''}
        </Button>
      )}
      {error && <p className="text-base font-semibold text-critical-700" id={errorId} role="alert">{error}</p>}
    </div>
  );
}

export interface DataColumn<Row> {
  key: keyof Row | string;
  header: string;
  align?: 'left' | 'right';
  sortable?: boolean;
  render?: (row: Row) => ReactNode;
}

export interface DataTableProps<Row> {
  rows: Row[];
  columns: DataColumn<Row>[];
  rowKey: (row: Row, index: number) => string;
  loading?: boolean;
  emptyTitle?: string;
  emptyDescription?: string;
  pageSize?: number;
}

export function DataTable<Row>({
  rows,
  columns,
  rowKey,
  loading = false,
  emptyTitle = 'Aucune donnée à afficher',
  emptyDescription = 'Modifiez les filtres ou ajoutez un enregistrement.',
  pageSize = 25,
}: DataTableProps<Row>): JSX.Element {
  const [sortKey, setSortKey] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(0);
  const sortedRows = [...rows].sort((left, right) => {
    if (!sortKey) return 0;
    const a = (left as Record<string, unknown>)[sortKey];
    const b = (right as Record<string, unknown>)[sortKey];
    const comparison = typeof a === 'number' && typeof b === 'number'
      ? a - b
      : String(a ?? '').localeCompare(String(b ?? ''), 'fr');
    return sortDirection === 'asc' ? comparison : -comparison;
  });
  const pageCount = Math.max(1, Math.ceil(sortedRows.length / pageSize));
  const visibleRows = sortedRows.slice(page * pageSize, (page + 1) * pageSize);
  const sortBy = (key: string) => {
    if (sortKey === key) setSortDirection((direction) => direction === 'asc' ? 'desc' : 'asc');
    else {
      setSortKey(key);
      setSortDirection('asc');
    }
    setPage(0);
  };

  if (loading) {
    return <div className="grid gap-2" aria-label="Chargement du tableau" aria-busy="true">
      {[0, 1, 2, 3].map((row) => <div key={row} className="h-10 rounded border border-border bg-neutral-100" />)}
    </div>;
  }
  if (rows.length === 0) return <EmptyState title={emptyTitle} description={emptyDescription} />;

  return (
    <div className="overflow-hidden rounded border border-border bg-surface">
      <div className="max-h-[70vh] overflow-auto">
        <table className="w-full border-collapse text-left text-base">
          <thead className="sticky top-0 z-10 bg-neutral-100 text-ink">
            <tr>
              {columns.map((column) => {
                const key = String(column.key);
                return (
                  <th key={key} scope="col" className={`h-12 border-b border-border px-3 font-semibold ${column.align === 'right' ? 'text-right' : 'text-left'}`}>
                    {column.sortable === false ? column.header : (
                      <button type="button" className="inline-flex min-h-10 items-center gap-1" onClick={() => sortBy(key)} aria-label={`Trier par ${column.header}`}>
                        {column.header}
                        {sortKey === key && (sortDirection === 'asc' ? <ArrowUp aria-hidden="true" size={14} /> : <ArrowDown aria-hidden="true" size={14} />)}
                      </button>
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {visibleRows.map((row, rowIndex) => (
              <tr key={rowKey(row, page * pageSize + rowIndex)} className="h-10 border-b border-border last:border-b-0 hover:bg-neutral-100">
                {columns.map((column) => {
                  const key = String(column.key);
                  const value = (row as Record<string, unknown>)[key];
                  return <td key={key} className={`max-w-72 px-3 py-2 ${column.align === 'right' ? 'text-right tabular-nums' : 'text-left'}`}>
                    {column.render ? column.render(row) : String(value ?? '—')}
                  </td>;
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex min-h-12 items-center justify-between gap-2 border-t border-border px-3">
        <p className="text-base text-muted">{rows.length} ligne{rows.length > 1 ? 's' : ''}</p>
        {pageCount > 1 && <div className="flex items-center gap-2">
          <Button type="button" variant="secondary" aria-label="Page précédente" disabled={page === 0} onClick={() => setPage((value) => Math.max(0, value - 1))}>
            <ChevronLeft aria-hidden="true" size={18} />
          </Button>
          <span className="text-base tabular-nums">{page + 1} / {pageCount}</span>
          <Button type="button" variant="secondary" aria-label="Page suivante" disabled={page >= pageCount - 1} onClick={() => setPage((value) => Math.min(pageCount - 1, value + 1))}>
            <ChevronRight aria-hidden="true" size={18} />
          </Button>
        </div>}
      </div>
    </div>
  );
}

export interface StatCardProps {
  label: string;
  value: ReactNode;
  unit?: string;
  period?: string;
  variation?: string;
  icon?: ReactNode;
}

export function StatCard({ label, value, unit, period, variation, icon }: StatCardProps): JSX.Element {
  return (
    <section className="min-w-0 rounded border border-border bg-surface p-4" aria-label={label}>
      <div className="flex items-start justify-between gap-2">
        <h2 className="text-base font-semibold text-muted">{label}</h2>
        {icon && <span className="text-institutional-700">{icon}</span>}
      </div>
      <p className="mt-2 text-2xl font-semibold leading-tight text-ink tabular-nums">
        {value}{unit && <span className="ml-1 text-base font-medium text-muted">{unit}</span>}
      </p>
      {(period || variation) && <div className="mt-2 flex flex-wrap gap-x-3 text-base text-muted">
        {period && <span>{period}</span>}
        {variation && <span>{variation}</span>}
      </div>}
    </section>
  );
}

export type StatusKind = 'ok' | 'information' | 'attention' | 'critical' | 'neutral';

const statusPresentation: Record<StatusKind, { className: string; icon: typeof CheckCircle2 }> = {
  ok: { className: 'bg-program-50 text-program-700', icon: CheckCircle2 },
  information: { className: 'bg-institutional-50 text-institutional-700', icon: Info },
  attention: { className: 'bg-accent-50 text-ink', icon: AlertTriangle },
  critical: { className: 'bg-critical-50 text-critical-700', icon: AlertCircle },
  neutral: { className: 'bg-neutral-100 text-neutral-700', icon: CircleHelp },
};

export function StatusBadge({ kind, label }: { kind: StatusKind; label: string }): JSX.Element {
  const presentation = statusPresentation[kind];
  const Icon = presentation.icon;
  return <span className={`inline-flex min-h-7 items-center gap-1 rounded border border-transparent px-2 text-base font-semibold ${presentation.className}`}>
    <Icon aria-hidden="true" size={16} strokeWidth={1.75} />{label}
  </span>;
}

export function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }): JSX.Element {
  return <div className="grid justify-items-center gap-2 rounded border border-dashed border-border bg-surface px-4 py-8 text-center">
    <Info aria-hidden="true" className="text-muted" size={24} strokeWidth={1.75} />
    <h2 className="text-lg font-semibold text-ink">{title}</h2>
    <p className="max-w-prose text-base text-muted">{description}</p>
    {action}
  </div>;
}

export function ErrorState({ title, description, onRetry }: { title: string; description: string; onRetry: () => void }): JSX.Element {
  return <div className="grid justify-items-start gap-3 rounded border border-critical-700 bg-critical-50 p-4" role="alert">
    <div className="flex items-start gap-2">
      <AlertCircle aria-hidden="true" className="mt-1 shrink-0 text-critical-700" size={20} />
      <div><h2 className="font-semibold text-critical-700">{title}</h2><p className="text-base text-ink">{description}</p></div>
    </div>
    <Button type="button" variant="secondary" icon={<RefreshCw aria-hidden="true" size={18} />} onClick={onRetry}>Réessayer</Button>
  </div>;
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = 'Confirmer',
  cancelLabel = 'Annuler',
  danger = false,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}): JSX.Element | null {
  if (!open) return null;
  return <div className="fixed inset-0 z-50 grid place-items-center bg-overlay p-4" onMouseDown={(event) => { if (event.target === event.currentTarget) onCancel(); }}>
    <section className="w-full max-w-md rounded border border-border bg-surface p-5 floating-panel" role="dialog" aria-modal="true" aria-labelledby="confirm-dialog-title" aria-describedby="confirm-dialog-description">
      <h2 className="text-xl font-semibold text-ink" id="confirm-dialog-title">{title}</h2>
      <p className="mt-2 text-base text-muted" id="confirm-dialog-description">{description}</p>
      <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button type="button" variant="secondary" onClick={onCancel}>{cancelLabel}</Button>
        <Button type="button" variant={danger ? 'danger' : 'primary'} onClick={onConfirm}>{confirmLabel}</Button>
      </div>
    </section>
  </div>;
}

type ToastKind = 'success' | 'information' | 'attention' | 'critical';
interface ToastMessage { id: number; kind: ToastKind; message: string }
interface ToastContextValue { showToast: (message: string, kind?: ToastKind) => void }
const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: ReactNode }): JSX.Element {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const showToast = (message: string, kind: ToastKind = 'information') => {
    const id = Date.now() + Math.random();
    setToasts((current) => [...current, { id, kind, message }]);
    window.setTimeout(() => setToasts((current) => current.filter((toast) => toast.id !== id)), 6000);
  };
  return <ToastContext.Provider value={{ showToast }}>
    {children}
    <div className="fixed bottom-4 right-4 z-[70] grid w-[min(100%-32px,400px)] gap-2" aria-live="polite" aria-relevant="additions text">
      {toasts.map((toast) => <Toast key={toast.id} toast={toast} onClose={() => setToasts((current) => current.filter((item) => item.id !== toast.id))} />)}
    </div>
  </ToastContext.Provider>;
}

export function useToast(): ToastContextValue {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast doit etre utilise dans ToastProvider.');
  return context;
}

function Toast({ toast, onClose }: { toast: ToastMessage; onClose: () => void }): JSX.Element {
  const styles: Record<ToastKind, string> = {
    success: 'border-program-700 bg-program-50 text-program-700',
    information: 'border-institutional-700 bg-institutional-50 text-institutional-700',
    attention: 'border-accent-600 bg-accent-50 text-ink',
    critical: 'border-critical-700 bg-critical-50 text-critical-700',
  };
  return <div className={`flex min-h-12 items-center justify-between gap-3 rounded border px-3 py-2 floating-panel ${styles[toast.kind]}`} role={toast.kind === 'critical' ? 'alert' : 'status'}>
    <p className="text-base font-medium">{toast.message}</p>
    <button className="touch-target grid shrink-0 place-items-center" type="button" aria-label="Fermer la notification" onClick={onClose}><X aria-hidden="true" size={18} /></button>
  </div>;
}

export function SyncStatusBar({
  online,
  pendingCount,
  conflictCount = 0,
  lastSyncedAt,
  onOpenQueue,
}: {
  online: boolean;
  pendingCount: number;
  conflictCount?: number;
  lastSyncedAt?: Date | null;
  onOpenQueue: () => void;
}): JSX.Element {
  const label = !online ? 'Hors ligne' : pendingCount > 0 ? 'Synchronisation en attente' : 'En ligne';
  const Icon = !online ? CloudOff : pendingCount > 0 ? Cloud : Wifi;
  return <button
    type="button"
    onClick={onOpenQueue}
    className="touch-target flex w-full items-center justify-between gap-3 border-b border-border bg-surface px-4 py-2 text-left transition-colors duration-150 hover:bg-neutral-100"
    aria-label={`${label}. ${pendingCount} élément${pendingCount === 1 ? '' : 's'} en attente${conflictCount ? `, ${conflictCount} conflit${conflictCount === 1 ? '' : 's'}` : ''}. Ouvrir la file de synchronisation.`}
  >
    <span className="flex min-w-0 items-center gap-2">
      <Icon aria-hidden="true" className={!online ? 'text-accent-600' : pendingCount ? 'text-institutional-700' : 'text-program-700'} size={18} strokeWidth={1.75} />
      <span className="truncate text-base font-semibold text-ink">{label}</span>
    </span>
    <span className="flex shrink-0 items-center gap-3 text-base text-muted">
      <span>{pendingCount} en attente</span>
      {conflictCount > 0 && <StatusBadge kind="attention" label={`${conflictCount} conflit${conflictCount === 1 ? '' : 's'}`} />}
      {lastSyncedAt && <span className="hidden sm:inline">Dernière synchro : {new Intl.DateTimeFormat('fr-GA', { dateStyle: 'short', timeStyle: 'short' }).format(lastSyncedAt)}</span>}
    </span>
  </button>;
}

export function PageHeader({ title, description, actions, eyebrow }: { title: string; description?: string; actions?: ReactNode; eyebrow?: string }): JSX.Element {
  return <header className="mb-5 flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-end sm:justify-between">
    <div className="min-w-0">
      {eyebrow && <p className="text-base font-semibold text-institutional-700">{eyebrow}</p>}
      <h1 className="text-2xl font-semibold leading-tight text-ink">{title}</h1>
      {description && <p className="mt-1 text-base text-muted">{description}</p>}
    </div>
    {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
  </header>;
}

export interface TabItem { id: string; label: string; content: ReactNode }

export function Tabs({ items, value, onChange }: { items: TabItem[]; value: string; onChange: (id: string) => void }): JSX.Element {
  const active = items.find((item) => item.id === value) ?? items[0];
  const onKeyDown = (event: React.KeyboardEvent<HTMLButtonElement>) => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const activeIndex = items.findIndex((item) => item.id === value);
    const nextIndex = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1
      : (activeIndex + (event.key === 'ArrowRight' ? 1 : items.length - 1)) % items.length;
    onChange(items[nextIndex].id);
    document.getElementById(`tab-${items[nextIndex].id}`)?.focus();
  };
  return <div>
    <div className="flex gap-1 overflow-x-auto border-b border-border" role="tablist" aria-label="Sections">
      {items.map((item) => <button
        id={`tab-${item.id}`}
        key={item.id}
        type="button"
        role="tab"
        aria-selected={item.id === active.id}
        aria-controls={`panel-${item.id}`}
        tabIndex={item.id === active.id ? 0 : -1}
        className={`min-h-12 shrink-0 border-b-2 px-4 text-base font-semibold transition-colors duration-150 ${item.id === active.id ? 'border-institutional-700 text-institutional-700' : 'border-transparent text-muted hover:text-ink'}`}
        onClick={() => onChange(item.id)}
        onKeyDown={onKeyDown}
      >{item.label}</button>)}
    </div>
    <div id={`panel-${active.id}`} role="tabpanel" aria-labelledby={`tab-${active.id}`} tabIndex={0} className="pt-4">{active.content}</div>
  </div>;
}

export function Timeline({ items }: { items: { id: string; title: string; date: string; description?: string; status?: StatusKind }[] }): JSX.Element {
  if (items.length === 0) return <EmptyState title="Aucun événement enregistré" description="Les étapes apparaîtront ici dès leur enregistrement." />;
  return <ol className="grid gap-0" aria-label="Historique chronologique">
    {items.map((item, index) => <li key={item.id} className="relative grid grid-cols-[24px_minmax(0,1fr)] gap-3 pb-5 last:pb-0">
      {index < items.length - 1 && <span aria-hidden="true" className="absolute bottom-0 left-[11px] top-5 w-px bg-border" />}
      <span className={`z-10 mt-1 h-3 w-3 rounded-full border-2 ${item.status === 'critical' ? 'border-critical-700 bg-critical-50' : item.status === 'ok' ? 'border-program-700 bg-program-50' : 'border-institutional-700 bg-institutional-50'}`} />
      <div>
        <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
          <h3 className="font-semibold text-ink">{item.title}</h3>
          <time className="text-base text-muted">{item.date}</time>
        </div>
        {item.description && <p className="mt-1 text-base text-muted">{item.description}</p>}
      </div>
    </li>)}
  </ol>;
}

export function Drawer({ open, title, onClose, children, side = 'right' }: { open: boolean; title: string; onClose: () => void; children: ReactNode; side?: 'left' | 'right' }): JSX.Element | null {
  if (!open) return null;
  return <div className="fixed inset-0 z-50 bg-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <section
      className={`absolute top-0 flex h-full w-[min(100%,440px)] flex-col border-border bg-surface p-4 floating-panel ${side === 'right' ? 'right-0 border-l' : 'left-0 border-r'}`}
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onKeyDown={(event) => { if (event.key === 'Escape') onClose(); }}
    >
      <header className="flex min-h-12 items-center justify-between gap-3 border-b border-border pb-3">
        <h2 className="text-xl font-semibold text-ink">{title}</h2>
        <Button type="button" variant="ghost" aria-label="Fermer le panneau" onClick={onClose}><X aria-hidden="true" size={20} /></Button>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto py-4">{children}</div>
    </section>
  </div>;
}

export function LoadingState({ label = 'Chargement des données' }: { label?: string }): JSX.Element {
  return <div className="flex min-h-24 items-center gap-3 rounded border border-border bg-surface p-4" role="status" aria-live="polite">
    <LoaderCircle aria-hidden="true" className="text-institutional-700" size={20} />
    <span className="text-base text-muted">{label}</span>
  </div>;
}

export function OfflineState({ lastUpdated }: { lastUpdated?: Date | null }): JSX.Element {
  return <StatusBadge
    kind="attention"
    label={lastUpdated ? `Hors ligne · données du ${new Intl.DateTimeFormat('fr-GA', { dateStyle: 'short', timeStyle: 'short' }).format(lastUpdated)}` : 'Hors ligne · aucune donnée en cache'}
  />;
}

export function SuccessMark({ label }: { label: string }): JSX.Element {
  return <span className="inline-flex items-center gap-2 text-program-700"><Check aria-hidden="true" size={18} />{label}</span>;
}