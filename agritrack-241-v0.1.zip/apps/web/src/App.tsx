export default function App(): JSX.Element {
  return (
    <main>
      <p className="eyebrow">Programme POUFA · DGE</p>
      <h1>AgriTrack 241</h1>
      <p>Socle de suivi des bandes et de traçabilité avicole.</p>
      <p className="status">Interface terrain en préparation</p>
    </main>
  );
}
