-- CreateSchema
CREATE SCHEMA IF NOT EXISTS "public";

-- CreateEnum
CREATE TYPE "ProvinceCode" AS ENUM ('ESTUAIRE', 'HAUT_OGOOUE', 'MOYEN_OGOOUE', 'NGOUNIE', 'NYANGA', 'OGOOUE_IVINDO', 'OGOOUE_LOLO', 'OGOOUE_MARITIME', 'WOLEU_NTEM');

-- CreateEnum
CREATE TYPE "Cohort" AS ENUM ('COHORTE_1', 'COHORTE_2');

-- CreateEnum
CREATE TYPE "FarmStatus" AS ENUM ('DRAFT', 'ACTIVE', 'SUSPENDED', 'CLOSED');

-- CreateEnum
CREATE TYPE "UserStatus" AS ENUM ('ACTIVE', 'DISABLED', 'LOCKED');

-- CreateEnum
CREATE TYPE "RoleCode" AS ENUM ('ELEVEUR', 'AGENT_TECHNIQUE', 'POUFA_DGE', 'VETERINAIRE', 'BCEG', 'MAEDR', 'OPERATEUR', 'AUDITEUR_ANINF', 'ADMIN');

-- CreateEnum
CREATE TYPE "PermissionAction" AS ENUM ('CONSULT', 'CREATE', 'MODIFY', 'VALIDATE', 'ADMINISTER', 'EXPORT');

-- CreateEnum
CREATE TYPE "UserScopeKind" AS ENUM ('FARM', 'PROVINCE');

-- CreateEnum
CREATE TYPE "FarmUserKind" AS ENUM ('OWNER', 'MANAGER', 'TECHNICIAN');

-- CreateEnum
CREATE TYPE "ConsentStatus" AS ENUM ('GRANTED', 'REVOKED');

-- CreateEnum
CREATE TYPE "BatchStatus" AS ENUM ('PLANNED', 'ACTIVE', 'CLOSED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "AlertStatus" AS ENUM ('NEW', 'UNDER_REVIEW', 'CONFIRMED', 'REFUTED', 'CLOSED');

-- CreateEnum
CREATE TYPE "AlertSeverity" AS ENUM ('LOW', 'MODERATE', 'HIGH', 'CRITICAL');

-- CreateEnum
CREATE TYPE "OutflowType" AS ENUM ('SLAUGHTER', 'SALE', 'TRANSFER', 'CULL', 'OTHER');

-- CreateEnum
CREATE TYPE "InputOrderStatus" AS ENUM ('DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED', 'DELIVERED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "DeclarationStatus" AS ENUM ('SUBMITTED', 'UNDER_REVIEW', 'QUALIFIED', 'REJECTED');

-- CreateEnum
CREATE TYPE "LotStatus" AS ENUM ('OPEN', 'CLOSED', 'REJECTED');

-- CreateEnum
CREATE TYPE "LotEventType" AS ENUM ('CREATED', 'SLAUGHTERED', 'PACKED', 'DISPATCHED', 'RECEIVED', 'SOLD', 'RECALLED', 'TRANSFER_VERIFIED');

-- CreateEnum
CREATE TYPE "ParameterValueType" AS ENUM ('STRING', 'NUMBER', 'BOOLEAN', 'JSON');

-- CreateEnum
CREATE TYPE "ConfigurationStatus" AS ENUM ('PROPOSED', 'APPROVED', 'RETIRED');

-- CreateEnum
CREATE TYPE "AggregateStatus" AS ENUM ('DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED', 'PUBLISHED', 'WITHDRAWN');

-- CreateEnum
CREATE TYPE "SyncConflictStatus" AS ENUM ('OPEN', 'RESOLVED');

-- CreateEnum
CREATE TYPE "ImportStatus" AS ENUM ('QUEUED', 'PROCESSING', 'COMPLETED', 'PARTIAL', 'FAILED');

-- CreateTable
CREATE TABLE "Province" (
    "code" "ProvinceCode" NOT NULL,
    "name" TEXT NOT NULL,
    "minLatitude" DECIMAL(9,6),
    "maxLatitude" DECIMAL(9,6),
    "minLongitude" DECIMAL(9,6),
    "maxLongitude" DECIMAL(9,6),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Province_pkey" PRIMARY KEY ("code")
);

-- CreateTable
CREATE TABLE "Locality" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "provinceCode" "ProvinceCode" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Locality_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Farm" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "status" "FarmStatus" NOT NULL DEFAULT 'DRAFT',
    "cohort" "Cohort" NOT NULL,
    "provinceCode" "ProvinceCode" NOT NULL,
    "localityId" TEXT NOT NULL,
    "latitude" DECIMAL(9,6) NOT NULL,
    "longitude" DECIMAL(9,6) NOT NULL,
    "capacity" INTEGER NOT NULL,
    "infrastructure" JSONB NOT NULL DEFAULT '{}',
    "bcegFinanced" BOOLEAN NOT NULL DEFAULT false,
    "revenueDomiciliation" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "archivedAt" TIMESTAMP(3),

    CONSTRAINT "Farm_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FarmStatusHistory" (
    "id" TEXT NOT NULL,
    "farmId" TEXT NOT NULL,
    "fromStatus" "FarmStatus",
    "toStatus" "FarmStatus" NOT NULL,
    "changedById" TEXT NOT NULL,
    "changedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reason" TEXT,

    CONSTRAINT "FarmStatusHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FarmConsentHistory" (
    "id" TEXT NOT NULL,
    "farmId" TEXT NOT NULL,
    "status" "ConsentStatus" NOT NULL,
    "purpose" TEXT NOT NULL,
    "consentedBy" TEXT NOT NULL,
    "effectiveAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "revokedAt" TIMESTAMP(3),
    "evidenceRef" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "FarmConsentHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "phone" TEXT,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "lastLoginAt" TIMESTAMP(3),

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Role" (
    "id" TEXT NOT NULL,
    "code" "RoleCode" NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Role_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserRole" (
    "userId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,
    "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "assignedBy" TEXT,

    CONSTRAINT "UserRole_pkey" PRIMARY KEY ("userId","roleId")
);

-- CreateTable
CREATE TABLE "AuthSession" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "refreshTokenHash" CHAR(64) NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "revokedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastUsedAt" TIMESTAMP(3),
    "userAgent" TEXT,
    "ipHash" TEXT,

    CONSTRAINT "AuthSession_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Permission" (
    "id" TEXT NOT NULL,
    "resource" TEXT NOT NULL,
    "action" "PermissionAction" NOT NULL,
    "description" TEXT,

    CONSTRAINT "Permission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RolePermission" (
    "roleId" TEXT NOT NULL,
    "permissionId" TEXT NOT NULL,
    "grantedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "RolePermission_pkey" PRIMARY KEY ("roleId","permissionId")
);

-- CreateTable
CREATE TABLE "UserScope" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "kind" "UserScopeKind" NOT NULL,
    "farmId" TEXT,
    "provinceCode" "ProvinceCode",
    "grantedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "UserScope_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FarmUserAssignment" (
    "farmId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "kind" "FarmUserKind" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "FarmUserAssignment_pkey" PRIMARY KEY ("farmId","userId","kind")
);

-- CreateTable
CREATE TABLE "Batch" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID,
    "code" TEXT NOT NULL,
    "farmId" TEXT NOT NULL,
    "rank" INTEGER NOT NULL,
    "status" "BatchStatus" NOT NULL DEFAULT 'PLANNED',
    "placedAt" TIMESTAMP(3) NOT NULL,
    "plannedCloseAt" TIMESTAMP(3),
    "closedAt" TIMESTAMP(3),
    "placedCount" INTEGER NOT NULL,
    "initialAverageWeight" DECIMAL(10,3),
    "initialStock" INTEGER,
    "lockVersion" INTEGER NOT NULL DEFAULT 0,
    "isLocked" BOOLEAN NOT NULL DEFAULT false,
    "lockedAt" TIMESTAMP(3),
    "closureSummary" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Batch_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BatchStatusHistory" (
    "id" TEXT NOT NULL,
    "batchId" TEXT NOT NULL,
    "fromStatus" "BatchStatus",
    "toStatus" "BatchStatus" NOT NULL,
    "changedById" TEXT NOT NULL,
    "changedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reason" TEXT,

    CONSTRAINT "BatchStatusHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DailyRecord" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "batchId" TEXT NOT NULL,
    "recordDate" DATE NOT NULL,
    "deaths" INTEGER NOT NULL DEFAULT 0,
    "feedConsumedKg" DECIMAL(12,3) NOT NULL DEFAULT 0,
    "waterConsumedLiters" DECIMAL(12,3),
    "suspicionReported" BOOLEAN NOT NULL DEFAULT false,
    "notes" TEXT,
    "recordedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "recordedById" TEXT,
    "syncUpdatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "serverUpdatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DailyRecord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Weighing" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "batchId" TEXT NOT NULL,
    "weighedAt" TIMESTAMP(3) NOT NULL,
    "sampleCount" INTEGER NOT NULL,
    "averageWeight" DECIMAL(10,3) NOT NULL,
    "minWeight" DECIMAL(10,3),
    "maxWeight" DECIMAL(10,3),
    "recordedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "recordedById" TEXT,

    CONSTRAINT "Weighing_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Outflow" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "batchId" TEXT NOT NULL,
    "type" "OutflowType" NOT NULL,
    "occurredAt" TIMESTAMP(3) NOT NULL,
    "quantity" INTEGER NOT NULL,
    "averageWeight" DECIMAL(10,3),
    "destination" TEXT,
    "reference" TEXT,
    "recordedById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Outflow_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "InputReceipt" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "farmId" TEXT NOT NULL,
    "batchId" TEXT,
    "inputCode" TEXT NOT NULL,
    "quantity" DECIMAL(14,3) NOT NULL,
    "unitCost" DECIMAL(14,2),
    "confirmedQuantity" DECIMAL(14,3),
    "unit" TEXT NOT NULL,
    "receivedAt" TIMESTAMP(3) NOT NULL,
    "confirmedAt" TIMESTAMP(3),
    "confirmedById" TEXT,
    "supplier" TEXT,
    "subsidized" BOOLEAN NOT NULL DEFAULT false,
    "subsidyReference" TEXT,
    "lotNumber" TEXT,
    "recordedById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "InputReceipt_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "InputUsage" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "farmId" TEXT NOT NULL,
    "batchId" TEXT,
    "inputCode" TEXT NOT NULL,
    "quantity" DECIMAL(14,3) NOT NULL,
    "unit" TEXT NOT NULL,
    "usedAt" TIMESTAMP(3) NOT NULL,
    "receiptId" TEXT,
    "recordedById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "InputUsage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "InputOrder" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "farmId" TEXT NOT NULL,
    "batchId" TEXT,
    "orderNumber" TEXT NOT NULL,
    "status" "InputOrderStatus" NOT NULL DEFAULT 'DRAFT',
    "items" JSONB NOT NULL,
    "submittedAt" TIMESTAMP(3),
    "approvedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "InputOrder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HealthDeclaration" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "farmId" TEXT NOT NULL,
    "batchId" TEXT,
    "symptoms" TEXT NOT NULL,
    "suspectedCondition" TEXT,
    "affectedCount" INTEGER,
    "declaredAt" TIMESTAMP(3) NOT NULL,
    "status" "DeclarationStatus" NOT NULL DEFAULT 'SUBMITTED',
    "reportedById" TEXT NOT NULL,
    "reviewedById" TEXT,
    "reviewedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "HealthDeclaration_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "VaccinationCalendar" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "vaccine" TEXT NOT NULL,
    "ageDay" INTEGER NOT NULL,
    "route" TEXT,
    "dose" TEXT,
    "provinceCode" "ProvinceCode",
    "activeFrom" TIMESTAMP(3),
    "activeTo" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "VaccinationCalendar_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Vaccination" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "batchId" TEXT NOT NULL,
    "calendarId" TEXT,
    "vaccine" TEXT NOT NULL,
    "administeredAt" TIMESTAMP(3) NOT NULL,
    "dose" TEXT,
    "quantity" DECIMAL(12,3),
    "batchNumber" TEXT,
    "administeredBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Vaccination_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Treatment" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "batchId" TEXT NOT NULL,
    "lotId" TEXT,
    "product" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "startedAt" TIMESTAMP(3) NOT NULL,
    "endedAt" TIMESTAMP(3),
    "dosage" TEXT,
    "withdrawalEndsAt" TIMESTAMP(3),
    "prescribedBy" TEXT,
    "recordedById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Treatment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "VetIntervention" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "farmId" TEXT NOT NULL,
    "batchId" TEXT,
    "declarationId" TEXT,
    "vetId" TEXT NOT NULL,
    "visitedAt" TIMESTAMP(3) NOT NULL,
    "findings" TEXT NOT NULL,
    "diagnosis" TEXT,
    "recommendations" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "VetIntervention_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Alert" (
    "id" TEXT NOT NULL,
    "batchId" TEXT,
    "farmId" TEXT NOT NULL,
    "healthDeclarationId" TEXT,
    "sourceDailyRecordId" TEXT,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "severity" "AlertSeverity" NOT NULL,
    "status" "AlertStatus" NOT NULL DEFAULT 'NEW',
    "createdById" TEXT,
    "qualifiedById" TEXT,
    "qualifiedAt" TIMESTAMP(3),
    "publishedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Alert_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AlertStatusHistory" (
    "id" TEXT NOT NULL,
    "alertId" TEXT NOT NULL,
    "fromStatus" "AlertStatus",
    "toStatus" "AlertStatus" NOT NULL,
    "changedById" TEXT NOT NULL,
    "changedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "note" TEXT,
    "event" TEXT NOT NULL DEFAULT 'STATUS_CHANGE',

    CONSTRAINT "AlertStatusHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BiosecurityGrid" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "description" TEXT,
    "points" DECIMAL(8,3) NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BiosecurityGrid_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BiosecurityCheck" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "farmId" TEXT NOT NULL,
    "batchId" TEXT,
    "checkedAt" TIMESTAMP(3) NOT NULL,
    "checkedById" TEXT,
    "score" DECIMAL(6,2),
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "BiosecurityCheck_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BiosecurityCheckItem" (
    "checkId" TEXT NOT NULL,
    "gridId" TEXT NOT NULL,
    "compliant" BOOLEAN NOT NULL,
    "note" TEXT,

    CONSTRAINT "BiosecurityCheckItem_pkey" PRIMARY KEY ("checkId","gridId")
);

-- CreateTable
CREATE TABLE "Visit" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "farmId" TEXT NOT NULL,
    "batchId" TEXT,
    "visitorId" TEXT NOT NULL,
    "visitedAt" TIMESTAMP(3) NOT NULL,
    "purpose" TEXT NOT NULL,
    "findings" TEXT,
    "followUpAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Visit_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Expense" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "farmId" TEXT NOT NULL,
    "batchId" TEXT,
    "category" TEXT NOT NULL,
    "description" TEXT,
    "amount" DECIMAL(14,2) NOT NULL,
    "sourceInputUsageId" TEXT,
    "incurredAt" TIMESTAMP(3) NOT NULL,
    "reference" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Expense_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Sale" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "batchId" TEXT NOT NULL,
    "operatorId" TEXT,
    "outflowId" TEXT,
    "soldAt" TIMESTAMP(3) NOT NULL,
    "quantity" DECIMAL(14,3) NOT NULL,
    "unit" TEXT NOT NULL,
    "unitPrice" DECIMAL(14,2) NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'XAF',
    "invoiceReference" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Sale_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Operator" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "operatorType" TEXT NOT NULL,
    "agreementSignedAt" TIMESTAMP(3),
    "agreementExpiresAt" TIMESTAMP(3),
    "agreementReference" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Operator_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OperatorUserAssignment" (
    "operatorId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "assignedBy" TEXT,

    CONSTRAINT "OperatorUserAssignment_pkey" PRIMARY KEY ("operatorId","userId")
);

-- CreateTable
CREATE TABLE "Lot" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "batchId" TEXT NOT NULL,
    "operatorId" TEXT,
    "outflowId" TEXT,
    "rank" INTEGER NOT NULL,
    "quantity" INTEGER NOT NULL,
    "status" "LotStatus" NOT NULL DEFAULT 'OPEN',
    "producedAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Lot_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LotEvent" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "lotId" TEXT NOT NULL,
    "eventType" "LotEventType" NOT NULL,
    "occurredAt" TIMESTAMP(3) NOT NULL,
    "location" TEXT,
    "details" JSONB NOT NULL DEFAULT '{}',
    "recordedById" TEXT,
    "verified" BOOLEAN NOT NULL DEFAULT false,
    "verifiedById" TEXT,
    "verifiedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "LotEvent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LotReception" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "lotEventId" TEXT NOT NULL,
    "operatorId" TEXT NOT NULL,
    "announcedQuantity" INTEGER NOT NULL,
    "receivedQuantity" INTEGER NOT NULL,
    "discrepancyPercent" DECIMAL(8,3) NOT NULL,
    "thresholdPercent" DECIMAL(65,30),
    "discrepancyFlagged" BOOLEAN NOT NULL DEFAULT false,
    "receivedAt" TIMESTAMP(3) NOT NULL,
    "receivedById" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "LotReception_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QrCode" (
    "id" TEXT NOT NULL,
    "token" UUID NOT NULL,
    "lotId" TEXT NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "closedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "QrCode_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ScanLog" (
    "id" TEXT NOT NULL,
    "qrCodeId" TEXT,
    "submittedToken" TEXT NOT NULL,
    "scannedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ipHash" TEXT,
    "userAgent" TEXT,
    "outcome" TEXT NOT NULL,

    CONSTRAINT "ScanLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" TEXT NOT NULL,
    "sequence" BIGSERIAL NOT NULL,
    "actorId" TEXT,
    "action" TEXT NOT NULL,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "occurredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "before" JSONB,
    "after" JSONB,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "previousHash" TEXT,
    "entryHash" CHAR(64) NOT NULL,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Parameter" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "valueType" "ParameterValueType" NOT NULL,
    "value" JSONB NOT NULL,
    "version" INTEGER NOT NULL,
    "status" "ConfigurationStatus" NOT NULL DEFAULT 'PROPOSED',
    "description" TEXT,
    "unit" TEXT,
    "createdById" TEXT,
    "approvedById" TEXT,
    "effectiveAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Parameter_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Formula" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "expression" TEXT NOT NULL,
    "variables" JSONB NOT NULL,
    "version" INTEGER NOT NULL,
    "status" "ConfigurationStatus" NOT NULL DEFAULT 'PROPOSED',
    "description" TEXT,
    "createdById" TEXT,
    "approvedById" TEXT,
    "effectiveAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Formula_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Threshold" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "value" DECIMAL(14,5) NOT NULL,
    "unit" TEXT,
    "version" INTEGER NOT NULL,
    "status" "ConfigurationStatus" NOT NULL DEFAULT 'PROPOSED',
    "veterinarianOnly" BOOLEAN NOT NULL DEFAULT false,
    "description" TEXT,
    "createdById" TEXT,
    "approvedById" TEXT,
    "effectiveAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Threshold_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ListValue" (
    "id" TEXT NOT NULL,
    "listKey" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "version" INTEGER NOT NULL DEFAULT 1,
    "metadata" JSONB NOT NULL DEFAULT '{}',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ListValue_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReportTemplate" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "definition" JSONB NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "version" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ReportTemplate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PublishedAggregate" (
    "id" TEXT NOT NULL,
    "reportKey" TEXT NOT NULL,
    "periodStart" DATE NOT NULL,
    "periodEnd" DATE NOT NULL,
    "dimensions" JSONB NOT NULL,
    "data" JSONB NOT NULL,
    "status" "AggregateStatus" NOT NULL DEFAULT 'DRAFT',
    "submittedAt" TIMESTAMP(3),
    "approvedById" TEXT,
    "approvedAt" TIMESTAMP(3),
    "publishedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PublishedAggregate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SyncConflict" (
    "id" TEXT NOT NULL,
    "clientUuid" UUID NOT NULL,
    "userId" TEXT,
    "entityType" TEXT NOT NULL,
    "entityId" TEXT NOT NULL,
    "clientUpdatedAt" TIMESTAMP(3) NOT NULL,
    "serverUpdatedAt" TIMESTAMP(3) NOT NULL,
    "clientPayload" JSONB NOT NULL,
    "serverPayload" JSONB NOT NULL,
    "resolution" TEXT,
    "status" "SyncConflictStatus" NOT NULL DEFAULT 'OPEN',
    "resolvedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SyncConflict_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ImportReport" (
    "id" TEXT NOT NULL,
    "uploadedById" TEXT NOT NULL,
    "fileName" TEXT NOT NULL,
    "fileHash" CHAR(64) NOT NULL,
    "status" "ImportStatus" NOT NULL DEFAULT 'QUEUED',
    "totalRows" INTEGER NOT NULL DEFAULT 0,
    "successRows" INTEGER NOT NULL DEFAULT 0,
    "errorRows" INTEGER NOT NULL DEFAULT 0,
    "report" JSONB NOT NULL DEFAULT '{}',
    "startedAt" TIMESTAMP(3),
    "completedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ImportReport_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "IdentifierCounter" (
    "key" TEXT NOT NULL,
    "nextValue" INTEGER NOT NULL DEFAULT 1,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "IdentifierCounter_pkey" PRIMARY KEY ("key")
);

-- CreateTable
CREATE TABLE "Notification" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "entityType" TEXT,
    "entityId" TEXT,
    "readAt" TIMESTAMP(3),
    "deliveryStatus" TEXT NOT NULL DEFAULT 'PENDING',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Province_name_key" ON "Province"("name");

-- CreateIndex
CREATE INDEX "Locality_provinceCode_idx" ON "Locality"("provinceCode");

-- CreateIndex
CREATE UNIQUE INDEX "Locality_provinceCode_name_key" ON "Locality"("provinceCode", "name");

-- CreateIndex
CREATE UNIQUE INDEX "Farm_code_key" ON "Farm"("code");

-- CreateIndex
CREATE INDEX "Farm_provinceCode_status_idx" ON "Farm"("provinceCode", "status");

-- CreateIndex
CREATE INDEX "Farm_localityId_idx" ON "Farm"("localityId");

-- CreateIndex
CREATE INDEX "Farm_cohort_status_idx" ON "Farm"("cohort", "status");

-- CreateIndex
CREATE INDEX "Farm_bcegFinanced_idx" ON "Farm"("bcegFinanced");

-- CreateIndex
CREATE INDEX "FarmStatusHistory_farmId_changedAt_idx" ON "FarmStatusHistory"("farmId", "changedAt");

-- CreateIndex
CREATE INDEX "FarmConsentHistory_farmId_effectiveAt_idx" ON "FarmConsentHistory"("farmId", "effectiveAt");

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE INDEX "User_status_idx" ON "User"("status");

-- CreateIndex
CREATE UNIQUE INDEX "Role_code_key" ON "Role"("code");

-- CreateIndex
CREATE UNIQUE INDEX "Role_name_key" ON "Role"("name");

-- CreateIndex
CREATE INDEX "UserRole_roleId_idx" ON "UserRole"("roleId");

-- CreateIndex
CREATE UNIQUE INDEX "AuthSession_refreshTokenHash_key" ON "AuthSession"("refreshTokenHash");

-- CreateIndex
CREATE INDEX "AuthSession_userId_revokedAt_expiresAt_idx" ON "AuthSession"("userId", "revokedAt", "expiresAt");

-- CreateIndex
CREATE INDEX "Permission_action_idx" ON "Permission"("action");

-- CreateIndex
CREATE UNIQUE INDEX "Permission_resource_action_key" ON "Permission"("resource", "action");

-- CreateIndex
CREATE INDEX "UserScope_userId_kind_idx" ON "UserScope"("userId", "kind");

-- CreateIndex
CREATE UNIQUE INDEX "UserScope_userId_farmId_key" ON "UserScope"("userId", "farmId");

-- CreateIndex
CREATE UNIQUE INDEX "UserScope_userId_provinceCode_key" ON "UserScope"("userId", "provinceCode");

-- CreateIndex
CREATE INDEX "FarmUserAssignment_userId_kind_idx" ON "FarmUserAssignment"("userId", "kind");

-- CreateIndex
CREATE UNIQUE INDEX "Batch_clientUuid_key" ON "Batch"("clientUuid");

-- CreateIndex
CREATE UNIQUE INDEX "Batch_code_key" ON "Batch"("code");

-- CreateIndex
CREATE INDEX "Batch_farmId_status_idx" ON "Batch"("farmId", "status");

-- CreateIndex
CREATE INDEX "Batch_status_placedAt_idx" ON "Batch"("status", "placedAt");

-- CreateIndex
CREATE UNIQUE INDEX "Batch_farmId_rank_key" ON "Batch"("farmId", "rank");

-- CreateIndex
CREATE INDEX "BatchStatusHistory_batchId_changedAt_idx" ON "BatchStatusHistory"("batchId", "changedAt");

-- CreateIndex
CREATE UNIQUE INDEX "DailyRecord_clientUuid_key" ON "DailyRecord"("clientUuid");

-- CreateIndex
CREATE INDEX "DailyRecord_recordDate_idx" ON "DailyRecord"("recordDate");

-- CreateIndex
CREATE INDEX "DailyRecord_batchId_syncUpdatedAt_idx" ON "DailyRecord"("batchId", "syncUpdatedAt");

-- CreateIndex
CREATE UNIQUE INDEX "DailyRecord_batchId_recordDate_key" ON "DailyRecord"("batchId", "recordDate");

-- CreateIndex
CREATE UNIQUE INDEX "Weighing_clientUuid_key" ON "Weighing"("clientUuid");

-- CreateIndex
CREATE INDEX "Weighing_batchId_weighedAt_idx" ON "Weighing"("batchId", "weighedAt");

-- CreateIndex
CREATE UNIQUE INDEX "Outflow_clientUuid_key" ON "Outflow"("clientUuid");

-- CreateIndex
CREATE INDEX "Outflow_batchId_occurredAt_idx" ON "Outflow"("batchId", "occurredAt");

-- CreateIndex
CREATE INDEX "Outflow_type_occurredAt_idx" ON "Outflow"("type", "occurredAt");

-- CreateIndex
CREATE UNIQUE INDEX "InputReceipt_clientUuid_key" ON "InputReceipt"("clientUuid");

-- CreateIndex
CREATE INDEX "InputReceipt_farmId_inputCode_receivedAt_idx" ON "InputReceipt"("farmId", "inputCode", "receivedAt");

-- CreateIndex
CREATE INDEX "InputReceipt_batchId_idx" ON "InputReceipt"("batchId");

-- CreateIndex
CREATE UNIQUE INDEX "InputUsage_clientUuid_key" ON "InputUsage"("clientUuid");

-- CreateIndex
CREATE INDEX "InputUsage_farmId_inputCode_usedAt_idx" ON "InputUsage"("farmId", "inputCode", "usedAt");

-- CreateIndex
CREATE INDEX "InputUsage_batchId_idx" ON "InputUsage"("batchId");

-- CreateIndex
CREATE INDEX "InputUsage_receiptId_idx" ON "InputUsage"("receiptId");

-- CreateIndex
CREATE UNIQUE INDEX "InputOrder_clientUuid_key" ON "InputOrder"("clientUuid");

-- CreateIndex
CREATE UNIQUE INDEX "InputOrder_orderNumber_key" ON "InputOrder"("orderNumber");

-- CreateIndex
CREATE INDEX "InputOrder_farmId_status_idx" ON "InputOrder"("farmId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "HealthDeclaration_clientUuid_key" ON "HealthDeclaration"("clientUuid");

-- CreateIndex
CREATE INDEX "HealthDeclaration_farmId_declaredAt_idx" ON "HealthDeclaration"("farmId", "declaredAt");

-- CreateIndex
CREATE INDEX "HealthDeclaration_status_declaredAt_idx" ON "HealthDeclaration"("status", "declaredAt");

-- CreateIndex
CREATE UNIQUE INDEX "VaccinationCalendar_code_key" ON "VaccinationCalendar"("code");

-- CreateIndex
CREATE INDEX "VaccinationCalendar_ageDay_idx" ON "VaccinationCalendar"("ageDay");

-- CreateIndex
CREATE INDEX "VaccinationCalendar_provinceCode_idx" ON "VaccinationCalendar"("provinceCode");

-- CreateIndex
CREATE UNIQUE INDEX "Vaccination_clientUuid_key" ON "Vaccination"("clientUuid");

-- CreateIndex
CREATE INDEX "Vaccination_batchId_administeredAt_idx" ON "Vaccination"("batchId", "administeredAt");

-- CreateIndex
CREATE UNIQUE INDEX "Treatment_clientUuid_key" ON "Treatment"("clientUuid");

-- CreateIndex
CREATE INDEX "Treatment_batchId_startedAt_idx" ON "Treatment"("batchId", "startedAt");

-- CreateIndex
CREATE UNIQUE INDEX "VetIntervention_clientUuid_key" ON "VetIntervention"("clientUuid");

-- CreateIndex
CREATE INDEX "VetIntervention_farmId_visitedAt_idx" ON "VetIntervention"("farmId", "visitedAt");

-- CreateIndex
CREATE INDEX "VetIntervention_batchId_idx" ON "VetIntervention"("batchId");

-- CreateIndex
CREATE UNIQUE INDEX "Alert_healthDeclarationId_key" ON "Alert"("healthDeclarationId");

-- CreateIndex
CREATE UNIQUE INDEX "Alert_sourceDailyRecordId_key" ON "Alert"("sourceDailyRecordId");

-- CreateIndex
CREATE INDEX "Alert_farmId_status_idx" ON "Alert"("farmId", "status");

-- CreateIndex
CREATE INDEX "Alert_status_severity_createdAt_idx" ON "Alert"("status", "severity", "createdAt");

-- CreateIndex
CREATE INDEX "AlertStatusHistory_alertId_changedAt_idx" ON "AlertStatusHistory"("alertId", "changedAt");

-- CreateIndex
CREATE UNIQUE INDEX "BiosecurityGrid_code_key" ON "BiosecurityGrid"("code");

-- CreateIndex
CREATE UNIQUE INDEX "BiosecurityCheck_clientUuid_key" ON "BiosecurityCheck"("clientUuid");

-- CreateIndex
CREATE INDEX "BiosecurityCheck_farmId_checkedAt_idx" ON "BiosecurityCheck"("farmId", "checkedAt");

-- CreateIndex
CREATE UNIQUE INDEX "Visit_clientUuid_key" ON "Visit"("clientUuid");

-- CreateIndex
CREATE INDEX "Visit_farmId_visitedAt_idx" ON "Visit"("farmId", "visitedAt");

-- CreateIndex
CREATE UNIQUE INDEX "Expense_clientUuid_key" ON "Expense"("clientUuid");

-- CreateIndex
CREATE UNIQUE INDEX "Expense_sourceInputUsageId_key" ON "Expense"("sourceInputUsageId");

-- CreateIndex
CREATE INDEX "Expense_farmId_incurredAt_idx" ON "Expense"("farmId", "incurredAt");

-- CreateIndex
CREATE INDEX "Expense_batchId_category_idx" ON "Expense"("batchId", "category");

-- CreateIndex
CREATE UNIQUE INDEX "Sale_clientUuid_key" ON "Sale"("clientUuid");

-- CreateIndex
CREATE UNIQUE INDEX "Sale_outflowId_key" ON "Sale"("outflowId");

-- CreateIndex
CREATE INDEX "Sale_batchId_soldAt_idx" ON "Sale"("batchId", "soldAt");

-- CreateIndex
CREATE INDEX "Sale_operatorId_idx" ON "Sale"("operatorId");

-- CreateIndex
CREATE UNIQUE INDEX "Operator_code_key" ON "Operator"("code");

-- CreateIndex
CREATE INDEX "Operator_active_operatorType_idx" ON "Operator"("active", "operatorType");

-- CreateIndex
CREATE INDEX "OperatorUserAssignment_userId_idx" ON "OperatorUserAssignment"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "Lot_code_key" ON "Lot"("code");

-- CreateIndex
CREATE INDEX "Lot_operatorId_status_idx" ON "Lot"("operatorId", "status");

-- CreateIndex
CREATE INDEX "Lot_batchId_status_idx" ON "Lot"("batchId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "Lot_batchId_rank_key" ON "Lot"("batchId", "rank");

-- CreateIndex
CREATE UNIQUE INDEX "LotEvent_clientUuid_key" ON "LotEvent"("clientUuid");

-- CreateIndex
CREATE INDEX "LotEvent_lotId_occurredAt_idx" ON "LotEvent"("lotId", "occurredAt");

-- CreateIndex
CREATE INDEX "LotEvent_eventType_occurredAt_idx" ON "LotEvent"("eventType", "occurredAt");

-- CreateIndex
CREATE UNIQUE INDEX "LotReception_clientUuid_key" ON "LotReception"("clientUuid");

-- CreateIndex
CREATE UNIQUE INDEX "LotReception_lotEventId_key" ON "LotReception"("lotEventId");

-- CreateIndex
CREATE INDEX "LotReception_operatorId_receivedAt_idx" ON "LotReception"("operatorId", "receivedAt");

-- CreateIndex
CREATE INDEX "LotReception_discrepancyFlagged_receivedAt_idx" ON "LotReception"("discrepancyFlagged", "receivedAt");

-- CreateIndex
CREATE UNIQUE INDEX "QrCode_token_key" ON "QrCode"("token");

-- CreateIndex
CREATE UNIQUE INDEX "QrCode_lotId_key" ON "QrCode"("lotId");

-- CreateIndex
CREATE INDEX "ScanLog_qrCodeId_scannedAt_idx" ON "ScanLog"("qrCodeId", "scannedAt");

-- CreateIndex
CREATE INDEX "ScanLog_scannedAt_idx" ON "ScanLog"("scannedAt");

-- CreateIndex
CREATE UNIQUE INDEX "AuditLog_sequence_key" ON "AuditLog"("sequence");

-- CreateIndex
CREATE UNIQUE INDEX "AuditLog_entryHash_key" ON "AuditLog"("entryHash");

-- CreateIndex
CREATE INDEX "AuditLog_entityType_entityId_occurredAt_idx" ON "AuditLog"("entityType", "entityId", "occurredAt");

-- CreateIndex
CREATE INDEX "AuditLog_actorId_occurredAt_idx" ON "AuditLog"("actorId", "occurredAt");

-- CreateIndex
CREATE INDEX "AuditLog_occurredAt_idx" ON "AuditLog"("occurredAt");

-- CreateIndex
CREATE INDEX "Parameter_key_status_effectiveAt_idx" ON "Parameter"("key", "status", "effectiveAt");

-- CreateIndex
CREATE UNIQUE INDEX "Parameter_key_version_key" ON "Parameter"("key", "version");

-- CreateIndex
CREATE INDEX "Formula_key_status_effectiveAt_idx" ON "Formula"("key", "status", "effectiveAt");

-- CreateIndex
CREATE UNIQUE INDEX "Formula_key_version_key" ON "Formula"("key", "version");

-- CreateIndex
CREATE INDEX "Threshold_key_status_effectiveAt_idx" ON "Threshold"("key", "status", "effectiveAt");

-- CreateIndex
CREATE UNIQUE INDEX "Threshold_key_version_key" ON "Threshold"("key", "version");

-- CreateIndex
CREATE INDEX "ListValue_listKey_active_sortOrder_idx" ON "ListValue"("listKey", "active", "sortOrder");

-- CreateIndex
CREATE UNIQUE INDEX "ListValue_listKey_code_version_key" ON "ListValue"("listKey", "code", "version");

-- CreateIndex
CREATE INDEX "ReportTemplate_key_active_idx" ON "ReportTemplate"("key", "active");

-- CreateIndex
CREATE UNIQUE INDEX "ReportTemplate_key_version_key" ON "ReportTemplate"("key", "version");

-- CreateIndex
CREATE INDEX "PublishedAggregate_status_periodEnd_idx" ON "PublishedAggregate"("status", "periodEnd");

-- CreateIndex
CREATE UNIQUE INDEX "PublishedAggregate_reportKey_periodStart_periodEnd_key" ON "PublishedAggregate"("reportKey", "periodStart", "periodEnd");

-- CreateIndex
CREATE INDEX "SyncConflict_status_createdAt_idx" ON "SyncConflict"("status", "createdAt");

-- CreateIndex
CREATE INDEX "SyncConflict_entityType_entityId_idx" ON "SyncConflict"("entityType", "entityId");

-- CreateIndex
CREATE UNIQUE INDEX "SyncConflict_clientUuid_entityType_key" ON "SyncConflict"("clientUuid", "entityType");

-- CreateIndex
CREATE INDEX "ImportReport_uploadedById_createdAt_idx" ON "ImportReport"("uploadedById", "createdAt");

-- CreateIndex
CREATE INDEX "ImportReport_status_createdAt_idx" ON "ImportReport"("status", "createdAt");

-- CreateIndex
CREATE INDEX "Notification_userId_readAt_createdAt_idx" ON "Notification"("userId", "readAt", "createdAt");

-- CreateIndex
CREATE INDEX "Notification_category_createdAt_idx" ON "Notification"("category", "createdAt");

-- AddForeignKey
ALTER TABLE "Locality" ADD CONSTRAINT "Locality_provinceCode_fkey" FOREIGN KEY ("provinceCode") REFERENCES "Province"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Farm" ADD CONSTRAINT "Farm_provinceCode_fkey" FOREIGN KEY ("provinceCode") REFERENCES "Province"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Farm" ADD CONSTRAINT "Farm_localityId_fkey" FOREIGN KEY ("localityId") REFERENCES "Locality"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FarmStatusHistory" ADD CONSTRAINT "FarmStatusHistory_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FarmConsentHistory" ADD CONSTRAINT "FarmConsentHistory_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FarmConsentHistory" ADD CONSTRAINT "FarmConsentHistory_consentedBy_fkey" FOREIGN KEY ("consentedBy") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserRole" ADD CONSTRAINT "UserRole_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserRole" ADD CONSTRAINT "UserRole_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuthSession" ADD CONSTRAINT "AuthSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RolePermission" ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RolePermission" ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES "Permission"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserScope" ADD CONSTRAINT "UserScope_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserScope" ADD CONSTRAINT "UserScope_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserScope" ADD CONSTRAINT "UserScope_provinceCode_fkey" FOREIGN KEY ("provinceCode") REFERENCES "Province"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FarmUserAssignment" ADD CONSTRAINT "FarmUserAssignment_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FarmUserAssignment" ADD CONSTRAINT "FarmUserAssignment_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Batch" ADD CONSTRAINT "Batch_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BatchStatusHistory" ADD CONSTRAINT "BatchStatusHistory_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DailyRecord" ADD CONSTRAINT "DailyRecord_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Weighing" ADD CONSTRAINT "Weighing_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Outflow" ADD CONSTRAINT "Outflow_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InputReceipt" ADD CONSTRAINT "InputReceipt_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InputReceipt" ADD CONSTRAINT "InputReceipt_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InputReceipt" ADD CONSTRAINT "InputReceipt_confirmedById_fkey" FOREIGN KEY ("confirmedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InputUsage" ADD CONSTRAINT "InputUsage_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InputUsage" ADD CONSTRAINT "InputUsage_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InputUsage" ADD CONSTRAINT "InputUsage_receiptId_fkey" FOREIGN KEY ("receiptId") REFERENCES "InputReceipt"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InputOrder" ADD CONSTRAINT "InputOrder_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "InputOrder" ADD CONSTRAINT "InputOrder_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HealthDeclaration" ADD CONSTRAINT "HealthDeclaration_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HealthDeclaration" ADD CONSTRAINT "HealthDeclaration_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HealthDeclaration" ADD CONSTRAINT "HealthDeclaration_reportedById_fkey" FOREIGN KEY ("reportedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HealthDeclaration" ADD CONSTRAINT "HealthDeclaration_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Vaccination" ADD CONSTRAINT "Vaccination_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Vaccination" ADD CONSTRAINT "Vaccination_calendarId_fkey" FOREIGN KEY ("calendarId") REFERENCES "VaccinationCalendar"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Treatment" ADD CONSTRAINT "Treatment_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Treatment" ADD CONSTRAINT "Treatment_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES "Lot"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VetIntervention" ADD CONSTRAINT "VetIntervention_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VetIntervention" ADD CONSTRAINT "VetIntervention_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VetIntervention" ADD CONSTRAINT "VetIntervention_declarationId_fkey" FOREIGN KEY ("declarationId") REFERENCES "HealthDeclaration"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VetIntervention" ADD CONSTRAINT "VetIntervention_vetId_fkey" FOREIGN KEY ("vetId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Alert" ADD CONSTRAINT "Alert_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Alert" ADD CONSTRAINT "Alert_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Alert" ADD CONSTRAINT "Alert_healthDeclarationId_fkey" FOREIGN KEY ("healthDeclarationId") REFERENCES "HealthDeclaration"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Alert" ADD CONSTRAINT "Alert_sourceDailyRecordId_fkey" FOREIGN KEY ("sourceDailyRecordId") REFERENCES "DailyRecord"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Alert" ADD CONSTRAINT "Alert_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AlertStatusHistory" ADD CONSTRAINT "AlertStatusHistory_alertId_fkey" FOREIGN KEY ("alertId") REFERENCES "Alert"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BiosecurityCheck" ADD CONSTRAINT "BiosecurityCheck_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BiosecurityCheck" ADD CONSTRAINT "BiosecurityCheck_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BiosecurityCheckItem" ADD CONSTRAINT "BiosecurityCheckItem_checkId_fkey" FOREIGN KEY ("checkId") REFERENCES "BiosecurityCheck"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BiosecurityCheckItem" ADD CONSTRAINT "BiosecurityCheckItem_gridId_fkey" FOREIGN KEY ("gridId") REFERENCES "BiosecurityGrid"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Visit" ADD CONSTRAINT "Visit_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Visit" ADD CONSTRAINT "Visit_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Visit" ADD CONSTRAINT "Visit_visitorId_fkey" FOREIGN KEY ("visitorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Expense" ADD CONSTRAINT "Expense_farmId_fkey" FOREIGN KEY ("farmId") REFERENCES "Farm"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Expense" ADD CONSTRAINT "Expense_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Expense" ADD CONSTRAINT "Expense_sourceInputUsageId_fkey" FOREIGN KEY ("sourceInputUsageId") REFERENCES "InputUsage"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Sale" ADD CONSTRAINT "Sale_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Sale" ADD CONSTRAINT "Sale_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES "Operator"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Sale" ADD CONSTRAINT "Sale_outflowId_fkey" FOREIGN KEY ("outflowId") REFERENCES "Outflow"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OperatorUserAssignment" ADD CONSTRAINT "OperatorUserAssignment_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES "Operator"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OperatorUserAssignment" ADD CONSTRAINT "OperatorUserAssignment_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Lot" ADD CONSTRAINT "Lot_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "Batch"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Lot" ADD CONSTRAINT "Lot_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES "Operator"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Lot" ADD CONSTRAINT "Lot_outflowId_fkey" FOREIGN KEY ("outflowId") REFERENCES "Outflow"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LotEvent" ADD CONSTRAINT "LotEvent_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES "Lot"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LotReception" ADD CONSTRAINT "LotReception_lotEventId_fkey" FOREIGN KEY ("lotEventId") REFERENCES "LotEvent"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LotReception" ADD CONSTRAINT "LotReception_operatorId_fkey" FOREIGN KEY ("operatorId") REFERENCES "Operator"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LotReception" ADD CONSTRAINT "LotReception_receivedById_fkey" FOREIGN KEY ("receivedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QrCode" ADD CONSTRAINT "QrCode_lotId_fkey" FOREIGN KEY ("lotId") REFERENCES "Lot"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ScanLog" ADD CONSTRAINT "ScanLog_qrCodeId_fkey" FOREIGN KEY ("qrCodeId") REFERENCES "QrCode"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PublishedAggregate" ADD CONSTRAINT "PublishedAggregate_approvedById_fkey" FOREIGN KEY ("approvedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SyncConflict" ADD CONSTRAINT "SyncConflict_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ImportReport" ADD CONSTRAINT "ImportReport_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE OR REPLACE FUNCTION prevent_audit_log_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    RAISE EXCEPTION 'AuditLog is append-only; UPDATE and DELETE are forbidden'
        USING ERRCODE = '55000';
END;
$$;

CREATE TRIGGER audit_log_no_update_or_delete
BEFORE UPDATE OR DELETE ON "AuditLog"
FOR EACH ROW
EXECUTE FUNCTION prevent_audit_log_mutation();

CREATE OR REPLACE FUNCTION prevent_batch_delete()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    RAISE EXCEPTION 'Batch records cannot be physically deleted'
        USING ERRCODE = '55000';
END;
$$;

CREATE TRIGGER batch_no_delete
BEFORE DELETE ON "Batch"
FOR EACH ROW
EXECUTE FUNCTION prevent_batch_delete();

CREATE OR REPLACE FUNCTION prevent_locked_batch_update()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF OLD."isLocked" AND current_setting('app.allow_closed_batch_edit', true) IS DISTINCT FROM 'true' THEN
        RAISE EXCEPTION 'Closed Batch is read-only'
            USING ERRCODE = '55000';
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER batch_locked_read_only
BEFORE UPDATE ON "Batch"
FOR EACH ROW
EXECUTE FUNCTION prevent_locked_batch_update();
