import { config } from 'dotenv';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';
import { PrismaClient } from '@prisma/client';

config({ path: resolve(__dirname, '../../../.env') });

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error('DATABASE_URL est obligatoire.');
if (process.env.ALLOW_DEMO_RESET !== 'true') {
  throw new Error('Reset refuse: definir ALLOW_DEMO_RESET=true explicitement.');
}
if (!['development', 'test'].includes(process.env.NODE_ENV ?? '')) {
  throw new Error('Reset refuse hors des environnements development/test.');
}

const target = new URL(databaseUrl);
const databaseName = target.pathname.replace(/^\//, '').split('?')[0];
if (!['localhost', '127.0.0.1', '::1'].includes(target.hostname) || !/^agritrack(_demo|_test)?$/.test(databaseName)) {
  throw new Error('Reset refuse: cible autorisee uniquement sur une base agritrack locale.');
}

const prisma = new PrismaClient();

async function resetDemo(): Promise<void> {
  await prisma.$executeRaw`TRUNCATE TABLE "Farm" CASCADE`;
  await prisma.$executeRaw`TRUNCATE TABLE "PublishedAggregate" CASCADE`;
  await prisma.notification.deleteMany({
    where: { entityType: { in: ['Farm', 'Batch', 'Alert', 'Lot', 'InputReceipt', 'InputUsage'] } },
  });
  await prisma.syncConflict.deleteMany({ where: { entityType: { in: ['Farm', 'Batch', 'DailyRecord', 'Outflow'] } } });
  console.info('Donnees metier locales reinitialisees. Le journal d audit et les compteurs d identifiants sont conserves.');
  execFileSync(process.execPath, ['--import', 'tsx', 'prisma/seed.ts'], {
    cwd: process.cwd(),
    env: process.env,
    stdio: 'inherit',
  });
}

resetDemo()
  .catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => prisma.$disconnect());