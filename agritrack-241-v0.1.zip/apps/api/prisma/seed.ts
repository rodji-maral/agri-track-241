import { config } from 'dotenv';
import { resolve } from 'node:path';
import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import {
  AlertSeverity,
  AlertStatus,
  BatchStatus,
  Cohort,
  ConfigurationStatus,
  DeclarationStatus,
  FarmStatus,
  FarmUserKind,
  ParameterValueType,
  PermissionAction,
  PrismaClient,
  ProvinceCode,
  RoleCode,
  UserScopeKind,
} from '@prisma/client';

const prisma = new PrismaClient();
config({ path: resolve(__dirname, '../../../.env') });
const demoPassword = 'PoufaDemo2026!';

const provinces = [
  { code: ProvinceCode.ESTUAIRE, name: 'Estuaire', locality: 'Libreville', prefix: 'EST', bounds: [-0.5, 1.2, 9.0, 11.5] },
  { code: ProvinceCode.HAUT_OGOOUE, name: 'Haut-Ogooue', locality: 'Franceville', prefix: 'HOG', bounds: [-2.5, -0.5, 12.5, 14.5] },
  { code: ProvinceCode.MOYEN_OGOOUE, name: 'Moyen-Ogooue', locality: 'Lambarene', prefix: 'MOG', bounds: [-1.5, 0.3, 9.5, 11.3] },
  { code: ProvinceCode.NGOUNIE, name: 'Ngounie', locality: 'Mouila', prefix: 'NGO', bounds: [-3.2, -0.5, 10.2, 12.3] },
  { code: ProvinceCode.NYANGA, name: 'Nyanga', locality: 'Tchibanga', prefix: 'NYA', bounds: [-4.5, -1.5, 9.5, 12.3] },
  { code: ProvinceCode.OGOOUE_IVINDO, name: 'Ogooue-Ivindo', locality: 'Makokou', prefix: 'OIV', bounds: [-0.8, 2.2, 11.5, 14.5] },
  { code: ProvinceCode.OGOOUE_LOLO, name: 'Ogooue-Lolo', locality: 'Koulamoutou', prefix: 'OLO', bounds: [-2.2, 0, 11, 13.5] },
  { code: ProvinceCode.OGOOUE_MARITIME, name: 'Ogooue-Maritime', locality: 'Port-Gentil', prefix: 'OMA', bounds: [-2, 0.2, 8.5, 10.7] },
  { code: ProvinceCode.WOLEU_NTEM, name: 'Woleu-Ntem', locality: 'Oyem', prefix: 'WNT', bounds: [0, 3, 10, 14] },
] as const;

const farms = [
  { code: 'EST-0001', name: 'Ferme Nkok', province: ProvinceCode.ESTUAIRE, locality: 'Nkok', lat: 0.3868, lon: 9.7658, capacity: 5000, financed: true },
  { code: 'EST-0002', name: 'Ferme Owendo', province: ProvinceCode.ESTUAIRE, locality: 'Owendo', lat: 0.2839, lon: 9.5037, capacity: 4200, financed: false },
  { code: 'EST-0003', name: 'Ferme Ntoum', province: ProvinceCode.ESTUAIRE, locality: 'Ntoum', lat: 0.3841, lon: 9.7596, capacity: 6000, financed: true },
  { code: 'HOG-0001', name: 'Ferme Mvengue', province: ProvinceCode.HAUT_OGOOUE, locality: 'Franceville', lat: -1.6333, lon: 13.5833, capacity: 4500, financed: true },
  { code: 'HOG-0002', name: 'Ferme Moanda', province: ProvinceCode.HAUT_OGOOUE, locality: 'Moanda', lat: -1.5667, lon: 13.2000, capacity: 3500, financed: false },
  { code: 'MOG-0001', name: 'Ferme Lambarene', province: ProvinceCode.MOYEN_OGOOUE, locality: 'Lambarene', lat: -0.7000, lon: 10.2333, capacity: 3800, financed: false },
  { code: 'NGO-0001', name: 'Ferme Mouila', province: ProvinceCode.NGOUNIE, locality: 'Mouila', lat: -1.8667, lon: 11.0167, capacity: 4000, financed: true },
  { code: 'NYA-0001', name: 'Ferme Tchibanga', province: ProvinceCode.NYANGA, locality: 'Tchibanga', lat: -2.8500, lon: 11.0167, capacity: 3200, financed: false },
  { code: 'OIV-0001', name: 'Ferme Makokou', province: ProvinceCode.OGOOUE_IVINDO, locality: 'Makokou', lat: 0.5667, lon: 12.8667, capacity: 3000, financed: false },
  { code: 'OLO-0001', name: 'Ferme Koulamoutou', province: ProvinceCode.OGOOUE_LOLO, locality: 'Koulamoutou', lat: -1.1333, lon: 12.4833, capacity: 3400, financed: false },
  { code: 'OMA-0001', name: 'Ferme Port-Gentil', province: ProvinceCode.OGOOUE_MARITIME, locality: 'Port-Gentil', lat: -0.7193, lon: 8.7815, capacity: 3600, financed: true },
  { code: 'WNT-0001', name: 'Ferme Oyem', province: ProvinceCode.WOLEU_NTEM, locality: 'Oyem', lat: 1.5995, lon: 11.5793, capacity: 4100, financed: false },
] as const;

const roleDefinitions: { code: RoleCode; name: string; email: string; firstName: string; lastName: string }[] = [
  { code: RoleCode.ELEVEUR, name: 'Eleveur', email: 'eleveur@agritrack.ga', firstName: 'Marcel', lastName: 'Moussavou' },
  { code: RoleCode.AGENT_TECHNIQUE, name: 'Agent technique', email: 'agent@agritrack.ga', firstName: 'Clarisse', lastName: 'Obame' },
  { code: RoleCode.POUFA_DGE, name: 'POUFA / DGE', email: 'dge@agritrack.ga', firstName: 'Andre', lastName: 'Mba' },
  { code: RoleCode.VETERINAIRE, name: 'Veterinaire', email: 'veterinaire@agritrack.ga', firstName: 'Sylvie', lastName: 'Ndong' },
  { code: RoleCode.BCEG, name: 'BCEG', email: 'bceg@agritrack.ga', firstName: 'Paul', lastName: 'Nziengui' },
  { code: RoleCode.MAEDR, name: 'MAEDR', email: 'maedr@agritrack.ga', firstName: 'Jeanne', lastName: 'Mabika' },
  { code: RoleCode.OPERATEUR, name: 'Operateur', email: 'operateur@agritrack.ga', firstName: 'Eric', lastName: 'Tchibinda' },
  { code: RoleCode.AUDITEUR_ANINF, name: 'Auditeur ANINF', email: 'auditeur@agritrack.ga', firstName: 'Nadine', lastName: 'Ekomie' },
  { code: RoleCode.ADMIN, name: 'Administrateur', email: 'admin@agritrack.ga', firstName: 'Admin', lastName: 'AgriTrack' },
];

const formulas = [
  ['present_count', 'Effectif present', 'placed - cumulative_deaths - cumulative_outflows', ['placed', 'cumulative_deaths', 'cumulative_outflows']],
  ['mortality_rate', 'Taux de mortalite', 'cumulative_deaths / placed * 100', ['cumulative_deaths', 'placed']],
  ['viability_rate', 'Viabilite', '100 - mortality_rate', ['mortality_rate']],
  ['daily_gain', 'GMQ', '(current_average_weight - initial_weight) / age_days * 1000', ['current_average_weight', 'initial_weight', 'age_days']],
  ['live_weight_produced', 'Poids vif produit', 'outflow_weight + present_count * current_average_weight - placed * initial_weight', ['outflow_weight', 'present_count', 'current_average_weight', 'placed', 'initial_weight']],
  ['feed_conversion', 'Indice de consommation', 'feed_consumed_kg / live_weight_produced_kg', ['feed_consumed_kg', 'live_weight_produced_kg']],
  ['occupancy_rate', 'Taux occupation', 'placed / capacity * 100', ['placed', 'capacity']],
  ['input_stock', 'Stock intrant', 'received - used', ['received', 'used']],
  ['input_variance_rate', 'Ecart intrants', '(delivered - used - stock) / delivered * 100', ['delivered', 'used', 'stock']],
  ['sale_traceability_rate', 'Ventes rattachees a un lot', 'linked_sales / total_sales * 100', ['linked_sales', 'total_sales']],
  ['lot_qr_coverage_rate', 'Lots avec QR', 'lots_with_qr / total_lots * 100', ['lots_with_qr', 'total_lots']],
  ['revenue', 'Chiffre affaires', 'quantity * unit_price', ['quantity', 'unit_price']],
  ['production_cost_per_kg', 'Cout par kg vif', 'charges / live_weight_produced_kg', ['charges', 'live_weight_produced_kg']],
  ['margin', 'Marge', 'revenue - charges', ['revenue', 'charges']],
  ['margin_rate', 'Taux de marge', 'margin / revenue * 100', ['margin', 'revenue']],
  ['entry_completeness', 'Completude de saisie', 'recorded_days / elapsed_days * 100', ['recorded_days', 'elapsed_days']],
  ['early_health_alert', 'Alerte precoce', 'daily_deaths / present_count * 100', ['daily_deaths', 'present_count']],
  ['biosecurity_score', 'Score bios securite', 'compliant_points / checked_points * 100', ['compliant_points', 'checked_points']],
] as const;

function daysAgo(days: number): Date {
  const date = new Date();
  date.setUTCHours(0, 0, 0, 0);
  date.setUTCDate(date.getUTCDate() - days);
  return date;
}

async function main(): Promise<void> {
  const passwordHash = await bcrypt.hash(demoPassword, 12);

  for (const province of provinces) {
    await prisma.province.upsert({
      where: { code: province.code },
      update: { name: province.name, minLatitude: province.bounds[0], maxLatitude: province.bounds[1], minLongitude: province.bounds[2], maxLongitude: province.bounds[3] },
      create: { code: province.code, name: province.name, minLatitude: province.bounds[0], maxLatitude: province.bounds[1], minLongitude: province.bounds[2], maxLongitude: province.bounds[3] },
    });
    await prisma.locality.upsert({
      where: { provinceCode_name: { provinceCode: province.code, name: province.locality } },
      update: {},
      create: { provinceCode: province.code, name: province.locality },
    });
  }

  for (const province of provinces) {
    await prisma.listValue.upsert({
      where: { listKey_code_version: { listKey: 'farm_code_prefix', code: province.code, version: 1 } },
      update: { label: province.prefix },
      create: { listKey: 'farm_code_prefix', code: province.code, label: province.prefix, version: 1 },
    });
  }
  for (const [code, label] of [
    ['DRAFT:ACTIVE', 'Activation'],
    ['ACTIVE:SUSPENDED', 'Suspension'],
    ['SUSPENDED:ACTIVE', 'Reactivation'],
    ['ACTIVE:CLOSED', 'Cloture'],
    ['SUSPENDED:CLOSED', 'Cloture apres suspension'],
  ]) {
    await prisma.listValue.upsert({
      where: { listKey_code_version: { listKey: 'farm_status_transition', code, version: 1 } },
      update: {},
      create: { listKey: 'farm_status_transition', code, label, version: 1 },
    });
  }
  for (const [listKey, code, label] of [
    ['alert_severity', 'MODERATE', 'Moderee'],
    ['alert_status_transition', 'NEW:UNDER_REVIEW', 'Nouvelle vers en analyse'],
    ['alert_status_transition', 'UNDER_REVIEW:CONFIRMED', 'En analyse vers confirmee'],
    ['alert_status_transition', 'UNDER_REVIEW:REFUTED', 'En analyse vers infirmee'],
    ['alert_status_transition', 'CONFIRMED:CLOSED', 'Confirmee vers close'],
    ['alert_status_transition', 'REFUTED:CLOSED', 'Infirmee vers close'],
    ['health_declaration_transition', 'SUBMITTED:UNDER_REVIEW', 'Soumise vers en analyse'],
    ['health_declaration_transition', 'UNDER_REVIEW:QUALIFIED', 'En analyse vers qualifiee'],
    ['health_declaration_transition', 'UNDER_REVIEW:REJECTED', 'En analyse vers rejetee'],
  ]) {
    await prisma.listValue.upsert({
      where: { listKey_code_version: { listKey, code, version: 1 } },
      update: { label },
      create: { listKey, code, label, version: 1 },
    });
  }

  const roleRecords = new Map<RoleCode, { id: string }>();
  for (const definition of roleDefinitions) {
    const role = await prisma.role.upsert({
      where: { code: definition.code },
      update: { name: definition.name },
      create: { code: definition.code, name: definition.name },
    });
    roleRecords.set(definition.code, role);
  }

  const demoUsers = new Map<RoleCode, { id: string }>();
  for (const definition of roleDefinitions) {
    const user = await prisma.user.upsert({
      where: { email: definition.email },
      update: { firstName: definition.firstName, lastName: definition.lastName },
      create: {
        email: definition.email,
        passwordHash,
        firstName: definition.firstName,
        lastName: definition.lastName,
      },
    });
    demoUsers.set(definition.code, user);
    await prisma.userRole.upsert({
      where: { userId_roleId: { userId: user.id, roleId: roleRecords.get(definition.code)!.id } },
      update: {},
      create: { userId: user.id, roleId: roleRecords.get(definition.code)!.id },
    });
  }

  const farmsByCode = new Map<string, { id: string; financed: boolean }>();
  for (const farm of farms) {
    const locality = await prisma.locality.upsert({
      where: { provinceCode_name: { provinceCode: farm.province, name: farm.locality } },
      update: {},
      create: { provinceCode: farm.province, name: farm.locality },
    });
    const record = await prisma.farm.upsert({
      where: { code: farm.code },
      update: {
        name: farm.name,
        provinceCode: farm.province,
        localityId: locality.id,
        latitude: farm.lat,
        longitude: farm.lon,
        capacity: farm.capacity,
        bcegFinanced: farm.financed,
        status: FarmStatus.ACTIVE,
      },
      create: {
        code: farm.code,
        name: farm.name,
        cohort: farm.code.endsWith('1') ? Cohort.COHORTE_1 : Cohort.COHORTE_2,
        provinceCode: farm.province,
        localityId: locality.id,
        latitude: farm.lat,
        longitude: farm.lon,
        capacity: farm.capacity,
        bcegFinanced: farm.financed,
        infrastructure: { poultryHouseCount: 2, waterSource: 'Forage', backupPower: false },
        status: FarmStatus.ACTIVE,
      },
    });
    farmsByCode.set(farm.code, { id: record.id, financed: farm.financed });
  }

  const farmer = demoUsers.get(RoleCode.ELEVEUR)!;
  const agent = demoUsers.get(RoleCode.AGENT_TECHNIQUE)!;
  const bceg = demoUsers.get(RoleCode.BCEG)!;
  const dge = demoUsers.get(RoleCode.POUFA_DGE)!;
  const vet = demoUsers.get(RoleCode.VETERINAIRE)!;
  const scopes = [
    { userId: farmer.id, kind: UserScopeKind.FARM, farmId: farmsByCode.get('EST-0001')!.id },
    ...farms.map((farm) => ({ userId: agent.id, kind: UserScopeKind.FARM, farmId: farmsByCode.get(farm.code)!.id })),
    ...farms.filter((farm) => farm.financed).map((farm) => ({ userId: bceg.id, kind: UserScopeKind.FARM, farmId: farmsByCode.get(farm.code)!.id })),
    ...provinces.map((province) => ({ userId: dge.id, kind: UserScopeKind.PROVINCE, provinceCode: province.code })),
    ...provinces.map((province) => ({ userId: vet.id, kind: UserScopeKind.PROVINCE, provinceCode: province.code })),
  ];
  for (const user of demoUsers.values()) await prisma.userScope.deleteMany({ where: { userId: user.id } });
  await prisma.userScope.createMany({ data: scopes, skipDuplicates: true });

  for (const farm of farms) {
    await prisma.farmUserAssignment.upsert({
      where: { farmId_userId_kind: { farmId: farmsByCode.get(farm.code)!.id, userId: farm.code === 'EST-0001' ? farmer.id : agent.id, kind: farm.code === 'EST-0001' ? FarmUserKind.OWNER : FarmUserKind.TECHNICIAN } },
      update: {},
      create: { farmId: farmsByCode.get(farm.code)!.id, userId: farm.code === 'EST-0001' ? farmer.id : agent.id, kind: farm.code === 'EST-0001' ? FarmUserKind.OWNER : FarmUserKind.TECHNICIAN },
    });
    if (farm.financed) {
      const currentConsent = await prisma.farmConsentHistory.findFirst({
        where: { farmId: farmsByCode.get(farm.code)!.id, purpose: 'BCEG_FINANCING', status: 'GRANTED' },
      });
      if (!currentConsent) {
        await prisma.farmConsentHistory.create({
          data: {
            farmId: farmsByCode.get(farm.code)!.id,
            status: 'GRANTED',
            purpose: 'BCEG_FINANCING',
            consentedBy: farmer.id,
            evidenceRef: `DEMO-CONSENT-${farm.code}`,
          },
        });
      }
    }
  }

  const permissionRows = [
    ...['farm', 'batch', 'daily_record', 'weighing', 'outflow', 'input', 'health', 'alert', 'finance', 'lot', 'audit', 'aggregate', 'parameter', 'notification', 'operator', 'report'].flatMap((resource) =>
      Object.values(PermissionAction).map((action) => ({ resource, action }))),
  ];
  for (const item of permissionRows) {
    await prisma.permission.upsert({
      where: { resource_action: item },
      update: {},
      create: item,
    });
  }

  const roleResources: Record<RoleCode, string[]> = {
    ELEVEUR: ['farm', 'batch', 'daily_record', 'weighing', 'outflow', 'input', 'health', 'finance', 'lot', 'report'],
    AGENT_TECHNIQUE: ['farm', 'batch', 'daily_record', 'weighing', 'outflow', 'input', 'health', 'finance', 'lot', 'report'],
    POUFA_DGE: ['farm', 'batch', 'daily_record', 'weighing', 'outflow', 'input', 'health', 'finance', 'lot', 'aggregate', 'parameter', 'operator', 'report'],
    VETERINAIRE: ['farm', 'batch', 'daily_record', 'health', 'alert', 'parameter'],
    BCEG: ['farm', 'finance', 'report'],
    MAEDR: ['aggregate', 'report'],
    OPERATEUR: ['lot', 'operator', 'finance'],
    AUDITEUR_ANINF: ['audit'],
    ADMIN: ['farm', 'batch', 'daily_record', 'weighing', 'outflow', 'input', 'health', 'alert', 'finance', 'lot', 'audit', 'aggregate', 'parameter', 'operator', 'report'],
  };
  for (const resources of Object.values(roleResources)) resources.push('notification');
  for (const [roleCode, resources] of Object.entries(roleResources) as [RoleCode, string[]][]) {
    const roleId = roleRecords.get(roleCode)!.id;
    const actions = roleCode === RoleCode.ADMIN
      ? Object.values(PermissionAction)
      : roleCode === RoleCode.AUDITEUR_ANINF
        ? [PermissionAction.CONSULT, PermissionAction.EXPORT]
        : roleCode === RoleCode.VETERINAIRE
          ? [PermissionAction.CONSULT, PermissionAction.CREATE, PermissionAction.MODIFY, PermissionAction.VALIDATE]
          : roleCode === RoleCode.MAEDR
            ? [PermissionAction.CONSULT, PermissionAction.VALIDATE, PermissionAction.EXPORT]
            : roleCode === RoleCode.OPERATEUR
              ? [PermissionAction.CONSULT, PermissionAction.MODIFY]
              : roleCode === RoleCode.BCEG
                ? [PermissionAction.CONSULT, PermissionAction.EXPORT]
                : roleCode === RoleCode.POUFA_DGE
                  ? [PermissionAction.CONSULT, PermissionAction.CREATE, PermissionAction.MODIFY, PermissionAction.EXPORT]
                  : [PermissionAction.CONSULT, PermissionAction.CREATE, PermissionAction.MODIFY, PermissionAction.EXPORT];
    const permissionRecords = await prisma.permission.findMany({ where: { resource: { in: resources }, action: { in: actions } } });
    await prisma.rolePermission.createMany({
      data: permissionRecords.map((permission) => ({ roleId, permissionId: permission.id })),
      skipDuplicates: true,
    });
  }

  const parameters = [
    { key: 'batch.reference_duration_days', valueType: ParameterValueType.NUMBER, value: 45, unit: 'jour' },
    { key: 'weighing.frequency_per_week', valueType: ParameterValueType.NUMBER, value: 1, unit: 'fois/semaine' },
    { key: 'production.cohort_count', valueType: ParameterValueType.NUMBER, value: 2, unit: 'cohorte' },
    { key: 'input.variance_alert_enabled', valueType: ParameterValueType.BOOLEAN, value: true },
    { key: 'traceability.coverage_target', valueType: ParameterValueType.NUMBER, value: 95, unit: '%' },
    { key: 'farm.ranking.criteria', valueType: ParameterValueType.JSON, value: [
      { metricKey: 'viabilityRate', weight: 0.35, maxValue: 100, lowerBetter: false },
      { metricKey: 'mortalityRate', weight: 0.3, maxValue: 10, lowerBetter: true },
      { metricKey: 'dataCompleteness', weight: 0.2, maxValue: 100, lowerBetter: false },
      { metricKey: 'occupancyRate', weight: 0.15, maxValue: 100, lowerBetter: false },
    ] },
    { key: 'sync.conflict_policy', valueType: ParameterValueType.STRING, value: 'LAST_TIMESTAMP_WINS' },
    { key: 'timezone', valueType: ParameterValueType.STRING, value: 'Africa/Libreville' },
  ];
  for (const parameter of parameters) {
    await prisma.parameter.upsert({
      where: { key_version: { key: parameter.key, version: 1 } },
      update: {},
      create: { ...parameter, version: 1, status: ConfigurationStatus.PROPOSED, description: 'Valeur proposee a valider par la DGE' },
    });
  }
  for (const [listKey, code, label] of [
    ['sale_unit', 'sujet', 'Par tete'],
    ['sale_unit', 'kg', 'Kilogramme'],
    ['expense_category', 'ALIMENT', 'Aliment'],
    ['expense_category', 'VACCIN', 'Vaccins et soins'],
    ['expense_category', 'ENERGIE', 'Energie'],
    ['expense_category', 'MAIN_DOEUVRE', 'Main d oeuvre'],
    ['expense_category', 'TRANSPORT', 'Transport'],
    ['expense_category', 'AUTRE', 'Autre charge'],
  ]) {
    await prisma.listValue.upsert({
      where: { listKey_code_version: { listKey, code, version: 1 } },
      update: { label },
      create: { listKey, code, label, version: 1 },
    });
  }
  const reportTemplates = [
    {
      key: 'weekly',
      name: 'Rapport hebdomadaire',
      description: 'Synthese des bandes actives du perimetre autorise.',
      definition: {
        datasource: 'weekly',
        title: 'Rapport hebdomadaire de production',
        columns: [
          { key: 'batchCode', label: 'Bande' }, { key: 'farmCode', label: 'Ferme' },
          { key: 'provinceCode', label: 'Province' }, { key: 'status', label: 'Statut' },
          { key: 'revenue', label: 'Chiffre d affaires' }, { key: 'charges', label: 'Charges' },
          { key: 'liveWeightProducedKg', label: 'Poids vif produit (kg)' }, { key: 'margin', label: 'Marge' },
        ],
      },
    },
    {
      key: 'batch_end',
      name: 'Bilan de fin de bande',
      description: 'Bilan economique final d une bande cloturee.',
      definition: {
        datasource: 'batch_end',
        title: 'Bilan de fin de bande',
        columns: [
          { key: 'batchCode', label: 'Bande' }, { key: 'status', label: 'Statut' },
          { key: 'revenue', label: 'Chiffre d affaires' }, { key: 'charges', label: 'Charges' },
          { key: 'productionCostPerKg', label: 'Cout par kg vif' }, { key: 'margin', label: 'Marge' },
          { key: 'marginRatePercent', label: 'Taux de marge (%)' },
        ],
      },
    },
    {
      key: 'national_monthly',
      name: 'Rapport national mensuel',
      description: 'Diffusion exclusivement depuis les agregats publies par la MAEDR.',
      definition: {
        datasource: 'national_monthly',
        title: 'Rapport national mensuel avicole',
        columns: [
          { key: 'farmsCount', label: 'Fermes actives' }, { key: 'placedCount', label: 'Sujets mis en place' },
          { key: 'averageMortalityPercent', label: 'Mortalite moyenne (%)' },
          { key: 'producedLiveWeightKg', label: 'Poids vif produit (kg)' }, { key: 'openHealthAlerts', label: 'Alertes sanitaires ouvertes' },
        ],
      },
    },
  ];
  for (const template of reportTemplates) {
    await prisma.reportTemplate.upsert({
      where: { key_version: { key: template.key, version: 1 } },
      update: { name: template.name, description: template.description, definition: template.definition, active: true },
      create: { ...template, version: 1, active: true },
    });
  }
  for (const [key, name, expression, variables] of formulas) {
    await prisma.formula.upsert({
      where: { key_version: { key, version: 1 } },
      update: {},
      create: {
        key,
        name,
        expression,
        variables: [...variables],
        version: 1,
        status: ConfigurationStatus.PROPOSED,
        description: 'Formule proposee a valider par la DGE; evaluation a implementer avec moteur restreint.',
      },
    });
  }
  for (const [key, value, unit, veterinarianOnly] of [
    ['health.daily_mortality_rate', 3, '%', true],
    ['input.variance_rate', 5, '%', false],
    ['traceability.reception_variance_rate', 5, '%', false],
  ] as const) {
    await prisma.threshold.upsert({
      where: { key_version: { key, version: 1 } },
      update: {},
      create: {
        key,
        value,
        unit,
        version: 1,
        status: ConfigurationStatus.PROPOSED,
        veterinarianOnly,
        description: 'Seuil propose a valider par le role habilite.',
      },
    });
  }

  const vaccineSchedule = [
    { code: 'DEMO-VAX-J01', name: 'Marek', vaccine: 'Vaccin Marek', ageDay: 1, route: 'In ovo ou sous-cutanee' },
    { code: 'DEMO-VAX-J07', name: 'Newcastle / bronchite', vaccine: 'Vaccin Newcastle et bronchite infectieuse', ageDay: 7, route: 'Eau de boisson' },
    { code: 'DEMO-VAX-J14', name: 'Gumboro', vaccine: 'Vaccin Gumboro', ageDay: 14, route: 'Eau de boisson' },
    { code: 'DEMO-VAX-J21', name: 'Rappel Newcastle', vaccine: 'Vaccin Newcastle', ageDay: 21, route: 'Eau de boisson' },
  ];
  const vaccineRecords = new Map<string, { id: string }>();
  for (const vaccine of vaccineSchedule) {
    const record = await prisma.vaccinationCalendar.upsert({
      where: { code: vaccine.code },
      update: {},
      create: vaccine,
    });
    vaccineRecords.set(vaccine.code, record);
  }

  const batchSpecs = [
    { farmCode: 'EST-0001', rank: 1, placedDaysAgo: 60, status: BatchStatus.CLOSED, placedCount: 2500, closeDaysAgo: 15 },
    { farmCode: 'HOG-0001', rank: 1, placedDaysAgo: 30, status: BatchStatus.ACTIVE, placedCount: 2200 },
    { farmCode: 'NGO-0001', rank: 1, placedDaysAgo: 29, status: BatchStatus.ACTIVE, placedCount: 2000 },
  ] as const;
  const batchesByCode = new Map<string, { id: string; placedCount: number }>();
  for (const spec of batchSpecs) {
    const farm = farmsByCode.get(spec.farmCode)!;
    const code = `${spec.farmCode}-B${String(spec.rank).padStart(2, '0')}`;
    const placedAt = daysAgo(spec.placedDaysAgo);
    const batch = await prisma.batch.upsert({
      where: { code },
      update: { status: spec.status, isLocked: spec.status === BatchStatus.CLOSED, closedAt: 'closeDaysAgo' in spec ? daysAgo(spec.closeDaysAgo) : null },
      create: {
        code,
        farmId: farm.id,
        rank: spec.rank,
        status: spec.status,
        placedAt,
        plannedCloseAt: new Date(placedAt.getTime() + 45 * 86_400_000),
        closedAt: 'closeDaysAgo' in spec ? daysAgo(spec.closeDaysAgo) : null,
        placedCount: spec.placedCount,
        initialAverageWeight: 0.042,
        initialStock: spec.placedCount,
        isLocked: spec.status === BatchStatus.CLOSED,
        lockedAt: spec.status === BatchStatus.CLOSED ? daysAgo(spec.closeDaysAgo) : null,
      },
    });
    batchesByCode.set(code, { id: batch.id, placedCount: spec.placedCount });

    const dailyRows = Array.from({ length: 30 }, (_, index) => {
      const recordDate = new Date(placedAt);
      recordDate.setUTCDate(recordDate.getUTCDate() + index);
      return {
        clientUuid: randomUUID(),
        batchId: batch.id,
        recordDate,
        deaths: index > 0 && index % 12 === 0 ? 2 : 0,
        feedConsumedKg: 45 + index * 1.2,
        waterConsumedLiters: 75 + index * 2,
        suspicionReported: false,
        recordedAt: new Date(recordDate.getTime() + 17 * 3_600_000),
        syncUpdatedAt: new Date(recordDate.getTime() + 17 * 3_600_000),
      };
    });
    await prisma.dailyRecord.createMany({ data: dailyRows, skipDuplicates: true });
    await prisma.weighing.createMany({
      data: [7, 14, 21, 28].map((ageDay) => ({
        clientUuid: randomUUID(),
        batchId: batch.id,
        weighedAt: new Date(placedAt.getTime() + ageDay * 86_400_000),
        sampleCount: 50,
        averageWeight: 0.12 + ageDay * 0.045,
      })),
      skipDuplicates: true,
    });
  }

  const alertBatch = batchesByCode.get('HOG-0001-B01')!;
  const declarationUuid = 'b80a2e3b-50e8-47fc-9e88-680fa1a0c101';
  const declaration = await prisma.healthDeclaration.upsert({
    where: { clientUuid: declarationUuid },
    update: {},
    create: {
      clientUuid: declarationUuid,
      farmId: farmsByCode.get('HOG-0001')!.id,
      batchId: alertBatch.id,
      symptoms: 'Baisse de consommation et toux observees sur plusieurs sujets.',
      suspectedCondition: 'Suspicion respiratoire a qualifier',
      affectedCount: 18,
      declaredAt: daysAgo(2),
      status: DeclarationStatus.SUBMITTED,
      reportedById: farmer.id,
    },
  });
  const existingAlert = await prisma.alert.findUnique({ where: { healthDeclarationId: declaration.id } });
  if (!existingAlert) {
    await prisma.alert.create({
      data: {
        farmId: farmsByCode.get('HOG-0001')!.id,
        batchId: alertBatch.id,
        healthDeclarationId: declaration.id,
        title: 'Signalement sanitaire a qualifier',
        description: 'Declaration recue; publication en attente de qualification veterinaire.',
        severity: AlertSeverity.MODERATE,
        status: AlertStatus.NEW,
        createdById: vet.id,
      },
    });
  }

  const operator = await prisma.operator.upsert({
    where: { code: 'OPER-DEMO-001' },
    update: {
      agreementExpiresAt: new Date(Date.now() + 180 * 86_400_000),
      agreementReference: 'CONVENTION-DEMO-001',
      active: true,
    },
    create: {
      code: 'OPER-DEMO-001',
      name: 'Operateur de demonstration',
      operatorType: 'ABATTOIR',
      agreementSignedAt: daysAgo(10),
      agreementExpiresAt: new Date(Date.now() + 180 * 86_400_000),
      agreementReference: 'CONVENTION-DEMO-001',
      active: true,
    },
  });
  const operatorUser = demoUsers.get(RoleCode.OPERATEUR)!;
  await prisma.operatorUserAssignment.upsert({
    where: { operatorId_userId: { operatorId: operator.id, userId: operatorUser.id } },
    update: {},
    create: { operatorId: operator.id, userId: operatorUser.id, assignedBy: demoUsers.get(RoleCode.ADMIN)!.id },
  });
  const lotCode = 'EST-0001-B01-L01';
  const lot = await prisma.lot.upsert({
    where: { code: lotCode },
    update: {},
    create: {
      code: lotCode,
      batchId: batchesByCode.get('EST-0001-B01')!.id,
      operatorId: operator.id,
      rank: 1,
      quantity: 2400,
      status: 'OPEN',
      producedAt: daysAgo(18),
    },
  });
  await prisma.qrCode.upsert({
    where: { lotId: lot.id },
    update: {},
    create: { lotId: lot.id },
  });
  await prisma.lotEvent.createMany({
    data: [{
      clientUuid: 'b80a2e3b-50e8-47fc-9e88-680fa1a0c102',
      lotId: lot.id,
      eventType: 'CREATED',
      occurredAt: daysAgo(18),
      location: 'Estuaire, Gabon',
      details: { demo: true },
    }],
    skipDuplicates: true,
  });

  console.info(`Seed termine: ${provinces.length} provinces, ${farms.length} fermes, ${batchSpecs.length} bandes, 9 comptes.`);
}

main()
  .catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => prisma.$disconnect());