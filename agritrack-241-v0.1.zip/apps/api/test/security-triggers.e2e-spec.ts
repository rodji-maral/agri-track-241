import 'dotenv/config';
import { randomUUID } from 'node:crypto';
import { PrismaClient } from '@prisma/client';
import { AuditService } from '../src/audit/audit.service';
import { PrismaService } from '../src/prisma/prisma.service';

const enabled = process.env.RUN_E2E === 'true';
const suite = enabled ? describe : describe.skip;

suite('database security triggers', () => {
  let prisma: PrismaClient;

  beforeAll(async () => {
    prisma = new PrismaClient();
    await prisma.$connect();
  });

  afterAll(async () => {
    await prisma?.$disconnect();
  });

  it('keeps AuditLog immutable and closed batches read-only/non-deletable', async () => {
    const installed = await prisma.$queryRaw<{ triggerName: string; tableName: string }[]>`
      SELECT t.tgname AS "triggerName", c.relname AS "tableName"
      FROM pg_trigger t
      JOIN pg_class c ON c.oid = t.tgrelid
      WHERE NOT t.tgisinternal
        AND t.tgname IN ('audit_log_no_update_or_delete', 'batch_no_delete', 'batch_locked_read_only')
    `;
    expect(installed).toEqual(expect.arrayContaining([
      expect.objectContaining({ triggerName: 'audit_log_no_update_or_delete', tableName: 'AuditLog' }),
      expect.objectContaining({ triggerName: 'batch_no_delete', tableName: 'Batch' }),
      expect.objectContaining({ triggerName: 'batch_locked_read_only', tableName: 'Batch' }),
    ]));

    const audit = new AuditService(prisma as unknown as PrismaService);
    const auditEntityId = randomUUID();
    await audit.record({
      action: 'TRIGGER_TEST',
      entityType: 'TriggerTest',
      entityId: auditEntityId,
    });
    const auditEntry = await prisma.auditLog.findFirstOrThrow({ where: { entityType: 'TriggerTest', entityId: auditEntityId } });
    await expect(prisma.auditLog.update({
      where: { id: auditEntry.id },
      data: { action: 'ALTERED' },
    })).rejects.toThrow();
    await expect(prisma.auditLog.delete({ where: { id: auditEntry.id } })).rejects.toThrow();

    const closedBatch = await prisma.batch.findFirst({ where: { isLocked: true }, select: { id: true } });
    expect(closedBatch).not.toBeNull();
    await expect(prisma.batch.update({
      where: { id: closedBatch!.id },
      data: { closedAt: new Date() },
    })).rejects.toThrow();
    await expect(prisma.batch.delete({ where: { id: closedBatch!.id } })).rejects.toThrow();
  });
});