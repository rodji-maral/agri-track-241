import { config } from 'dotenv';
import { randomUUID } from 'node:crypto';
import { resolve } from 'node:path';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { BatchStatus, ConfigurationStatus, FarmStatus, PrismaClient } from '@prisma/client';
import request = require('supertest');
import { AppModule } from '../src/app.module';

const enabled = process.env.RUN_E2E === 'true';
const suite = enabled ? describe : describe.skip;
config({ path: resolve(__dirname, '../../../.env') });

suite('critical production and traceability journey', () => {
  let app: INestApplication;
  let prisma: PrismaClient;
  let dgeToken: string;
  let vetToken: string;
  let farmId: string;
  let batchId: string;

  beforeAll(async () => {
    if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required for e2e tests.');
    const database = new URL(process.env.DATABASE_URL);
    if (!['localhost', '127.0.0.1', '::1'].includes(database.hostname)) {
      throw new Error('E2E tests are restricted to a local database.');
    }
    prisma = new PrismaClient();
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api');
    app.useGlobalPipes(new ValidationPipe({
      transform: true,
      whitelist: true,
      forbidNonWhitelisted: true,
      forbidUnknownValues: true,
    }));
    await app.init();

    await prisma.parameter.updateMany({
      where: { key: 'batch.reference_duration_days' },
      data: { status: ConfigurationStatus.APPROVED, effectiveAt: new Date() },
    });
    await prisma.formula.updateMany({
      where: { key: { in: ['present_count', 'mortality_rate', 'viability_rate', 'daily_gain', 'live_weight_produced', 'feed_conversion', 'occupancy_rate', 'entry_completeness', 'revenue', 'production_cost_per_kg', 'margin', 'margin_rate'] } },
      data: { status: ConfigurationStatus.APPROVED, effectiveAt: new Date() },
    });
    await prisma.threshold.updateMany({
      where: { key: 'health.daily_mortality_rate' },
      data: { status: ConfigurationStatus.APPROVED, value: 3, effectiveAt: new Date() },
    });

    dgeToken = await login('dge@agritrack.ga');
    vetToken = await login('veterinaire@agritrack.ga');
  });

  afterAll(async () => {
    await app?.close();
    await prisma?.$disconnect();
  });

  it('creates a farm, replays a clientUuid payload idempotently, qualifies an alert, closes the batch and scans its QR', async () => {
    const farmResponse = await request(app.getHttpServer())
      .post('/api/farms')
      .set(bearer(dgeToken))
      .send({
        name: `Ferme e2e ${Date.now()}`,
        cohort: 'COHORTE_1',
        provinceCode: 'ESTUAIRE',
        locality: 'Libreville',
        latitude: 0.41,
        longitude: 9.45,
        capacity: 2000,
      });
    if (farmResponse.status !== 201) {
      console.error(`POST /api/farms unexpected response: ${JSON.stringify({ status: farmResponse.status, body: farmResponse.body })}`);
    }
    expect({ status: farmResponse.status, body: farmResponse.body }).toMatchObject({ status: 201 });
    farmId = farmResponse.body.id as string;
    expect(farmResponse.body.code).toMatch(/^EST-\d{4}$/);

    await request(app.getHttpServer())
      .patch(`/api/farms/${farmId}/status`)
      .set(bearer(dgeToken))
      .send({ status: FarmStatus.ACTIVE, reason: 'E2E' })
      .expect(200);

    const placedAt = new Date(Date.now() - 86_400_000).toISOString();
    const batchResponse = await request(app.getHttpServer())
      .post(`/api/farms/${farmId}/batches`)
      .set(bearer(dgeToken))
      .send({ clientUuid: randomUUID(), placedAt, placedCount: 1000, initialAverageWeight: 0.04 })
      .expect(201);
    batchId = batchResponse.body.id as string;
    expect(batchResponse.body.code).toMatch(/-B\d{2}$/);

    const dailyRecord = {
      clientUuid: randomUUID(),
      recordDate: new Date().toISOString(),
      deaths: 50,
      feedConsumedKg: 90,
      suspicionReported: false,
    };
    const syncResponse = await request(app.getHttpServer())
      .post(`/api/batches/${batchId}/daily-records`)
      .set(bearer(dgeToken))
      .send(dailyRecord)
      .expect(201);
    expect(syncResponse.body.idempotentReplay).toBe(false);

    const replayResponse = await request(app.getHttpServer())
      .post(`/api/batches/${batchId}/daily-records`)
      .set(bearer(dgeToken))
      .send(dailyRecord)
      .expect(201);
    expect(replayResponse.body.idempotentReplay).toBe(true);
    expect(await prisma.dailyRecord.count({ where: { batchId, clientUuid: dailyRecord.clientUuid } })).toBe(1);

    const alerts = await request(app.getHttpServer()).get('/api/alerts').set(bearer(vetToken)).expect(200);
    const alert = (alerts.body as { id: string; sourceDailyRecordId: string }[]).find((item) => item.sourceDailyRecordId === syncResponse.body.record.id);
    expect(alert).toBeDefined();
    await request(app.getHttpServer()).put(`/api/alerts/${alert!.id}/status`).set(bearer(vetToken)).send({ status: 'UNDER_REVIEW' }).expect(200);
    await request(app.getHttpServer()).put(`/api/alerts/${alert!.id}/status`).set(bearer(vetToken)).send({ status: 'CONFIRMED' }).expect(200);
    await request(app.getHttpServer()).post(`/api/alerts/${alert!.id}/publish`).set(bearer(vetToken)).expect(201);

    const operator = await prisma.operator.findUniqueOrThrow({ where: { code: 'OPER-DEMO-001' } });
    const outflowResponse = await request(app.getHttpServer())
      .post(`/api/batches/${batchId}/outflows`)
      .set(bearer(dgeToken))
      .send({
        clientUuid: randomUUID(),
        type: 'SLAUGHTER',
        occurredAt: new Date().toISOString(),
        quantity: 500,
        averageWeight: 1.7,
        operatorId: operator.id,
        destination: 'Abattoir de démonstration',
      })
      .expect(201);

    await request(app.getHttpServer())
      .post(`/api/batches/${batchId}/close`)
      .set(bearer(dgeToken))
      .send({ reason: 'Clôture e2e' })
      .expect(201);
    expect((await prisma.batch.findUniqueOrThrow({ where: { id: batchId } })).status).toBe(BatchStatus.CLOSED);

    const lotResponse = await request(app.getHttpServer())
      .get(`/api/traceability/lots/${outflowResponse.body.lotId}`)
      .set(bearer(dgeToken))
      .expect(200);
    const lotCode = lotResponse.body.code as string;
    expect(await prisma.qrCode.findUnique({ where: { lotId: outflowResponse.body.lotId } })).not.toBeNull();

    const publicResponse = await request(app.getHttpServer())
      .get(`/api/public/lots/${encodeURIComponent(lotCode)}`)
      .set('User-Agent', 'AgriTrack-e2e')
      .expect(200);
    expect(publicResponse.body.notice).toContain('pas un certificat sanitaire');
    expect(JSON.stringify(publicResponse.body)).not.toContain('revenueDomiciliation');
    expect(await prisma.scanLog.count({ where: { submittedToken: lotCode, outcome: 'OK' } })).toBe(1);
  });

  async function login(email: string): Promise<string> {
    const response = await request(app.getHttpServer())
      .post('/api/auth/login')
      .send({ email, password: process.env.DEMO_PASSWORD ?? 'PoufaDemo2026!' })
      .expect(201);
    return response.body.accessToken as string;
  }

  function bearer(token: string): Record<string, string> {
    return { Authorization: `Bearer ${token}` };
  }
});