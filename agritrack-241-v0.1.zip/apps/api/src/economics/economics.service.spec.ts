import { FormulaEngine } from '../parameters/formula-engine';
import { EconomicsService } from './economics.service';

describe('EconomicsService calculations', () => {
  it('calculates cost, gross margin and margin rate from configured formulas', () => {
    const formulas = new Map([
      ['production_cost_per_kg', { expression: 'charges / live_weight_produced_kg', variables: ['charges', 'live_weight_produced_kg'] }],
      ['margin', { expression: 'revenue - charges', variables: ['revenue', 'charges'] }],
      ['margin_rate', { expression: 'margin / revenue * 100', variables: ['margin', 'revenue'] }],
    ]);

    const totals = EconomicsService.calculateTotals(1250, 800, 500, formulas, new FormulaEngine());

    expect(totals).toEqual({
      revenue: 1250,
      charges: 800,
      liveWeightProducedKg: 500,
      productionCostPerKg: 1.6,
      margin: 450,
      marginRatePercent: 36,
    });
  });

  it('does not fabricate economic metrics when formulas are not approved', () => {
    const totals = EconomicsService.calculateTotals(1250, 800, 500, new Map(), new FormulaEngine());
    expect(totals.margin).toBeNull();
    expect(totals.productionCostPerKg).toBeNull();
    expect(totals.marginRatePercent).toBeNull();
  });
});