import { BadRequestException, ConflictException, Injectable } from '@nestjs/common';
import { ConfigurationStatus, Prisma, RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { BatchesService } from '../batches/batches.service';
import { FormulaEngine } from '../parameters/formula-engine';
import { PerformanceService } from '../performance/performance.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { CreateSaleDto } from './dto/create-sale.dto';

export interface EconomicTotals {
  revenue: number;
  charges: number;
  liveWeightProducedKg: number;
  productionCostPerKg: number | null;
  margin: number | null;
  marginRatePercent: number | null;
}

@Injectable()
export class EconomicsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly batches: BatchesService,
    private readonly performance: PerformanceService,
    private readonly formulas: FormulaEngine,
    private readonly audit: AuditService,
  ) {}

  async listSales(user: AuthenticatedUser, batchId?: string) {
    const operatorOnly = user.roles.includes(RoleCode.OPERATEUR);
    const where: Prisma.SaleWhereInput = {
      ...(operatorOnly ? {} : { batch: { farm: await this.scopes.farmWhere(user) } }),
      ...(batchId ? { batchId } : {}),
    };
    if (operatorOnly) where.operator = { assignments: { some: { userId: user.id } } };
    return this.prisma.sale.findMany({
      where,
      include: { operator: { select: { code: true, name: true } }, batch: { select: { code: true, farmId: true } }, outflow: { include: { lots: { select: { code: true } } } } },
      orderBy: { soldAt: 'desc' },
    });
  }

  async createSale(batchId: string, input: CreateSaleDto, user: AuthenticatedUser) {
    const batch = await this.batches.findOne(batchId, user);
    const existing = await this.prisma.sale.findUnique({ where: { clientUuid: input.clientUuid } });
    if (existing) {
      if (existing.batchId !== batchId) throw new ConflictException('UUID client deja utilise pour une autre vente.');
      return existing;
    }
    const unitValue = await this.prisma.listValue.findFirst({ where: { listKey: 'sale_unit', code: input.unit, active: true } });
    if (!unitValue) throw new BadRequestException('Unite de vente non configuree.');
    const soldAt = new Date(input.soldAt);
    if (soldAt < batch.placedAt || soldAt > new Date()) throw new BadRequestException('Date de vente invalide.');
    if (input.operatorId) {
      const operator = await this.prisma.operator.findFirst({
        where: {
          id: input.operatorId,
          active: true,
          agreementSignedAt: { not: null },
          agreementExpiresAt: { gt: soldAt },
        },
        select: { id: true },
      });
      if (!operator) throw new BadRequestException('Acheteur inactif ou convention expiree.');
    }
    if (input.outflowId) {
      const outflow = await this.prisma.outflow.findFirst({ where: { id: input.outflowId, batchId }, select: { id: true, quantity: true, sale: { select: { id: true } } } });
      if (!outflow) throw new BadRequestException('La sortie n appartient pas a cette bande.');
      if (outflow.sale) throw new ConflictException('Cette sortie est deja rattachee a une vente.');
      if (input.quantity > outflow.quantity) throw new BadRequestException('La quantite vendue depasse la sortie rattachee.');
    }
    const revenueFormula = await this.prisma.formula.findFirst({
      where: { key: 'revenue', status: ConfigurationStatus.APPROVED },
      orderBy: { version: 'desc' },
    });
    if (!revenueFormula) throw new BadRequestException('La formule approuvee de chiffre d affaires est absente.');
    const revenue = this.formulas.evaluate(revenueFormula.expression, revenueFormula.variables as string[], {
      quantity: input.quantity,
      unit_price: input.unitPrice,
    });
    const sale = await this.prisma.sale.create({
      data: {
        clientUuid: input.clientUuid,
        batchId,
        operatorId: input.operatorId,
        outflowId: input.outflowId,
        soldAt,
        quantity: new Prisma.Decimal(input.quantity),
        unit: input.unit,
        unitPrice: new Prisma.Decimal(input.unitPrice),
        invoiceReference: input.invoiceReference,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'Sale', entityId: sale.id, after: sale });
    return { ...sale, revenue };
  }

  async listExpenses(user: AuthenticatedUser, batchId?: string) {
    return this.prisma.expense.findMany({
      where: {
        farm: await this.scopes.farmWhere(user),
        ...(batchId ? { batchId } : {}),
      },
      include: { batch: { select: { code: true } }, sourceInputUsage: { select: { inputCode: true, quantity: true } } },
      orderBy: { incurredAt: 'desc' },
    });
  }

  async createExpense(farmId: string, input: CreateExpenseDto, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, farmId);
    if (new Date(input.incurredAt) > new Date()) throw new BadRequestException('La date de depense ne peut pas etre future.');
    const category = await this.prisma.listValue.findFirst({ where: { listKey: 'expense_category', code: input.category, active: true } });
    if (!category) throw new BadRequestException('Poste de depense non configure.');
    if (input.batchId && !await this.prisma.batch.findFirst({ where: { id: input.batchId, farmId }, select: { id: true } })) {
      throw new BadRequestException('La bande n appartient pas a cette ferme.');
    }
    const duplicate = await this.prisma.expense.findUnique({ where: { clientUuid: input.clientUuid } });
    if (duplicate) {
      if (duplicate.farmId !== farmId) throw new ConflictException('UUID client deja utilise pour une autre ferme.');
      return duplicate;
    }
    let amount = input.amount;
    if (input.inputUsageId) {
      const usage = await this.prisma.inputUsage.findFirst({
        where: { id: input.inputUsageId, farmId },
        include: { receipt: { select: { unitCost: true } } },
      });
      if (!usage) throw new BadRequestException('Usage d intrant introuvable dans cette ferme.');
      if (!usage.receipt?.unitCost) throw new BadRequestException('Aucun cout unitaire n est disponible sur la reception de cet intrant.');
      const derivedAmount = usage.quantity.mul(usage.receipt.unitCost);
      if (amount !== undefined && !new Prisma.Decimal(amount).equals(derivedAmount)) {
        throw new BadRequestException('Le montant d intrant doit correspondre au cout de la reception source.');
      }
      amount = derivedAmount.toNumber();
      if (input.batchId && usage.batchId && input.batchId !== usage.batchId) {
        throw new BadRequestException('La bande differe de la bande de consommation source.');
      }
    }
    if (amount === undefined) throw new BadRequestException('Un montant ou un usage d intrant source est requis.');
    const expense = await this.prisma.expense.create({
      data: {
        clientUuid: input.clientUuid,
        farmId,
        batchId: input.batchId,
        category: input.category,
        description: input.description,
        amount: new Prisma.Decimal(amount),
        incurredAt: new Date(input.incurredAt),
        reference: input.reference,
        sourceInputUsageId: input.inputUsageId,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'Expense', entityId: expense.id, after: expense });
    return expense;
  }

  async batchTotals(batchId: string, user: AuthenticatedUser) {
    await this.batches.findOne(batchId, user);
    const [sales, expenses, performance, formulas] = await Promise.all([
      this.prisma.sale.findMany({ where: { batchId }, select: { quantity: true, unitPrice: true } }),
      this.prisma.expense.findMany({ where: { batchId }, select: { amount: true } }),
      this.performance.calculate(batchId),
      this.prisma.formula.findMany({ where: { status: ConfigurationStatus.APPROVED }, orderBy: { version: 'desc' } }),
    ]);
    const formulaMap = new Map<string, { expression: string; variables: string[] }>();
    for (const formula of formulas) {
      if (!formulaMap.has(formula.key)) formulaMap.set(formula.key, { expression: formula.expression, variables: formula.variables as string[] });
    }
    const revenue = sales.reduce((sum, sale) => sum + this.runFormula(formulaMap, 'revenue', { quantity: sale.quantity.toNumber(), unit_price: sale.unitPrice.toNumber() }), 0);
    const charges = expenses.reduce((sum, expense) => sum + expense.amount.toNumber(), 0);
    return EconomicsService.calculateTotals(revenue, charges, performance.atDate.liveWeightProducedKg ?? 0, formulaMap, this.formulas);
  }

  static calculateTotals(
    revenue: number,
    charges: number,
    liveWeightProducedKg: number,
    formulas: Map<string, { expression: string; variables: string[] }>,
    engine: FormulaEngine,
  ): EconomicTotals {
    const calculate = (key: string, values: Record<string, number>): number | null => {
      const formula = formulas.get(key);
      if (!formula) return null;
      try {
        return engine.evaluate(formula.expression, formula.variables, values);
      } catch {
        return null;
      }
    };
    const margin = calculate('margin', { revenue, charges });
    return {
      revenue,
      charges,
      liveWeightProducedKg,
      productionCostPerKg: calculate('production_cost_per_kg', { charges, live_weight_produced_kg: liveWeightProducedKg }),
      margin,
      marginRatePercent: margin === null ? null : calculate('margin_rate', { margin, revenue }),
    };
  }

  private runFormula(
    formulas: Map<string, { expression: string; variables: string[] }>,
    key: string,
    values: Record<string, number>,
  ): number {
    const formula = formulas.get(key);
    if (!formula) throw new BadRequestException(`La formule approuvee ${key} est absente.`);
    return this.formulas.evaluate(formula.expression, formula.variables, values);
  }
}