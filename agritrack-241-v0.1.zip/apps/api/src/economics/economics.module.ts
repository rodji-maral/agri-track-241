import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { BatchesModule } from '../batches/batches.module';
import { ParametersModule } from '../parameters/parameters.module';
import { PerformanceModule } from '../performance/performance.module';
import { ScopeModule } from '../scopes/scope.module';
import { EconomicsController } from './economics.controller';
import { EconomicsService } from './economics.service';

@Module({
  imports: [AuditModule, BatchesModule, ParametersModule, PerformanceModule, ScopeModule],
  controllers: [EconomicsController],
  providers: [EconomicsService],
  exports: [EconomicsService],
})
export class EconomicsModule {}