import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction, RoleCode } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { Roles } from '../auth/roles.decorator';
import { CreateExpenseDto } from './dto/create-expense.dto';
import { CreateSaleDto } from './dto/create-sale.dto';
import { EconomicsService } from './economics.service';

@ApiTags('Economie')
@ApiBearerAuth()
@Controller()
export class EconomicsController {
  constructor(private readonly economics: EconomicsService) {}

  @Get('batches/:batchId/economics')
  @Roles(RoleCode.ELEVEUR, RoleCode.AGENT_TECHNIQUE, RoleCode.POUFA_DGE, RoleCode.BCEG, RoleCode.ADMIN)
  @Permissions('finance', PermissionAction.CONSULT)
  batchTotals(@Param('batchId') batchId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.economics.batchTotals(batchId, user);
  }

  @Get('sales')
  @Roles(RoleCode.ELEVEUR, RoleCode.AGENT_TECHNIQUE, RoleCode.POUFA_DGE, RoleCode.BCEG, RoleCode.OPERATEUR, RoleCode.ADMIN)
  @Permissions('finance', PermissionAction.CONSULT)
  listSales(@CurrentUser() user: AuthenticatedUser, @Query('batchId') batchId?: string) {
    return this.economics.listSales(user, batchId);
  }

  @Post('batches/:batchId/sales')
  @Roles(RoleCode.ELEVEUR, RoleCode.AGENT_TECHNIQUE, RoleCode.POUFA_DGE, RoleCode.ADMIN)
  @Permissions('finance', PermissionAction.CREATE)
  createSale(@Param('batchId') batchId: string, @Body() body: CreateSaleDto, @CurrentUser() user: AuthenticatedUser) {
    return this.economics.createSale(batchId, body, user);
  }

  @Get('expenses')
  @Roles(RoleCode.ELEVEUR, RoleCode.AGENT_TECHNIQUE, RoleCode.POUFA_DGE, RoleCode.BCEG, RoleCode.ADMIN)
  @Permissions('finance', PermissionAction.CONSULT)
  listExpenses(@CurrentUser() user: AuthenticatedUser, @Query('batchId') batchId?: string) {
    return this.economics.listExpenses(user, batchId);
  }

  @Post('farms/:farmId/expenses')
  @Roles(RoleCode.ELEVEUR, RoleCode.AGENT_TECHNIQUE, RoleCode.POUFA_DGE, RoleCode.ADMIN)
  @Permissions('finance', PermissionAction.CREATE)
  createExpense(@Param('farmId') farmId: string, @Body() body: CreateExpenseDto, @CurrentUser() user: AuthenticatedUser) {
    return this.economics.createExpense(farmId, body, user);
  }
}