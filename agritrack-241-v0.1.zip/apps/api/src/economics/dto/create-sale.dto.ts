import { Type } from 'class-transformer';
import { IsDateString, IsNumber, IsOptional, IsString, IsUUID, MaxLength, Min } from 'class-validator';

export class CreateSaleDto {
  @IsUUID()
  clientUuid!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  operatorId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  outflowId?: string;

  @Type(() => Number)
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0.001)
  quantity!: number;

  @IsString()
  @MaxLength(24)
  unit!: string;

  @Type(() => Number)
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0)
  unitPrice!: number;

  @IsDateString()
  soldAt!: string;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  invoiceReference?: string;
}