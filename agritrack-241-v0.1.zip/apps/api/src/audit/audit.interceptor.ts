import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { Observable, concatMap, from } from 'rxjs';
import { AuthenticatedUser } from '../auth/auth.types';
import { AuditService } from './audit.service';

interface RequestWithUser extends Request {
  user?: AuthenticatedUser;
}

@Injectable()
export class AuditInterceptor implements NestInterceptor {
  constructor(private readonly audit: AuditService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const http = context.switchToHttp();
    const request = http.getRequest<RequestWithUser>();
    const response = http.getResponse<Response>();
    const path = request.originalUrl.split('?')[0];
    if (path.startsWith('/api/docs') || path.startsWith('/api/auth/')) return next.handle();

    return next.handle().pipe(concatMap((result: unknown) => from(this.audit.record({
      actorId: request.user?.id,
      action: request.method,
      entityType: request.route?.path ?? path,
      entityId: Array.isArray(request.params?.id) ? request.params.id[0] : request.params?.id ?? 'collection',
      after: { statusCode: response.statusCode },
      metadata: {
        method: request.method,
        path,
        statusCode: response.statusCode,
        queryKeys: Object.keys(request.query ?? {}).sort(),
      },
    })).pipe(concatMap(() => [result]))));
  }
}
