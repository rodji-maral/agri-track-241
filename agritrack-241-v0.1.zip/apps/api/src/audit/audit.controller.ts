import { Controller, Get, Query, Res } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { Response } from 'express';
import { CurrentUser } from '../auth/current-user.decorator';
import { AuthenticatedUser } from '../auth/auth.types';
import { Permissions } from '../auth/permissions.decorator';
import { AuditService } from './audit.service';

@ApiTags('Audit')
@ApiBearerAuth()
@Controller('audit')
export class AuditController {
  constructor(private readonly audit: AuditService) {}

  @Get('integrity')
  @Permissions('audit', PermissionAction.CONSULT)
  async verify(@CurrentUser() user: AuthenticatedUser) {
    await this.audit.record({ actorId: user.id, action: 'VERIFY', entityType: 'AuditLog', entityId: 'chain' });
    return this.audit.verifyIntegrity();
  }

  @Get('export')
  @Permissions('audit', PermissionAction.EXPORT)
  async export(
    @CurrentUser() user: AuthenticatedUser,
    @Query('format') format: string | undefined,
    @Res() response: Response,
  ): Promise<void> {
    await this.audit.record({
      actorId: user.id,
      action: 'EXPORT',
      entityType: 'AuditLog',
      entityId: 'chain',
      metadata: { format: format === 'csv' ? 'csv' : 'json' },
    });
    const entries = await this.audit.exportEntries(10000);
    if (format === 'csv') {
      const columns = ['sequence', 'occurredAt', 'actorId', 'action', 'entityType', 'entityId', 'previousHash', 'entryHash'];
      const rows = entries.map((entry) => columns.map((column) => this.csvCell(entry[column as keyof typeof entry])).join(','));
      response.type('text/csv; charset=utf-8').send([columns.join(','), ...rows].join('\n'));
      return;
    }
    response.json(entries.map((entry) => ({ ...entry, sequence: entry.sequence.toString() })));
  }

  private csvCell(value: unknown): string {
    const text = value instanceof Date ? value.toISOString() : String(value ?? '');
    return `"${text.replaceAll('"', '""')}"`;
  }
}
