import { AuditService } from './audit.service';
import { PrismaService } from '../prisma/prisma.service';

describe('AuditService hash chain', () => {
  it('detects an altered entry in the hash chain', async () => {
    const entry = {
      id: 'entry-1',
      sequence: 1n,
      actorId: 'user-1',
      action: 'CREATE',
      entityType: 'Farm',
      entityId: 'farm-1',
      occurredAt: new Date('2026-01-01T12:00:00.000Z'),
      before: null,
      after: { name: 'Ferme A' },
      metadata: {},
      previousHash: null,
    };
    const validHash = AuditService.hashEntry(entry);
    const prisma = { auditLog: { findMany: jest.fn().mockResolvedValue([{ ...entry, action: 'DELETE', entryHash: validHash }]) } };
    const audit = new AuditService(prisma as unknown as PrismaService);

    await expect(audit.verifyIntegrity()).resolves.toMatchObject({
      valid: false,
      checkedEntries: 0,
      brokenAtSequence: '1',
    });
  });

  it('confirme une chaîne intacte', async () => {
    const entry = {
      id: 'entry-1',
      sequence: 1n,
      actorId: null,
      action: 'GET',
      entityType: 'Farm',
      entityId: 'collection',
      occurredAt: new Date('2026-01-01T12:00:00.000Z'),
      before: null,
      after: { statusCode: 200 },
      metadata: {},
      previousHash: null,
    };
    const prisma = { auditLog: { findMany: jest.fn().mockResolvedValue([{ ...entry, entryHash: AuditService.hashEntry(entry) }]) } };
    const audit = new AuditService(prisma as unknown as PrismaService);
    await expect(audit.verifyIntegrity()).resolves.toEqual({ valid: true, checkedEntries: 1 });
  });
});