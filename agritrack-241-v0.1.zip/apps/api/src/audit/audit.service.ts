import { createHash, randomUUID } from 'node:crypto';
import { Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

export interface AuditWrite {
  actorId?: string;
  action: string;
  entityType: string;
  entityId: string;
  before?: unknown;
  after?: unknown;
  metadata?: unknown;
}

export interface AuditIntegrityResult {
  valid: boolean;
  checkedEntries: number;
  brokenAtSequence?: string;
  expectedHash?: string;
  actualHash?: string;
}

interface ChainEntry {
  id: string;
  sequence: bigint;
  actorId: string | null;
  action: string;
  entityType: string;
  entityId: string;
  occurredAt: Date;
  before: Prisma.JsonValue | null;
  after: Prisma.JsonValue | null;
  metadata: Prisma.JsonValue;
  previousHash: string | null;
  entryHash: string;
}

interface HashableEntry {
  id: string;
  sequence: bigint;
  actorId: string | null;
  action: string;
  entityType: string;
  entityId: string;
  occurredAt: Date;
  before: unknown;
  after: unknown;
  metadata: unknown;
  previousHash: string | null;
}

@Injectable()
export class AuditService {
  constructor(private readonly prisma: PrismaService) {}

  async record(input: AuditWrite): Promise<void> {
    await this.prisma.$transaction(async (transaction) => {
      await transaction.$executeRaw`SELECT pg_advisory_xact_lock(2410241001)`;
      const previous = await transaction.auditLog.findFirst({
        orderBy: { sequence: 'desc' },
        select: { sequence: true, entryHash: true },
      });
      const occurredAt = new Date();
      const before = this.toJson(input.before);
      const after = this.toJson(input.after);
      const entry = {
        id: randomUUID(),
        sequence: (previous?.sequence ?? 0n) + 1n,
        actorId: input.actorId ?? null,
        action: input.action,
        entityType: input.entityType,
        entityId: input.entityId,
        occurredAt,
        before: before ?? null,
        after: after ?? null,
        metadata: this.toJson(input.metadata) ?? {},
        previousHash: previous?.entryHash ?? null,
      };
      const entryHash = AuditService.hashEntry(entry);
      const data: Prisma.AuditLogUncheckedCreateInput = {
        ...entry,
        before: before === undefined ? Prisma.DbNull : before,
        after: after === undefined ? Prisma.DbNull : after,
        entryHash,
      };
      await transaction.auditLog.create({ data });
    });
  }

  async verifyIntegrity(): Promise<AuditIntegrityResult> {
    const entries = await this.prisma.auditLog.findMany({
      orderBy: { sequence: 'asc' },
    }) as ChainEntry[];
    let previousHash: string | null = null;
    let previousSequence = 0n;
    for (const entry of entries) {
      const expected = AuditService.hashEntry({
        id: entry.id,
        sequence: entry.sequence,
        actorId: entry.actorId,
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId,
        occurredAt: entry.occurredAt,
        before: entry.before,
        after: entry.after,
        metadata: entry.metadata,
        previousHash: entry.previousHash,
      });
      if (
        entry.sequence !== previousSequence + 1n ||
        entry.previousHash !== previousHash ||
        entry.entryHash !== expected
      ) {
        return {
          valid: false,
          checkedEntries: Number(previousSequence),
          brokenAtSequence: entry.sequence.toString(),
          expectedHash: expected,
          actualHash: entry.entryHash,
        };
      }
      previousSequence = entry.sequence;
      previousHash = entry.entryHash;
    }
    return { valid: true, checkedEntries: entries.length };
  }

  async exportEntries(limit: number): Promise<ChainEntry[]> {
    return this.prisma.auditLog.findMany({
      orderBy: { sequence: 'asc' },
      take: limit,
    }) as Promise<ChainEntry[]>;
  }

  static hashEntry(entry: HashableEntry): string {
    const canonical = AuditService.canonicalize({
      id: entry.id,
      sequence: entry.sequence.toString(),
      actorId: entry.actorId,
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId,
      occurredAt: entry.occurredAt.toISOString(),
      before: entry.before,
      after: entry.after,
      metadata: entry.metadata,
      previousHash: entry.previousHash,
    });
    return createHash('sha256').update(canonical).digest('hex');
  }

  private toJson(value: unknown): Prisma.InputJsonValue | undefined {
    if (value === undefined) return undefined;
    return JSON.parse(JSON.stringify(value)) as Prisma.InputJsonValue;
  }

  private static canonicalize(value: unknown): string {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map((item) => AuditService.canonicalize(item)).join(',')}]`;
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${AuditService.canonicalize(record[key])}`).join(',')}}`;
  }
}
