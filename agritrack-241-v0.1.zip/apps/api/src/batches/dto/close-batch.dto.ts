import { IsDateString, IsOptional, IsString, MaxLength } from 'class-validator';

export class CloseBatchDto {
  @IsOptional()
  @IsDateString()
  closedAt?: string;

  @IsOptional()
  @IsString()
  @MaxLength(300)
  reason?: string;
}