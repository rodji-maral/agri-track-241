import { IsDateString, IsNumber, IsOptional, IsString, IsUUID, MaxLength, Min } from 'class-validator';

export class OpenBatchDto {
  @IsDateString()
  placedAt!: string;

  @IsNumber({ allowNaN: false, allowInfinity: false, maxDecimalPlaces: 0 })
  @Min(1)
  placedCount!: number;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0)
  initialAverageWeight?: number;

  @IsOptional()
  @IsString()
  @MaxLength(300)
  notes?: string;

  @IsUUID()
  clientUuid!: string;
}