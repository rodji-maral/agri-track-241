import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { ParametersModule } from '../parameters/parameters.module';
import { PerformanceModule } from '../performance/performance.module';
import { ScopeModule } from '../scopes/scope.module';
import { BatchesController } from './batches.controller';
import { BatchesService } from './batches.service';

@Module({
  imports: [AuditModule, ScopeModule, ParametersModule, PerformanceModule],
  controllers: [BatchesController],
  providers: [BatchesService],
  exports: [BatchesService],
})
export class BatchesModule {}