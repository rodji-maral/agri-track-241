import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { PerformanceService } from '../performance/performance.service';
import { CloseBatchDto } from './dto/close-batch.dto';
import { OpenBatchDto } from './dto/open-batch.dto';
import { BatchesService } from './batches.service';

@ApiTags('Bandes')
@ApiBearerAuth()
@Controller()
export class BatchesController {
  constructor(
    private readonly batches: BatchesService,
    private readonly performance: PerformanceService,
  ) {}

  @Get('batches')
  @Permissions('batch', PermissionAction.CONSULT)
  list(@CurrentUser() user: AuthenticatedUser, @Query('farmId') farmId?: string) {
    return this.batches.list(user, farmId);
  }

  @Get('batches/:id')
  @Permissions('batch', PermissionAction.CONSULT)
  findOne(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.batches.findOne(id, user);
  }

  @Post('farms/:farmId/batches')
  @Permissions('batch', PermissionAction.CREATE)
  open(@Param('farmId') farmId: string, @Body() body: OpenBatchDto, @CurrentUser() user: AuthenticatedUser) {
    return this.batches.open(farmId, body, user);
  }

  @Post('batches/:id/close')
  @Permissions('batch', PermissionAction.MODIFY)
  close(@Param('id') id: string, @Body() body: CloseBatchDto, @CurrentUser() user: AuthenticatedUser) {
    return this.batches.close(id, body, user);
  }

  @Get('batches/:id/performance')
  @Permissions('batch', PermissionAction.CONSULT)
  async performanceAt(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser, @Query('at') at?: string) {
    await this.batches.findOne(id, user);
    return this.performance.calculate(id, at ? new Date(at) : undefined);
  }

  @Get('batches/:id/weighing-reminder')
  @Permissions('weighing', PermissionAction.CONSULT)
  weighingReminder(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.batches.weighingReminder(id, user);
  }
}