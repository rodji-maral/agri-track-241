import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { BatchStatus, ConfigurationStatus, FarmStatus, Prisma, RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { ParametersService } from '../parameters/parameters.service';
import { PerformanceService } from '../performance/performance.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { CloseBatchDto } from './dto/close-batch.dto';
import { OpenBatchDto } from './dto/open-batch.dto';

@Injectable()
export class BatchesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly audit: AuditService,
    private readonly performance: PerformanceService,
  ) {}

  async list(user: AuthenticatedUser, farmId?: string) {
    return this.prisma.batch.findMany({
      where: await this.scopes.batchWhere(user, farmId),
      orderBy: [{ placedAt: 'desc' }, { rank: 'desc' }],
      include: { farm: { select: { id: true, code: true, name: true, provinceCode: true } } },
    });
  }

  async findOne(id: string, user: AuthenticatedUser) {
    const batch = await this.prisma.batch.findFirst({
      where: { id, ...(await this.scopes.batchWhere(user)) },
      include: { farm: { select: { id: true, code: true, name: true, capacity: true, provinceCode: true } } },
    });
    if (!batch) throw new NotFoundException('Bande introuvable.');
    return batch;
  }

  async open(farmId: string, input: OpenBatchDto, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, farmId);
    const placedAt = new Date(input.placedAt);
    if (placedAt.getTime() > Date.now()) throw new BadRequestException('La date de mise en place ne peut pas etre future.');
    const farm = await this.prisma.farm.findUnique({ where: { id: farmId } });
    if (!farm || farm.status !== FarmStatus.ACTIVE) throw new BadRequestException('La ferme doit etre active pour ouvrir une bande.');
    const referenceDuration = await this.referenceDurationDays();
    const nextDueDate = new Date(placedAt.getTime() + referenceDuration * 86_400_000);

    const existingClientBatch = await this.prisma.batch.findUnique({ where: { clientUuid: input.clientUuid } });
    if (existingClientBatch) {
      if (existingClientBatch.farmId !== farmId) throw new ConflictException('UUID client deja utilise pour une autre ferme.');
      return existingClientBatch;
    }

    const batch = await this.prisma.$transaction(async (transaction) => {
      await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`batch:${farmId}`}))`;
      const currentBatches = await transaction.batch.findMany({
        where: { farmId, status: { in: [BatchStatus.PLANNED, BatchStatus.ACTIVE] } },
        select: { placedCount: true },
      });
      const currentOccupancy = currentBatches.reduce((sum, item) => sum + item.placedCount, 0);
      if (currentOccupancy + input.placedCount > farm.capacity) {
        throw new ConflictException('La capacite disponible de la ferme serait depassee.');
      }
      const rank = (await transaction.batch.aggregate({ where: { farmId }, _max: { rank: true } }))._max.rank ?? 0;
      const counterKey = `batch:${farmId}`;
      const currentCounter = await transaction.identifierCounter.findUnique({ where: { key: counterKey } });
      const nextRank = Math.max(rank + 1, currentCounter ? currentCounter.nextValue : 1);
      await transaction.identifierCounter.upsert({
        where: { key: counterKey },
        create: { key: counterKey, nextValue: nextRank + 1 },
        update: { nextValue: nextRank + 1 },
      });
      const code = `${farm.code}-B${String(nextRank).padStart(2, '0')}`;
      const created = await transaction.batch.create({
        data: {
          clientUuid: input.clientUuid,
          code,
          farmId,
          rank: nextRank,
          status: BatchStatus.ACTIVE,
          placedAt,
          plannedCloseAt: nextDueDate,
          placedCount: input.placedCount,
          initialStock: input.placedCount,
          initialAverageWeight: input.initialAverageWeight,
        },
      });
      await transaction.batchStatusHistory.create({
        data: { batchId: created.id, fromStatus: null, toStatus: BatchStatus.ACTIVE, changedById: user.id, reason: input.notes ?? 'Ouverture' },
      });
      return created;
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'Batch', entityId: batch.id, after: batch });
    return { ...batch, performance: await this.performance.calculate(batch.id) };
  }

  async close(id: string, input: CloseBatchDto, user: AuthenticatedUser) {
    const current = await this.findOne(id, user);
    if (current.status !== BatchStatus.ACTIVE || current.isLocked || current.closedAt) {
      throw new ConflictException('Une bande cloturee est en lecture seule.');
    }
    const closedAt = input.closedAt ? new Date(input.closedAt) : new Date();
    if (closedAt < current.placedAt || closedAt > new Date()) throw new BadRequestException('Date de cloture invalide.');
    const summary = await this.performance.calculate(id, closedAt);
    const updated = await this.prisma.$transaction(async (transaction) => {
      await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`batch:${id}`}))`;
      const currentLocked = await transaction.batch.findUnique({ where: { id } });
      if (!currentLocked || currentLocked.status !== BatchStatus.ACTIVE || currentLocked.isLocked) {
        throw new ConflictException('La bande est deja cloturee ou indisponible.');
      }
      const result = await transaction.batch.update({
        where: { id, isLocked: false },
        data: { status: BatchStatus.CLOSED, closedAt, isLocked: true, lockedAt: closedAt, closureSummary: summary.atDate as unknown as Prisma.InputJsonValue },
      });
      await transaction.batchStatusHistory.create({
        data: { batchId: id, fromStatus: current.status, toStatus: BatchStatus.CLOSED, changedById: user.id, reason: input.reason ?? 'Cloture' },
      });
      return result;
    });
    await this.audit.record({ actorId: user.id, action: 'CLOSE', entityType: 'Batch', entityId: id, before: current, after: updated });
    return updated;
  }

  async maybeAutoClose(id: string, userId: string, occurredAt: Date): Promise<void> {
    const batch = await this.prisma.batch.findUnique({ where: { id } });
    if (!batch || batch.status !== BatchStatus.ACTIVE || batch.isLocked) return;
    const referenceDays = await this.referenceDurationDays();
    const ageDays = Math.floor((Date.UTC(occurredAt.getUTCFullYear(), occurredAt.getUTCMonth(), occurredAt.getUTCDate()) -
      Date.UTC(batch.placedAt.getUTCFullYear(), batch.placedAt.getUTCMonth(), batch.placedAt.getUTCDate())) / 86_400_000) + 1;
    if (ageDays >= referenceDays) {
      await this.close(id, { closedAt: occurredAt.toISOString(), reason: 'Cloture automatique selon duree de reference' }, {
        id: userId,
        email: '',
        roles: [RoleCode.POUFA_DGE],
      });
    }
  }

  async assertWritable(id: string, user?: AuthenticatedUser) {
    const batch = await this.prisma.batch.findFirst({
      where: { id, ...(user ? await this.scopes.batchWhere(user) : {}) },
    });
    if (!batch) throw new NotFoundException('Bande introuvable.');
    if (batch.status !== BatchStatus.ACTIVE || batch.isLocked || batch.closedAt) {
      throw new ConflictException('Une bande cloturee est en lecture seule.');
    }
    return batch;
  }

  async weighingReminder(id: string, user: AuthenticatedUser) {
    const batch = await this.findOne(id, user);
    const frequency = await this.prisma.parameter.findFirst({
      where: { key: 'weighing.frequency_per_week', status: ConfigurationStatus.APPROVED },
      orderBy: { version: 'desc' },
    });
    const timesPerWeek = Number(frequency?.value ?? 1);
    if (!Number.isFinite(timesPerWeek) || timesPerWeek <= 0) {
      throw new BadRequestException('Frequence de pesee non configuree.');
    }
    const intervalDays = 7 / timesPerWeek;
    const last = await this.prisma.weighing.findFirst({ where: { batchId: id }, orderBy: { weighedAt: 'desc' } });
    const dueAt = last ? new Date(last.weighedAt.getTime() + intervalDays * 86_400_000) : batch.placedAt;
    return { batchId: id, frequencyPerWeek: timesPerWeek, intervalDays, lastWeighedAt: last?.weighedAt ?? null, dueAt, overdue: dueAt <= new Date() };
  }

  private async referenceDurationDays(): Promise<number> {
    const parameter = await this.prisma.parameter.findFirst({
      where: { key: 'batch.reference_duration_days', status: ConfigurationStatus.APPROVED },
      orderBy: { version: 'desc' },
    });
    const value = Number(parameter?.value);
    if (!Number.isFinite(value) || value <= 0) throw new BadRequestException('Duree de reference de bande invalide.');
    return value;
  }
}