import { ForbiddenException } from '@nestjs/common';
import { RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { NotificationsService } from '../notifications/notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { AlertsService } from './alerts.service';

describe('AlertsService early warning', () => {
  it('creates a new alert when daily mortality exceeds the approved threshold', async () => {
    const alert = { id: 'alert-1', title: 'Seuil de mortalite depasse', status: 'NEW' };
    const transaction = {
      alert: { findUnique: jest.fn().mockResolvedValue(null), create: jest.fn().mockResolvedValue(alert) },
      alertStatusHistory: { create: jest.fn() },
    };
    const prisma = {
      alert: { findUnique: jest.fn().mockResolvedValue(null) },
      batch: { findUnique: jest.fn().mockResolvedValue({ farm: { id: 'farm-1', provinceCode: 'ESTUAIRE' } }) },
      threshold: { findFirst: jest.fn().mockResolvedValue({ value: { toNumber: () => 3 } }) },
      listValue: { findFirst: jest.fn().mockResolvedValue({ code: 'MODERATE' }) },
      user: { findMany: jest.fn().mockResolvedValue([{ id: 'vet-1' }]) },
      $transaction: jest.fn((callback: (tx: typeof transaction) => unknown) => callback(transaction)),
    };
    const notifications = { notify: jest.fn() };
    const service = new AlertsService(
      prisma as unknown as PrismaService,
      {} as ScopeService,
      { record: jest.fn() } as unknown as AuditService,
      notifications as unknown as NotificationsService,
    );

    const result = await service.evaluateMortality({
      dailyRecordId: 'daily-1',
      batchId: 'batch-1',
      deaths: 4,
      presentBefore: 100,
      suspicionReported: false,
      occurredAt: new Date('2026-05-01T00:00:00.000Z'),
      actorId: 'farmer-1',
    });

    expect(result).toEqual(alert);
    expect(transaction.alert.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ sourceDailyRecordId: 'daily-1', status: 'NEW' }),
    }));
    expect(notifications.notify).toHaveBeenCalledWith(expect.objectContaining({ userId: 'vet-1', category: 'HEALTH_ALERT' }));
  });

  it('denies alert publication to an ELEVEUR before accessing persistence', async () => {
    const service = new AlertsService({} as PrismaService, {} as ScopeService, {} as AuditService, {} as NotificationsService);
    await expect(service.publish('alert-1', {
      id: 'farmer-1',
      email: 'farmer@test.ga',
      roles: [RoleCode.ELEVEUR],
    })).rejects.toBeInstanceOf(ForbiddenException);
  });
});