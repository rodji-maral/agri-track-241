import { Body, Controller, Get, Param, Post, Put } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { Roles } from '../auth/roles.decorator';
import { CurrentUser } from '../auth/current-user.decorator';
import { AuthenticatedUser } from '../auth/auth.types';
import { Permissions } from '../auth/permissions.decorator';
import { RoleCode } from '@prisma/client';
import { TransitionAlertDto } from './dto/transition-alert.dto';
import { AlertsService } from './alerts.service';

@ApiTags('Alertes sanitaires')
@ApiBearerAuth()
@Controller('alerts')
@Roles(RoleCode.VETERINAIRE)
export class AlertsController {
  constructor(private readonly alerts: AlertsService) {}

  @Get()
  @Permissions('alert', PermissionAction.CONSULT)
  list(@CurrentUser() user: AuthenticatedUser) {
    return this.alerts.list(user);
  }

  @Put(':id/status')
  @Permissions('alert', PermissionAction.VALIDATE)
  transition(@Param('id') id: string, @Body() body: TransitionAlertDto, @CurrentUser() user: AuthenticatedUser) {
    return this.alerts.transition(id, body.status, body.note, user);
  }

  @Post(':id/publish')
  @Permissions('alert', PermissionAction.VALIDATE)
  publish(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.alerts.publish(id, user);
  }
}