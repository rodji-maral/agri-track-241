import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { AlertSeverity, AlertStatus, ConfigurationStatus, ProvinceCode, RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { NotificationsService } from '../notifications/notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';

@Injectable()
export class AlertsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationsService,
  ) {}

  async evaluateMortality(input: {
    dailyRecordId: string;
    batchId: string;
    deaths: number;
    presentBefore: number;
    suspicionReported: boolean;
    occurredAt: Date;
    actorId: string;
  }) {
    const previousAlert = await this.prisma.alert.findUnique({ where: { sourceDailyRecordId: input.dailyRecordId } });
    if (previousAlert) return previousAlert;
    const [batch, threshold, severityValue] = await Promise.all([
      this.prisma.batch.findUnique({ where: { id: input.batchId }, include: { farm: { select: { id: true, provinceCode: true } } } }),
      this.prisma.threshold.findFirst({ where: { key: 'health.daily_mortality_rate', status: ConfigurationStatus.APPROVED }, orderBy: { version: 'desc' } }),
      this.prisma.listValue.findFirst({ where: { listKey: 'alert_severity', active: true }, orderBy: { sortOrder: 'asc' } }),
    ]);
    if (!batch) throw new NotFoundException('Bande introuvable pour evaluation sanitaire.');
    const dailyRate = input.presentBefore > 0 ? (input.deaths / input.presentBefore) * 100 : null;
    const exceedsThreshold = dailyRate !== null && threshold !== null && dailyRate > threshold.value.toNumber();
    if (!input.suspicionReported && !exceedsThreshold) return null;
    if (!severityValue || !Object.values(AlertSeverity).includes(severityValue.code as AlertSeverity)) {
      throw new BadRequestException('La gravite par defaut des alertes n est pas configuree.');
    }
    const alert = await this.prisma.$transaction(async (transaction) => {
      const current = await transaction.alert.findUnique({ where: { sourceDailyRecordId: input.dailyRecordId } });
      if (current) return current;
      const created = await transaction.alert.create({
        data: {
          sourceDailyRecordId: input.dailyRecordId,
          batchId: input.batchId,
          farmId: batch.farm.id,
          title: input.suspicionReported ? 'Suspicion sanitaire signalee' : 'Seuil de mortalite depasse',
          description: `Evaluation automatique : ${input.deaths} mortalites pour ${input.presentBefore} sujets presents${dailyRate === null ? '' : ` (${dailyRate.toFixed(2)} %)`}. A qualifier par un veterinaire.`,
          severity: severityValue.code as AlertSeverity,
          status: AlertStatus.NEW,
          createdById: input.actorId,
        },
      });
      await transaction.alertStatusHistory.create({
        data: { alertId: created.id, fromStatus: null, toStatus: AlertStatus.NEW, changedById: input.actorId, note: 'Creation automatique apres saisie quotidienne' },
      });
      return created;
    });
    await this.notifyVeterinarians(batch.farm.id, batch.farm.provinceCode, alert.id, alert.title, alert.description);
    await this.audit.record({ actorId: input.actorId, action: 'CREATE_EARLY_ALERT', entityType: 'Alert', entityId: alert.id, after: alert });
    return alert;
  }

  async evaluateDailyRecord(dailyRecordId: string, actorId: string) {
    const record = await this.prisma.dailyRecord.findUnique({
      where: { id: dailyRecordId },
      include: { batch: true },
    });
    if (!record) throw new NotFoundException('Fiche quotidienne introuvable pour evaluation sanitaire.');
    const [priorRecords, priorOutflows] = await Promise.all([
      this.prisma.dailyRecord.findMany({ where: { batchId: record.batchId, recordDate: { lt: record.recordDate } }, select: { deaths: true } }),
      this.prisma.outflow.findMany({ where: { batchId: record.batchId, occurredAt: { lt: record.recordDate } }, select: { quantity: true } }),
    ]);
    const presentBefore = record.batch.placedCount -
      priorRecords.reduce((sum, item) => sum + item.deaths, 0) -
      priorOutflows.reduce((sum, item) => sum + item.quantity, 0);
    return this.evaluateMortality({
      dailyRecordId,
      batchId: record.batchId,
      deaths: record.deaths,
      presentBefore,
      suspicionReported: record.suspicionReported,
      occurredAt: record.recordDate,
      actorId,
    });
  }

  async list(user: AuthenticatedUser) {
    this.assertVeterinarian(user);
    return this.prisma.alert.findMany({
      where: { farm: await this.scopes.farmWhere(user) },
      include: { history: { orderBy: { changedAt: 'asc' } }, batch: { select: { code: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async transition(id: string, nextStatus: AlertStatus, note: string | undefined, user: AuthenticatedUser) {
    this.assertVeterinarian(user);
    const current = await this.prisma.alert.findFirst({ where: { id, farm: await this.scopes.farmWhere(user) } });
    if (!current) throw new NotFoundException('Alerte introuvable.');
    if (current.publishedAt) throw new BadRequestException('Une alerte publiee ne peut plus changer de statut.');
    if (nextStatus === current.status) return current;
    const transitionCode = `${current.status}:${nextStatus}`;
    const allowed = await this.prisma.listValue.findFirst({
      where: { listKey: 'alert_status_transition', code: transitionCode, active: true },
      select: { id: true },
    });
    if (!allowed) throw new BadRequestException('Transition d alerte non autorisee par le parametrage.');
    const updated = await this.prisma.$transaction(async (transaction) => {
      const result = await transaction.alert.update({
        where: { id, status: current.status },
        data: {
          status: nextStatus,
          ...(nextStatus === AlertStatus.CONFIRMED || nextStatus === AlertStatus.REFUTED
            ? { qualifiedById: user.id, qualifiedAt: new Date() }
            : {}),
        },
      });
      await transaction.alertStatusHistory.create({
        data: { alertId: id, fromStatus: current.status, toStatus: nextStatus, changedById: user.id, note },
      });
      return result;
    });
    await this.audit.record({ actorId: user.id, action: 'STATUS_CHANGE', entityType: 'Alert', entityId: id, before: current, after: updated });
    return updated;
  }

  async publish(id: string, user: AuthenticatedUser) {
    this.assertVeterinarian(user);
    const current = await this.prisma.alert.findFirst({ where: { id, farm: await this.scopes.farmWhere(user) } });
    if (!current) throw new NotFoundException('Alerte introuvable.');
    if (current.status !== AlertStatus.CONFIRMED || !current.qualifiedById) {
      throw new BadRequestException('Seule une alerte confirmee par un veterinaire peut etre publiee.');
    }
    if (current.publishedAt) return current;
    const updated = await this.prisma.$transaction(async (transaction) => {
      const result = await transaction.alert.update({ where: { id, status: AlertStatus.CONFIRMED, publishedAt: null }, data: { publishedAt: new Date() } });
      await transaction.alertStatusHistory.create({
        data: { alertId: id, fromStatus: AlertStatus.CONFIRMED, toStatus: AlertStatus.CONFIRMED, changedById: user.id, event: 'PUBLISHED', note: 'Publication autorite veterinaire' },
      });
      return result;
    });
    await this.audit.record({ actorId: user.id, action: 'PUBLISH', entityType: 'Alert', entityId: id, before: current, after: updated });
    return updated;
  }

  private assertVeterinarian(user: AuthenticatedUser): void {
    if (!user.roles.includes(RoleCode.VETERINAIRE)) throw new ForbiddenException('Action reservee au role VETERINAIRE.');
  }

  private async notifyVeterinarians(farmId: string, provinceCode: ProvinceCode, alertId: string, title: string, message: string): Promise<void> {
    const veterinarians = await this.prisma.user.findMany({
      where: {
        status: 'ACTIVE',
        roles: { some: { role: { code: RoleCode.VETERINAIRE } } },
        scopes: { some: { OR: [{ farmId }, { provinceCode }] } },
      },
      select: { id: true },
    });
    await Promise.all(veterinarians.map(({ id }) => this.notifications.notify({
      userId: id,
      category: 'HEALTH_ALERT',
      title,
      message,
      entityType: 'Alert',
      entityId: alertId,
    })));
  }
}