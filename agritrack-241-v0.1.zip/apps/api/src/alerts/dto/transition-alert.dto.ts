import { AlertStatus } from '@prisma/client';
import { IsEnum, IsOptional, IsString, MaxLength } from 'class-validator';

export class TransitionAlertDto {
  @IsEnum(AlertStatus)
  status!: AlertStatus;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  note?: string;
}