import { PassThrough } from 'node:stream';
import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { AggregateStatus, Prisma, RoleCode } from '@prisma/client';
import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { BatchesService } from '../batches/batches.service';
import { EconomicsService } from '../economics/economics.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { CreateReportTemplateDto } from './dto/create-report-template.dto';
import { ExportReportDto } from './dto/export-report.dto';

interface ReportColumn {
  key: string;
  label: string;
}

interface ReportDefinition {
  title?: string;
  datasource?: string;
  columns?: ReportColumn[];
}

@Injectable()
export class ReportsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly batches: BatchesService,
    private readonly economics: EconomicsService,
    private readonly audit: AuditService,
  ) {}

  listTemplates() {
    return this.prisma.reportTemplate.findMany({ where: { active: true }, orderBy: [{ key: 'asc' }, { version: 'desc' }] });
  }

  async createTemplate(input: CreateReportTemplateDto, user: AuthenticatedUser) {
    if (!user.roles.includes(RoleCode.ADMIN)) throw new ForbiddenException('Seul ADMIN peut administrer les modeles de rapport.');
    const previous = await this.prisma.reportTemplate.findFirst({ where: { key: input.key }, orderBy: { version: 'desc' } });
    return this.prisma.$transaction(async (transaction) => {
      await transaction.reportTemplate.updateMany({ where: { key: input.key, active: true }, data: { active: false } });
      const template = await transaction.reportTemplate.create({
        data: {
          key: input.key,
          name: input.name,
          description: input.description,
          definition: input.definition as Prisma.InputJsonValue,
          version: (previous?.version ?? 0) + 1,
          active: true,
        },
      });
      await this.audit.record({ actorId: user.id, action: 'CREATE_REPORT_TEMPLATE_VERSION', entityType: 'ReportTemplate', entityId: template.id, after: template });
      return template;
    });
  }

  async export(key: string, query: ExportReportDto, user: AuthenticatedUser): Promise<{ contentType: string; fileName: string; body: Buffer }> {
    const template = await this.prisma.reportTemplate.findFirst({ where: { key, active: true }, orderBy: { version: 'desc' } });
    if (!template) throw new NotFoundException('Modele de rapport introuvable.');
    const definition = template.definition as unknown as ReportDefinition;
    const rows = await this.getRows(key, definition, query, user);
    const columns = definition.columns ?? Object.keys(rows[0] ?? {}).map((field) => ({ key: field, label: field }));
    await this.audit.record({
      actorId: user.id,
      action: 'EXPORT',
      entityType: 'Report',
      entityId: key,
      metadata: { format: query.format, rowCount: rows.length, templateVersion: template.version, from: query.from ?? null, to: query.to ?? null },
    });
    const fileName = `${key}-${new Date().toISOString().slice(0, 10)}.${query.format}`;
    if (query.format === 'csv') return { contentType: 'text/csv; charset=utf-8', fileName, body: Buffer.from(this.toCsv(rows, columns), 'utf8') };
    if (query.format === 'xlsx') return { contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', fileName, body: await this.toXlsx(rows, columns, definition.title ?? template.name) };
    return { contentType: 'application/pdf', fileName, body: await this.toPdf(rows, columns, definition.title ?? template.name) };
  }

  private async getRows(key: string, definition: ReportDefinition, query: ExportReportDto, user: AuthenticatedUser): Promise<Record<string, unknown>[]> {
    const datasource = definition.datasource ?? key;
    if (datasource === 'national_monthly') {
      if (!query.from || !query.to) throw new BadRequestException('La periode est obligatoire pour le rapport national.');
      if (new Date(query.from) > new Date(query.to)) throw new BadRequestException('La date de debut doit preceder la date de fin.');
      const province = query.provinceCode ?? 'NATIONAL';
      const reportKey = `dashboard.${province}.ALL.ALL.ALL`;
      const aggregate = await this.prisma.publishedAggregate.findFirst({
        where: {
          reportKey,
          periodStart: new Date(query.from),
          periodEnd: new Date(query.to),
          status: AggregateStatus.PUBLISHED,
        },
      });
      if (!aggregate) throw new NotFoundException('Aucune donnee nationale validee par la MAEDR pour cette periode.');
      const data = aggregate.data;
      return Array.isArray(data) ? data as Record<string, unknown>[] : [data as Record<string, unknown>];
    }
    if (datasource === 'batch_end') {
      if (!query.batchId) throw new BadRequestException('batchId est obligatoire pour un rapport de fin de bande.');
      const batch = await this.batches.findOne(query.batchId, user);
      if (batch.status !== 'CLOSED') throw new BadRequestException('Le rapport de fin de bande exige une bande cloturee.');
      const totals = await this.economics.batchTotals(batch.id, user);
      return [{ batchCode: batch.code, farmId: batch.farmId, status: batch.status, ...totals }];
    }
    if (datasource !== 'weekly') throw new BadRequestException('Source de rapport non prise en charge par le modele.');
    if (!query.from || !query.to) throw new BadRequestException('Les bornes de periode sont obligatoires.');
    if (new Date(query.from) > new Date(query.to)) throw new BadRequestException('La date de debut doit preceder la date de fin.');
    const batches = await this.prisma.batch.findMany({
      where: {
        farm: await this.scopes.farmWhere(user),
        placedAt: { gte: new Date(query.from), lte: new Date(query.to) },
      },
      include: { farm: { select: { code: true, provinceCode: true } } },
      orderBy: { placedAt: 'asc' },
      take: 2000,
    });
    const rows = await Promise.all(batches.map(async (batch) => ({
      batchCode: batch.code,
      farmCode: batch.farm.code,
      provinceCode: batch.farm.provinceCode,
      status: batch.status,
      ...(await this.economics.batchTotals(batch.id, user)),
    })));
    return rows;
  }

  private toCsv(rows: Record<string, unknown>[], columns: ReportColumn[]): string {
    const cell = (value: unknown) => {
      const text = String(value ?? '');
      const safe = /^[=+\-@\t\r]/.test(text) ? `'${text}` : text;
      return `"${safe.replaceAll('"', '""')}"`;
    };
    return [columns.map((column) => cell(column.label)).join(','), ...rows.map((row) => columns.map((column) => cell(this.field(row, column.key))).join(','))].join('\r\n');
  }

  private async toXlsx(rows: Record<string, unknown>[], columns: ReportColumn[], title: string): Promise<Buffer> {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(title.slice(0, 31));
    worksheet.columns = columns.map((column) => ({ header: column.label, key: column.key, width: Math.min(40, Math.max(12, column.label.length + 2)) }));
    for (const row of rows) worksheet.addRow(Object.fromEntries(columns.map((column) => [column.key, this.field(row, column.key)])));
    const output = await workbook.xlsx.writeBuffer();
    return Buffer.from(output);
  }

  private async toPdf(rows: Record<string, unknown>[], columns: ReportColumn[], title: string): Promise<Buffer> {
    const document = new PDFDocument({ size: 'A4', margin: 40, layout: 'landscape' });
    const stream = new PassThrough();
    const chunks: Buffer[] = [];
    stream.on('data', (chunk: Buffer) => chunks.push(chunk));
    document.pipe(stream);
    document.fontSize(18).text(title, { align: 'left' });
    document.moveDown(0.5).fontSize(8).text(`Genere le ${new Date().toISOString()}`);
    document.moveDown();
    document.fontSize(8).text(columns.map((column) => column.label).join(' | '));
    document.moveDown(0.5);
    for (const row of rows) {
      document.fontSize(7).text(columns.map((column) => String(this.field(row, column.key) ?? '')).join(' | '), { width: 760 });
    }
    document.end();
    await new Promise<void>((resolve, reject) => {
      stream.on('end', resolve);
      stream.on('error', reject);
      document.on('error', reject);
    });
    return Buffer.concat(chunks);
  }

  private field(record: Record<string, unknown>, path: string): unknown {
    return path.split('.').reduce<unknown>((current, key) =>
      typeof current === 'object' && current !== null ? (current as Record<string, unknown>)[key] : undefined, record);
  }
}