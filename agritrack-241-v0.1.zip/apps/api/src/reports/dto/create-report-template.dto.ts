import { IsObject, IsOptional, IsString, Matches, MaxLength } from 'class-validator';

export class CreateReportTemplateDto {
  @IsString()
  @Matches(/^[a-z][a-z0-9_.-]{1,79}$/)
  key!: string;

  @IsString()
  @MaxLength(140)
  name!: string;

  @IsOptional()
  @IsString()
  @MaxLength(300)
  description?: string;

  @IsObject()
  definition!: Record<string, unknown>;
}