import { IsDateString, IsIn, IsOptional, IsString, MaxLength } from 'class-validator';

export class ExportReportDto {
  @IsIn(['pdf', 'csv', 'xlsx'])
  format!: 'pdf' | 'csv' | 'xlsx';

  @IsOptional()
  @IsDateString()
  from?: string;

  @IsOptional()
  @IsDateString()
  to?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  batchId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(20)
  provinceCode?: string;
}