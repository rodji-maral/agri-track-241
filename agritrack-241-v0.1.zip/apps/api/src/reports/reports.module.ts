import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { BatchesModule } from '../batches/batches.module';
import { EconomicsModule } from '../economics/economics.module';
import { ScopeModule } from '../scopes/scope.module';
import { ReportsController } from './reports.controller';
import { ReportsService } from './reports.service';

@Module({
  imports: [AuditModule, BatchesModule, EconomicsModule, ScopeModule],
  controllers: [ReportsController],
  providers: [ReportsService],
})
export class ReportsModule {}