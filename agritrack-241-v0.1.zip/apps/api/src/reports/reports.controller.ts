import { BadRequestException, Body, Controller, Get, Param, Post, Query, Res } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction, RoleCode } from '@prisma/client';
import { Response } from 'express';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { Roles } from '../auth/roles.decorator';
import { CreateReportTemplateDto } from './dto/create-report-template.dto';
import { ExportReportDto } from './dto/export-report.dto';
import { ReportsService } from './reports.service';

@ApiTags('Rapports')
@ApiBearerAuth()
@Controller('reports')
export class ReportsController {
  constructor(private readonly reports: ReportsService) {}

  @Get('templates')
  @Roles(RoleCode.ADMIN, RoleCode.POUFA_DGE, RoleCode.MAEDR)
  @Permissions('report', PermissionAction.CONSULT)
  listTemplates() {
    return this.reports.listTemplates();
  }

  @Post('templates')
  @Roles(RoleCode.ADMIN)
  @Permissions('report', PermissionAction.ADMINISTER)
  createTemplate(@Body() body: CreateReportTemplateDto, @CurrentUser() user: AuthenticatedUser) {
    return this.reports.createTemplate(body, user);
  }

  @Get(':key/export')
  @Roles(RoleCode.ELEVEUR, RoleCode.AGENT_TECHNIQUE, RoleCode.POUFA_DGE, RoleCode.MAEDR, RoleCode.BCEG, RoleCode.ADMIN)
  @Permissions('report', PermissionAction.EXPORT)
  async export(
    @Param('key') key: string,
    @Query() query: ExportReportDto,
    @CurrentUser() user: AuthenticatedUser,
    @Res() response: Response,
  ): Promise<void> {
    if (!query.format) throw new BadRequestException('Le format d export est obligatoire.');
    const output = await this.reports.export(key, query, user);
    response.setHeader('Content-Type', output.contentType);
    response.setHeader('Content-Disposition', `attachment; filename="${output.fileName}"`);
    response.send(output.body);
  }
}