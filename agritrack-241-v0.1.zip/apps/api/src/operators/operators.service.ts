import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { PrismaService } from '../prisma/prisma.service';
import { AssignOperatorUserDto } from './dto/assign-operator-user.dto';
import { CreateOperatorDto } from './dto/create-operator.dto';

@Injectable()
export class OperatorsService {
  constructor(private readonly prisma: PrismaService, private readonly audit: AuditService) {}

  async list(user: AuthenticatedUser) {
    const where = user.roles.some((role) => role === RoleCode.ADMIN || role === RoleCode.POUFA_DGE)
      ? {}
      : { assignments: { some: { userId: user.id } } };
    return this.prisma.operator.findMany({
      where,
      select: {
        id: true,
        code: true,
        name: true,
        operatorType: true,
        agreementSignedAt: true,
        agreementExpiresAt: true,
        agreementReference: true,
        active: true,
      },
      orderBy: { name: 'asc' },
    });
  }

  async create(input: CreateOperatorDto, user: AuthenticatedUser) {
    const signedAt = new Date(input.agreementSignedAt);
    const expiresAt = new Date(input.agreementExpiresAt);
    if (signedAt > new Date() || expiresAt <= new Date() || expiresAt <= signedAt) {
      throw new BadRequestException('La convention doit etre signee et encore valide.');
    }
    const exists = await this.prisma.operator.findUnique({ where: { code: input.code } });
    if (exists) throw new ConflictException('Ce code operateur existe deja.');
    const operator = await this.prisma.operator.create({
      data: {
        code: input.code,
        name: input.name.trim(),
        operatorType: input.operatorType.trim(),
        agreementSignedAt: signedAt,
        agreementExpiresAt: expiresAt,
        agreementReference: input.agreementReference.trim(),
        active: true,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE_OPERATOR', entityType: 'Operator', entityId: operator.id, after: operator });
    return operator;
  }

  async assignUser(operatorId: string, input: AssignOperatorUserDto, user: AuthenticatedUser) {
    const operator = await this.prisma.operator.findUnique({ where: { id: operatorId } });
    if (!operator) throw new NotFoundException('Operateur introuvable.');
    if (!operator.active || !operator.agreementSignedAt || !operator.agreementExpiresAt || operator.agreementExpiresAt <= new Date()) {
      throw new BadRequestException('Une convention signee valide est obligatoire pour activer un compte operateur.');
    }
    const account = await this.prisma.user.findUnique({ where: { id: input.userId }, include: { roles: { include: { role: true } } } });
    if (!account || !account.roles.some(({ role }) => role.code === RoleCode.OPERATEUR)) {
      throw new BadRequestException('Le compte cible doit porter le role OPERATEUR.');
    }
    const assignment = await this.prisma.operatorUserAssignment.upsert({
      where: { operatorId_userId: { operatorId, userId: input.userId } },
      update: {},
      create: { operatorId, userId: input.userId, assignedBy: user.id },
    });
    await this.audit.record({ actorId: user.id, action: 'ASSIGN_OPERATOR_USER', entityType: 'OperatorUserAssignment', entityId: `${operatorId}:${input.userId}`, after: assignment });
    return assignment;
  }

  async assertCanReceive(userId: string, operatorId: string): Promise<void> {
    const assignment = await this.prisma.operatorUserAssignment.findFirst({
      where: {
        userId,
        operatorId,
        operator: {
          active: true,
          agreementSignedAt: { not: null },
          agreementExpiresAt: { gt: new Date() },
        },
      },
      select: { userId: true },
    });
    if (!assignment) throw new ForbiddenException('Le compte operateur ne peut pas recevoir ce lot.');
  }
}