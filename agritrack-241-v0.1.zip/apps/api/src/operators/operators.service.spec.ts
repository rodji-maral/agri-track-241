import { BadRequestException } from '@nestjs/common';
import { AuditService } from '../audit/audit.service';
import { PrismaService } from '../prisma/prisma.service';
import { OperatorsService } from './operators.service';

describe('OperatorsService convention enforcement', () => {
  it('refuses an expired convention before creating an active operator', async () => {
    const create = jest.fn();
    const service = new OperatorsService({ operator: { findUnique: jest.fn(), create } } as unknown as PrismaService, {} as AuditService);
    await expect(service.create({
      code: 'ABAT-01',
      name: 'Abattoir test',
      operatorType: 'ABATTOIR',
      agreementSignedAt: '2026-01-01T00:00:00.000Z',
      agreementReference: 'CONVENTION-01',
      agreementExpiresAt: '2026-02-01T00:00:00.000Z',
    }, { id: 'dge-1', email: 'dge@test.ga', roles: [] })).rejects.toBeInstanceOf(BadRequestException);
    expect(create).not.toHaveBeenCalled();
  });
});