import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RoleCode } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Roles } from '../auth/roles.decorator';
import { AssignOperatorUserDto } from './dto/assign-operator-user.dto';
import { CreateOperatorDto } from './dto/create-operator.dto';
import { OperatorsService } from './operators.service';

@ApiTags('Operateurs')
@ApiBearerAuth()
@Controller('operators')
export class OperatorsController {
  constructor(private readonly operators: OperatorsService) {}

  @Get()
  @Roles(RoleCode.ADMIN, RoleCode.POUFA_DGE, RoleCode.OPERATEUR)
  list(@CurrentUser() user: AuthenticatedUser) {
    return this.operators.list(user);
  }

  @Post()
  @Roles(RoleCode.ADMIN, RoleCode.POUFA_DGE)
  create(@Body() body: CreateOperatorDto, @CurrentUser() user: AuthenticatedUser) {
    return this.operators.create(body, user);
  }

  @Post(':id/accounts')
  @Roles(RoleCode.ADMIN, RoleCode.POUFA_DGE)
  assignUser(@Param('id') id: string, @Body() body: AssignOperatorUserDto, @CurrentUser() user: AuthenticatedUser) {
    return this.operators.assignUser(id, body, user);
  }
}