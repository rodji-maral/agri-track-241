import { IsString, MaxLength } from 'class-validator';

export class AssignOperatorUserDto {
  @IsString()
  @MaxLength(100)
  userId!: string;
}