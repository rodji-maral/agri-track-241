import { IsDateString, IsString, MaxLength, Matches } from 'class-validator';

export class CreateOperatorDto {
  @IsString()
  @Matches(/^[A-Z0-9_-]{2,24}$/)
  code!: string;

  @IsString()
  @MaxLength(160)
  name!: string;

  @IsString()
  @MaxLength(80)
  operatorType!: string;

  @IsDateString()
  agreementSignedAt!: string;

  @IsString()
  @MaxLength(200)
  agreementReference!: string;

  @IsDateString()
  agreementExpiresAt!: string;
}