import { Controller, Get, Headers, Ip, Param } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { Public } from '../auth/public.decorator';
import { QrCodeService } from './qr-code.service';

@ApiTags('Traceabilite publique')
@Controller('public/lots')
export class PublicLotsController {
  constructor(private readonly qrCodes: QrCodeService) {}

  @Public()
  @Get(':code')
  @Throttle({ default: { limit: 30, ttl: 60_000 } })
  @ApiOperation({ summary: "Informations publiques du lot; ne constitue pas un certificat sanitaire" })
  find(@Param('code') code: string, @Ip() ip: string, @Headers('user-agent') userAgent?: string) {
    return this.qrCodes.getPublicLot(code, ip, userAgent);
  }
}