import { IsDateString, IsInt, IsOptional, IsString, IsUUID, MaxLength, Min } from 'class-validator';

export class ReceiveLotDto {
  @IsUUID()
  clientUuid!: string;

  @IsString()
  @MaxLength(100)
  operatorId!: string;

  @IsInt()
  @Min(0)
  receivedQuantity!: number;

  @IsOptional()
  @IsDateString()
  receivedAt?: string;
}