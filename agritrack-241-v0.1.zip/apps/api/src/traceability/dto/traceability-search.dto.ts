import { IsDateString, IsOptional, IsString, MaxLength } from 'class-validator';

export class TraceabilitySearchDto {
  @IsOptional()
  @IsString()
  @MaxLength(100)
  farmId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  batchId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  operatorId?: string;

  @IsOptional()
  @IsDateString()
  from?: string;

  @IsOptional()
  @IsDateString()
  to?: string;
}