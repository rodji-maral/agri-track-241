import { IsDateString, IsString, IsUUID, MaxLength } from 'class-validator';

export class VerifyTransferDto {
  @IsUUID()
  clientUuid!: string;

  @IsDateString()
  occurredAt!: string;

  @IsString()
  @MaxLength(160)
  reference!: string;
}