import { NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { QrCodeService } from './qr-code.service';

describe('QrCodeService public scan', () => {
  it('journalise un QR inconnu avant de le rejeter', async () => {
    const scanCreate = jest.fn();
    const service = new QrCodeService({
      qrCode: { findFirst: jest.fn().mockResolvedValue(null) },
      scanLog: { create: scanCreate },
    } as unknown as PrismaService);

    await expect(service.getPublicLot('UNKNOWN-LOT', '127.0.0.1', 'test-agent')).rejects.toBeInstanceOf(NotFoundException);
    expect(scanCreate).toHaveBeenCalledWith({ data: expect.objectContaining({ submittedToken: 'UNKNOWN-LOT', outcome: 'UNKNOWN', qrCodeId: undefined }) });
  });

  it('journalise puis rejette un QR associé à un lot clos', async () => {
    const scanCreate = jest.fn();
    const service = new QrCodeService({
      qrCode: {
        findFirst: jest.fn().mockResolvedValue({
          id: 'qr-1',
          active: false,
          closedAt: new Date(),
          lot: { code: 'EST-0001-B01-L01', status: 'CLOSED' },
        }),
      },
      scanLog: { create: scanCreate },
    } as unknown as PrismaService);

    await expect(service.getPublicLot('EST-0001-B01-L01', '127.0.0.1', 'test-agent')).rejects.toBeInstanceOf(NotFoundException);
    expect(scanCreate).toHaveBeenCalledWith({ data: expect.objectContaining({ qrCodeId: 'qr-1', outcome: 'CLOSED' }) });
  });

  it('returns only public farm data for an active lot scan', async () => {
    const service = new QrCodeService({
      qrCode: {
        findFirst: jest.fn().mockResolvedValue({
          id: 'qr-1',
          active: true,
          closedAt: null,
          lot: {
            code: 'EST-0001-B01-L01',
            status: 'OPEN',
            producedAt: new Date('2026-01-01T00:00:00.000Z'),
            batch: {
              farm: {
                name: 'Ferme Nkok',
                locality: { name: 'Nkok' },
                revenueDomiciliation: 'private bank data',
              },
            },
            events: [],
          },
        }),
      },
      scanLog: { create: jest.fn() },
    } as unknown as PrismaService);

    const publicLot = await service.getPublicLot('EST-0001-B01-L01', '127.0.0.1', 'test-agent');
    expect(publicLot).toMatchObject({ producer: 'Ferme Nkok', locality: 'Nkok', status: 'OPEN' });
    expect(JSON.stringify(publicLot)).not.toContain('private bank data');
    expect(publicLot.notice).toContain('pas un certificat sanitaire');
  });
});