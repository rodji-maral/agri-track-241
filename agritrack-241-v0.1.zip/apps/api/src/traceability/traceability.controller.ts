import { BadRequestException, Body, Controller, Get, Param, Post, Query, Res } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction, RoleCode } from '@prisma/client';
import { Response } from 'express';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { Roles } from '../auth/roles.decorator';
import { ReceiveLotDto } from './dto/receive-lot.dto';
import { TraceabilitySearchDto } from './dto/traceability-search.dto';
import { VerifyTransferDto } from './dto/verify-transfer.dto';
import { QrCodeService } from './qr-code.service';
import { TraceabilityService } from './traceability.service';

@ApiTags('Tracabilite')
@ApiBearerAuth()
@Controller('traceability')
export class TraceabilityController {
  constructor(
    private readonly traceability: TraceabilityService,
    private readonly qrCodes: QrCodeService,
  ) {}

  @Get('lots/:id')
  @Permissions('lot', PermissionAction.CONSULT)
  detail(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.traceability.detail(id, user);
  }

  @Get('lots/:id/qr')
  @Permissions('lot', PermissionAction.CONSULT)
  async qr(@Param('id') id: string, @Query('format') format: string | undefined, @CurrentUser() user: AuthenticatedUser, @Res() response: Response): Promise<void> {
    await this.traceability.detail(id, user);
    if (format && format !== 'png' && format !== 'svg') throw new BadRequestException('Format QR attendu: png ou svg.');
    const image = await this.qrCodes.render(id, format === 'svg' ? 'svg' : 'png');
    response.type(image.contentType).send(image.body);
  }

  @Post('lots/:id/verify-transfer')
  @Roles(RoleCode.ELEVEUR, RoleCode.AGENT_TECHNIQUE, RoleCode.POUFA_DGE)
  @Permissions('lot', PermissionAction.MODIFY)
  verifyTransfer(@Param('id') id: string, @Body() body: VerifyTransferDto, @CurrentUser() user: AuthenticatedUser) {
    return this.traceability.verifyTransfer(id, body, user);
  }

  @Post('lots/:id/receive')
  @Roles(RoleCode.OPERATEUR)
  @Permissions('lot', PermissionAction.MODIFY)
  receive(@Param('id') id: string, @Body() body: ReceiveLotDto, @CurrentUser() user: AuthenticatedUser) {
    return this.traceability.receiveAtOperator(id, body, user);
  }

  @Get('search')
  @Permissions('lot', PermissionAction.CONSULT)
  async search(
    @Query() query: TraceabilitySearchDto,
    @Query('format') format: string | undefined,
    @CurrentUser() user: AuthenticatedUser,
    @Res() response: Response,
  ): Promise<void> {
    if (format && format !== 'csv' && format !== 'json') throw new BadRequestException('Format attendu: csv ou json.');
    const result = await this.traceability.export(query, user, format === 'csv' ? 'csv' : 'json');
    if (typeof result === 'string') {
      response.type('text/csv; charset=utf-8').send(result);
      return;
    }
    response.json(result);
  }

  @Get('indicators')
  @Permissions('lot', PermissionAction.CONSULT)
  indicators(@CurrentUser() user: AuthenticatedUser) {
    return this.traceability.indicators(user);
  }
}