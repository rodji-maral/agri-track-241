import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { OperatorsModule } from '../operators/operators.module';
import { ParametersModule } from '../parameters/parameters.module';
import { ScopeModule } from '../scopes/scope.module';
import { PublicLotsController } from './public-lots.controller';
import { QrCodeService } from './qr-code.service';
import { TraceabilityController } from './traceability.controller';
import { TraceabilityService } from './traceability.service';

@Module({
  imports: [AuditModule, NotificationsModule, OperatorsModule, ParametersModule, ScopeModule],
  controllers: [PublicLotsController, TraceabilityController],
  providers: [QrCodeService, TraceabilityService],
  exports: [QrCodeService, TraceabilityService],
})
export class TraceabilityModule {}