import { randomUUID } from 'node:crypto';
import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigurationStatus, LotEventType, LotStatus, Prisma, RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { FormulaEngine } from '../parameters/formula-engine';
import { OperatorsService } from '../operators/operators.service';
import { NotificationsService } from '../notifications/notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { ReceiveLotDto } from './dto/receive-lot.dto';
import { TraceabilitySearchDto } from './dto/traceability-search.dto';
import { VerifyTransferDto } from './dto/verify-transfer.dto';

@Injectable()
export class TraceabilityService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly operators: OperatorsService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationsService,
    private readonly formulas: FormulaEngine,
  ) {}

  async detail(lotId: string, user: AuthenticatedUser) {
    const operatorOnly = user.roles.includes(RoleCode.OPERATEUR);
    const where: Prisma.LotWhereInput = {
      id: lotId,
      ...(operatorOnly ? {} : { batch: { farm: await this.scopes.farmWhere(user) } }),
    };
    if (operatorOnly) where.operator = { assignments: { some: { userId: user.id } } };
    const lot = await this.prisma.lot.findFirst({
      where,
      include: {
        batch: { include: { farm: { include: { locality: true } } } },
        operator: true,
        events: { orderBy: { occurredAt: 'asc' } },
        treatments: { orderBy: { startedAt: 'asc' } },
        outflow: { include: { sale: true } },
        qrCode: true,
      },
    });
    if (!lot) throw new NotFoundException('Lot introuvable.');
    const timeline = [
      ...lot.events.map((event) => ({ type: event.eventType, occurredAt: event.occurredAt, details: event.details, verified: event.verified })),
      ...lot.treatments.map((treatment) => ({ type: 'TREATMENT' as const, occurredAt: treatment.startedAt, details: { product: treatment.product, reason: treatment.reason }, verified: false })),
    ].sort((a, b) => a.occurredAt.getTime() - b.occurredAt.getTime());
    return { ...lot, timeline };
  }

  async verifyTransfer(lotId: string, input: VerifyTransferDto, user: AuthenticatedUser) {
    if (!user.roles.some((role) => role === RoleCode.ELEVEUR || role === RoleCode.AGENT_TECHNIQUE || role === RoleCode.POUFA_DGE)) {
      throw new ForbiddenException('Role non habilite a verifier une cession.');
    }
    const lot = await this.prisma.lot.findFirst({
      where: { id: lotId, batch: { farm: await this.scopes.farmWhere(user) } },
      include: { outflow: { select: { id: true, reference: true } } },
    });
    if (!lot) throw new NotFoundException('Lot introuvable.');
    if (!lot.outflow || (input.reference !== lot.outflow.id && input.reference !== lot.outflow.reference)) {
      throw new BadRequestException('La reference de cession ne correspond pas a la sortie du lot.');
    }
    const duplicate = await this.prisma.lotEvent.findUnique({ where: { clientUuid: input.clientUuid } });
    if (duplicate) {
      if (duplicate.lotId !== lotId || duplicate.eventType !== LotEventType.TRANSFER_VERIFIED) {
        throw new ConflictException('UUID client deja utilise pour un autre evenement.');
      }
      return duplicate;
    }
    const event = await this.prisma.lotEvent.create({
      data: {
        clientUuid: input.clientUuid,
        lotId,
        eventType: LotEventType.TRANSFER_VERIFIED,
        occurredAt: new Date(input.occurredAt),
        details: { reference: input.reference ?? null },
        recordedById: user.id,
        verified: true,
        verifiedById: user.id,
        verifiedAt: new Date(),
      },
    });
    await this.audit.record({ actorId: user.id, action: 'VERIFY_TRANSFER', entityType: 'LotEvent', entityId: event.id, after: event });
    return event;
  }

  async receiveAtOperator(lotId: string, input: ReceiveLotDto, user: AuthenticatedUser) {
    if (!user.roles.includes(RoleCode.OPERATEUR)) throw new ForbiddenException('Action reservee au compte OPERATEUR.');
    await this.operators.assertCanReceive(user.id, input.operatorId);
    const lot = await this.prisma.lot.findUnique({ where: { id: lotId }, include: { outflow: true } });
    if (!lot || lot.operatorId !== input.operatorId) throw new NotFoundException('Lot destine a cet operateur introuvable.');
    if (lot.status !== LotStatus.OPEN) throw new ConflictException('Le lot est deja clos.');
    const existing = await this.prisma.lotReception.findUnique({
      where: { clientUuid: input.clientUuid },
      include: { lotEvent: { select: { lotId: true } } },
    });
    if (existing) {
      if (existing.operatorId !== input.operatorId || existing.lotEvent.lotId !== lotId) throw new ConflictException('UUID client deja utilise pour une autre reception.');
      return existing;
    }
    const threshold = await this.prisma.threshold.findFirst({
      where: { key: 'traceability.reception_variance_rate', status: ConfigurationStatus.APPROVED },
      orderBy: { version: 'desc' },
    });
    const difference = input.receivedQuantity - lot.quantity;
    const discrepancyPercent = lot.quantity === 0 ? 0 : (difference / lot.quantity) * 100;
    const thresholdPercent = threshold?.value.toNumber() ?? null;
    const discrepancyFlagged = thresholdPercent !== null && Math.abs(discrepancyPercent) > thresholdPercent;
    const receivedAt = input.receivedAt ? new Date(input.receivedAt) : new Date();
    if (receivedAt > new Date()) throw new BadRequestException('La date de reception ne peut pas etre future.');
    const reception = await this.prisma.$transaction(async (transaction) => {
      await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`lot:${lotId}`}))`;
      const current = await transaction.lot.findUnique({ where: { id: lotId } });
      if (!current || current.status !== LotStatus.OPEN) throw new ConflictException('Le lot est deja clos.');
      const event = await transaction.lotEvent.create({
        data: {
          clientUuid: input.clientUuid,
          lotId,
          eventType: LotEventType.RECEIVED,
          occurredAt: receivedAt,
          location: 'Abattoir',
          details: { announcedQuantity: lot.quantity, receivedQuantity: input.receivedQuantity, discrepancyPercent },
          recordedById: user.id,
          verified: true,
          verifiedById: user.id,
          verifiedAt: new Date(),
        },
      });
      const result = await transaction.lotReception.create({
        data: {
          clientUuid: input.clientUuid,
          lotEventId: event.id,
          operatorId: input.operatorId,
          announcedQuantity: lot.quantity,
          receivedQuantity: input.receivedQuantity,
          discrepancyPercent: new Prisma.Decimal(discrepancyPercent),
          thresholdPercent: thresholdPercent === null ? undefined : new Prisma.Decimal(thresholdPercent),
          discrepancyFlagged,
          receivedAt,
          receivedById: user.id,
        },
      });
      await transaction.lot.update({ where: { id: lotId }, data: { status: LotStatus.CLOSED } });
      if (lot.outflowId) {
        await transaction.lotEvent.create({
          data: {
            clientUuid: randomUUID(),
            lotId,
            eventType: LotEventType.TRANSFER_VERIFIED,
            occurredAt: receivedAt,
            details: { receptionId: result.id, operatorId: input.operatorId },
            recordedById: user.id,
            verified: true,
            verifiedById: user.id,
            verifiedAt: new Date(),
          },
        });
      }
      await transaction.qrCode.updateMany({ where: { lotId }, data: { active: false, closedAt: receivedAt } });
      return result;
    });
    if (discrepancyFlagged) {
      const dgeUsers = await this.prisma.user.findMany({ where: { status: 'ACTIVE', roles: { some: { role: { code: RoleCode.POUFA_DGE } } } }, select: { id: true } });
      await Promise.all(dgeUsers.map(({ id }) => this.notifications.notify({
        userId: id,
        category: 'TRACEABILITY_DISCREPANCY',
        title: 'Ecart de reception abattoir',
        message: `Lot ${lot.code}: ecart de ${discrepancyPercent.toFixed(2)} %, seuil ${thresholdPercent} %.`,
        entityType: 'LotReception',
        entityId: reception.id,
      })));
    }
    await this.audit.record({ actorId: user.id, action: 'RECEIVE_LOT', entityType: 'LotReception', entityId: reception.id, after: reception });
    return { ...reception, discrepancyFlagged };
  }

  async search(query: TraceabilitySearchDto, user: AuthenticatedUser) {
    const operatorOnly = user.roles.includes(RoleCode.OPERATEUR);
    const farmWhere = operatorOnly ? undefined : await this.scopes.farmWhere(user, query.farmId);
    const where: Prisma.LotWhereInput = {
      batch: {
        ...(farmWhere ? { farm: farmWhere } : {}),
        ...(query.batchId ? { id: query.batchId } : {}),
      },
      ...(query.operatorId ? { operatorId: query.operatorId } : {}),
      ...(query.from || query.to ? { producedAt: { ...(query.from ? { gte: new Date(query.from) } : {}), ...(query.to ? { lte: new Date(query.to) } : {}) } } : {}),
    };
    if (user.roles.includes(RoleCode.OPERATEUR)) {
      where.operator = { assignments: { some: { userId: user.id } } };
    }
    return this.prisma.lot.findMany({
      where,
      include: {
        batch: { include: { farm: { include: { locality: true } } } },
        operator: { select: { code: true, name: true } },
        qrCode: { select: { active: true, createdAt: true } },
        events: { orderBy: { occurredAt: 'asc' } },
      },
      orderBy: { producedAt: 'desc' },
      take: 1000,
    });
  }

  async export(query: TraceabilitySearchDto, user: AuthenticatedUser, format: 'csv' | 'json') {
    const lots = await this.search(query, user);
    await this.audit.record({ actorId: user.id, action: 'EXPORT', entityType: 'Lot', entityId: 'traceability-search', metadata: { count: lots.length, format, query } });
    if (format === 'json') return lots;
    const columns = ['code', 'farmCode', 'farmName', 'locality', 'batchCode', 'operator', 'quantity', 'status', 'producedAt', 'qrActive'];
    const lines = lots.map((lot) => columns.map((column) => {
      const value = column === 'farmCode' ? lot.batch.farm.code
        : column === 'farmName' ? lot.batch.farm.name
          : column === 'locality' ? lot.batch.farm.locality.name
            : column === 'batchCode' ? lot.batch.code
              : column === 'operator' ? lot.operator?.name ?? ''
                : column === 'qrActive' ? lot.qrCode?.active ?? false
                  : lot[column as keyof typeof lot];
      return `"${String(value ?? '').replaceAll('"', '""')}"`;
    }).join(','));
    return [columns.join(','), ...lines].join('\n');
  }

  async indicators(user: AuthenticatedUser) {
    const farmWhere = await this.scopes.farmWhere(user);
    const [lots, sales, targetParameter, saleFormula, qrFormula] = await Promise.all([
      this.prisma.lot.findMany({ where: { batch: { farm: farmWhere } }, select: { id: true, qrCode: { select: { id: true } } } }),
      this.prisma.sale.findMany({ where: { batch: { farm: farmWhere } }, select: { id: true, outflowId: true, outflow: { select: { lots: { select: { id: true } } } } } }),
      this.prisma.parameter.findFirst({ where: { key: 'traceability.coverage_target', status: ConfigurationStatus.APPROVED }, orderBy: { version: 'desc' } }),
      this.prisma.formula.findFirst({ where: { key: 'sale_traceability_rate', status: ConfigurationStatus.APPROVED }, orderBy: { version: 'desc' } }),
      this.prisma.formula.findFirst({ where: { key: 'lot_qr_coverage_rate', status: ConfigurationStatus.APPROVED }, orderBy: { version: 'desc' } }),
    ]);
    const salesLinked = sales.filter((sale) => sale.outflowId !== null && sale.outflow?.lots.length).length;
    const lotsWithQr = lots.filter((lot) => lot.qrCode !== null).length;
    const saleRate = sales.length && saleFormula
      ? this.formulas.evaluate(saleFormula.expression, saleFormula.variables as string[], { linked_sales: salesLinked, total_sales: sales.length })
      : null;
    const qrRate = lots.length && qrFormula
      ? this.formulas.evaluate(qrFormula.expression, qrFormula.variables as string[], { lots_with_qr: lotsWithQr, total_lots: lots.length })
      : null;
    const target = targetParameter ? Number(targetParameter.value) : null;
    return {
      totalLots: lots.length,
      lotsWithQr,
      qrCoveragePercent: qrRate,
      totalSales: sales.length,
      salesLinkedToLots: salesLinked,
      salesTraceabilityPercent: saleRate,
      targetPercent: target,
      meetsTarget: target !== null && saleRate !== null && qrRate !== null && saleRate >= target && qrRate >= target,
    };
  }
}