import { createHash } from 'node:crypto';
import { Injectable, NotFoundException } from '@nestjs/common';
import { LotStatus } from '@prisma/client';
import QRCode from 'qrcode';
import { PrismaService } from '../prisma/prisma.service';

export type QrFormat = 'png' | 'svg';

@Injectable()
export class QrCodeService {
  constructor(private readonly prisma: PrismaService) {}

  async getOrCreate(lotId: string) {
    const lot = await this.prisma.lot.findUnique({ where: { id: lotId }, select: { id: true, code: true } });
    if (!lot) throw new NotFoundException('Lot introuvable.');
    return this.prisma.qrCode.upsert({
      where: { lotId },
      update: {},
      create: { lotId },
      include: { lot: { select: { code: true } } },
    });
  }

  async render(lotId: string, format: QrFormat): Promise<{ contentType: string; body: string | Buffer; publicUrl: string }> {
    const qr = await this.getOrCreate(lotId);
    const apiBase = (process.env.PUBLIC_API_URL ?? 'http://localhost:3000/api').replace(/\/$/, '');
    const publicUrl = `${apiBase}/public/lots/${encodeURIComponent(qr.lot.code)}`;
    if (format === 'svg') {
      return { contentType: 'image/svg+xml', body: await QRCode.toString(publicUrl, { type: 'svg', errorCorrectionLevel: 'M' }), publicUrl };
    }
    return { contentType: 'image/png', body: await QRCode.toBuffer(publicUrl, { type: 'png', errorCorrectionLevel: 'M' }), publicUrl };
  }

  async getPublicLot(code: string, ip: string | undefined, userAgent: string | undefined) {
    const qr = await this.prisma.qrCode.findFirst({
      where: { lot: { code } },
      include: {
        lot: {
          include: {
            batch: {
              include: {
                farm: { include: { locality: { select: { name: true } } } },
              },
            },
            events: { orderBy: { occurredAt: 'asc' }, select: { eventType: true, occurredAt: true } },
          },
        },
      },
    });
    const isClosed = qr?.closedAt !== null || qr?.lot.status === LotStatus.CLOSED;
    const outcome = !qr ? 'UNKNOWN' : !qr.active || isClosed ? 'CLOSED' : 'OK';
    await this.prisma.scanLog.create({
      data: {
        qrCodeId: qr?.id,
        submittedToken: code.slice(0, 100),
        ipHash: ip ? createHash('sha256').update(ip).digest('hex') : undefined,
        userAgent: userAgent?.slice(0, 300),
        outcome,
      },
    });
    if (outcome !== 'OK' || !qr) throw new NotFoundException('QR inconnu ou lot cloture.');
    return {
      code: qr.lot.code,
      producer: qr.lot.batch.farm.name,
      locality: qr.lot.batch.farm.locality.name,
      producedAt: qr.lot.producedAt.toISOString(),
      events: qr.lot.events.map((event) => ({ type: event.eventType, date: event.occurredAt.toISOString() })),
      status: qr.lot.status,
      notice: "Ce QR code n'est pas un certificat sanitaire.",
    };
  }
}