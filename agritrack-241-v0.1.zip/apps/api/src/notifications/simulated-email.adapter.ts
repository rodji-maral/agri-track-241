import { Injectable, Logger } from '@nestjs/common';
import { NotificationDelivery, NotificationMessage } from './notification-delivery';

@Injectable()
export class SimulatedEmailAdapter implements NotificationDelivery {
  private readonly logger = new Logger(SimulatedEmailAdapter.name);

  async send(message: NotificationMessage): Promise<void> {
    this.logger.log(`Email simule vers ${message.recipient}: ${message.subject}`);
  }
}