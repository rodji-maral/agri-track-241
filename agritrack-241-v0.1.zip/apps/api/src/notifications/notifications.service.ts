import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { NOTIFICATION_DELIVERY, NotificationDelivery } from './notification-delivery';

export interface CreateNotificationInput {
  userId: string;
  category: string;
  title: string;
  message: string;
  entityType?: string;
  entityId?: string;
}

@Injectable()
export class NotificationsService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(NOTIFICATION_DELIVERY) private readonly delivery: NotificationDelivery,
  ) {}

  async notify(input: CreateNotificationInput) {
    const notification = await this.prisma.notification.create({ data: input });
    const user = await this.prisma.user.findUnique({ where: { id: input.userId }, select: { email: true } });
    if (user) {
      try {
        await this.delivery.send({ recipient: user.email, subject: input.title, body: input.message });
        return this.prisma.notification.update({ where: { id: notification.id }, data: { deliveryStatus: 'SIMULATED' } });
      } catch {
        return this.prisma.notification.update({ where: { id: notification.id }, data: { deliveryStatus: 'FAILED' } });
      }
    }
    return notification;
  }

  list(userId: string, unreadOnly = false) {
    return this.prisma.notification.findMany({
      where: { userId, ...(unreadOnly ? { readAt: null } : {}) },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }

  async markRead(userId: string, id: string) {
    const notification = await this.prisma.notification.findFirst({ where: { id, userId } });
    if (!notification) throw new NotFoundException('Notification introuvable.');
    if (notification.readAt) return notification;
    return this.prisma.notification.update({ where: { id }, data: { readAt: new Date() } });
  }
}