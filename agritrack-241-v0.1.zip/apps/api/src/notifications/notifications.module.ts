import { Module } from '@nestjs/common';
import { NotificationsController } from './notifications.controller';
import { NOTIFICATION_DELIVERY } from './notification-delivery';
import { NotificationsService } from './notifications.service';
import { SimulatedEmailAdapter } from './simulated-email.adapter';

@Module({
  controllers: [NotificationsController],
  providers: [
    NotificationsService,
    SimulatedEmailAdapter,
    { provide: NOTIFICATION_DELIVERY, useExisting: SimulatedEmailAdapter },
  ],
  exports: [NotificationsService],
})
export class NotificationsModule {}