export interface NotificationMessage {
  recipient: string;
  subject: string;
  body: string;
}

export interface NotificationDelivery {
  send(message: NotificationMessage): Promise<void>;
}

export const NOTIFICATION_DELIVERY = Symbol('NOTIFICATION_DELIVERY');
