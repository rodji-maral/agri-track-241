import { Body, Controller, Get, Param, Post, Put } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { DeclarationStatus, PermissionAction, RoleCode } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { Roles } from '../auth/roles.decorator';
import { CreateHealthDeclarationDto } from './dto/create-health-declaration.dto';
import { CreateTreatmentDto } from './dto/create-treatment.dto';
import { CreateVaccinationDto } from './dto/create-vaccination.dto';
import { CreateVetInterventionDto } from './dto/create-vet-intervention.dto';
import { ReviewHealthDeclarationDto } from './dto/review-health-declaration.dto';
import { HealthService } from './health.service';

@ApiTags('Sante animale')
@ApiBearerAuth()
@Controller('health')
export class HealthController {
  constructor(private readonly health: HealthService) {}

  @Post('declarations')
  @Permissions('health', PermissionAction.CREATE)
  createDeclaration(@Body() body: CreateHealthDeclarationDto, @CurrentUser() user: AuthenticatedUser) {
    return this.health.createDeclaration(body, user);
  }

  @Get('declarations')
  @Roles(RoleCode.VETERINAIRE)
  @Permissions('health', PermissionAction.CONSULT)
  listDeclarations(@CurrentUser() user: AuthenticatedUser) {
    return this.health.listDeclarations(user);
  }

  @Put('declarations/:id/review')
  @Roles(RoleCode.VETERINAIRE)
  @Permissions('health', PermissionAction.VALIDATE)
  reviewDeclaration(@Param('id') id: string, @Body() body: ReviewHealthDeclarationDto, @CurrentUser() user: AuthenticatedUser) {
    return this.health.reviewDeclaration(id, body.status as DeclarationStatus, user);
  }

  @Get('batches/:batchId/vaccination-calendar')
  @Permissions('health', PermissionAction.CONSULT)
  vaccinationCalendar(@Param('batchId') batchId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.health.vaccinationCalendar(batchId, user);
  }

  @Get('batches/:batchId/vaccinations')
  @Permissions('health', PermissionAction.CONSULT)
  listVaccinations(@Param('batchId') batchId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.health.listVaccinations(batchId, user);
  }

  @Post('batches/:batchId/vaccinations')
  @Permissions('health', PermissionAction.CREATE)
  createVaccination(@Param('batchId') batchId: string, @Body() body: CreateVaccinationDto, @CurrentUser() user: AuthenticatedUser) {
    return this.health.createVaccination(batchId, body, user);
  }

  @Get('batches/:batchId/treatments')
  @Permissions('health', PermissionAction.CONSULT)
  listTreatments(@Param('batchId') batchId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.health.listTreatments(batchId, user);
  }

  @Post('batches/:batchId/treatments')
  @Permissions('health', PermissionAction.CREATE)
  createTreatment(@Param('batchId') batchId: string, @Body() body: CreateTreatmentDto, @CurrentUser() user: AuthenticatedUser) {
    return this.health.createTreatment(batchId, body, user);
  }

  @Get('interventions')
  @Roles(RoleCode.VETERINAIRE)
  @Permissions('health', PermissionAction.CONSULT)
  listInterventions(@CurrentUser() user: AuthenticatedUser) {
    return this.health.listInterventions(user);
  }

  @Post('interventions')
  @Roles(RoleCode.VETERINAIRE)
  @Permissions('health', PermissionAction.CREATE)
  createIntervention(@Body() body: CreateVetInterventionDto, @CurrentUser() user: AuthenticatedUser) {
    return this.health.createIntervention(body, user);
  }
}