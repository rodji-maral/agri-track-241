import { IsDateString, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';

export class CreateTreatmentDto {
  @IsUUID()
  clientUuid!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  lotId?: string;

  @IsString()
  @MaxLength(160)
  product!: string;

  @IsString()
  @MaxLength(500)
  reason!: string;

  @IsDateString()
  startedAt!: string;

  @IsOptional()
  @IsDateString()
  endedAt?: string;

  @IsOptional()
  @IsString()
  @MaxLength(160)
  dosage?: string;

  @IsOptional()
  @IsDateString()
  withdrawalEndsAt?: string;
}