import { IsDateString, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';

export class CreateVetInterventionDto {
  @IsUUID()
  clientUuid!: string;

  @IsString()
  @MaxLength(100)
  farmId!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  batchId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  declarationId?: string;

  @IsDateString()
  visitedAt!: string;

  @IsString()
  @MaxLength(3000)
  findings!: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  diagnosis?: string;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  recommendations?: string;
}