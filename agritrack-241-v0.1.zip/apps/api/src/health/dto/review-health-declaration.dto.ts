import { DeclarationStatus } from '@prisma/client';
import { IsEnum } from 'class-validator';

export class ReviewHealthDeclarationDto {
  @IsEnum(DeclarationStatus)
  status!: DeclarationStatus;
}