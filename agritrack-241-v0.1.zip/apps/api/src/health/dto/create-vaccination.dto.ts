import { IsDateString, IsNumber, IsOptional, IsString, IsUUID, MaxLength, Min } from 'class-validator';

export class CreateVaccinationDto {
  @IsUUID()
  clientUuid!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  calendarId?: string;

  @IsString()
  @MaxLength(160)
  vaccine!: string;

  @IsDateString()
  administeredAt!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  dose?: string;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0)
  quantity?: number;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  batchNumber?: string;
}