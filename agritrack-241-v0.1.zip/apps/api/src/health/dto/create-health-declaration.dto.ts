import { IsDateString, IsInt, IsOptional, IsString, IsUUID, MaxLength, Min } from 'class-validator';

export class CreateHealthDeclarationDto {
  @IsUUID()
  clientUuid!: string;

  @IsString()
  @MaxLength(100)
  farmId!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  batchId?: string;

  @IsString()
  @MaxLength(3000)
  symptoms!: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  suspectedCondition?: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  affectedCount?: number;

  @IsDateString()
  declaredAt!: string;
}