import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { BatchesModule } from '../batches/batches.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { ScopeModule } from '../scopes/scope.module';
import { HealthController } from './health.controller';
import { HealthService } from './health.service';

@Module({
  imports: [AuditModule, BatchesModule, NotificationsModule, ScopeModule],
  controllers: [HealthController],
  providers: [HealthService],
  exports: [HealthService],
})
export class HealthModule {}