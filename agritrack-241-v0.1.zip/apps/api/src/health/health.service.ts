import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { DeclarationStatus, Prisma, RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { BatchesService } from '../batches/batches.service';
import { NotificationsService } from '../notifications/notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { CreateHealthDeclarationDto } from './dto/create-health-declaration.dto';
import { CreateTreatmentDto } from './dto/create-treatment.dto';
import { CreateVaccinationDto } from './dto/create-vaccination.dto';
import { CreateVetInterventionDto } from './dto/create-vet-intervention.dto';

@Injectable()
export class HealthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly batches: BatchesService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationsService,
  ) {}

  async createDeclaration(input: CreateHealthDeclarationDto, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, input.farmId);
    if (input.batchId) {
      const batch = await this.prisma.batch.findFirst({ where: { id: input.batchId, farmId: input.farmId }, select: { id: true } });
      if (!batch) throw new BadRequestException('La bande n appartient pas a cette ferme.');
    }
    const duplicate = await this.prisma.healthDeclaration.findUnique({ where: { clientUuid: input.clientUuid } });
    if (duplicate) {
      if (duplicate.farmId !== input.farmId) throw new ConflictException('UUID client deja utilise pour une autre ferme.');
      if (duplicate.reportedById !== user.id) throw new ForbiddenException('Ce signalement ne vous appartient pas.');
      return { id: duplicate.id, status: duplicate.status, submittedAt: duplicate.createdAt };
    }
    const declaredAt = new Date(input.declaredAt);
    if (declaredAt > new Date()) throw new BadRequestException('La date du signalement ne peut pas etre future.');
    const declaration = await this.prisma.healthDeclaration.create({
      data: {
        clientUuid: input.clientUuid,
        farmId: input.farmId,
        batchId: input.batchId,
        symptoms: input.symptoms,
        suspectedCondition: input.suspectedCondition,
        affectedCount: input.affectedCount,
        declaredAt,
        reportedById: user.id,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE_PRIVATE_DECLARATION', entityType: 'HealthDeclaration', entityId: declaration.id, after: declaration });
    await this.notifyVeterinarians(input.farmId, declaration.id, 'Nouveau signalement sanitaire', 'Un signalement prive attend votre qualification.');
    return { id: declaration.id, status: declaration.status, submittedAt: declaration.createdAt };
  }

  async listDeclarations(user: AuthenticatedUser) {
    this.assertVeterinarian(user);
    return this.prisma.healthDeclaration.findMany({
      where: { farm: await this.scopes.farmWhere(user) },
      include: { farm: { select: { code: true, name: true, provinceCode: true } }, batch: { select: { code: true } } },
      orderBy: { declaredAt: 'desc' },
    });
  }

  async reviewDeclaration(id: string, status: DeclarationStatus, user: AuthenticatedUser) {
    this.assertVeterinarian(user);
    const current = await this.prisma.healthDeclaration.findFirst({ where: { id, farm: await this.scopes.farmWhere(user) } });
    if (!current) throw new NotFoundException('Signalement sanitaire introuvable.');
    const allowed = await this.prisma.listValue.findFirst({
      where: { listKey: 'health_declaration_transition', code: `${current.status}:${status}`, active: true },
      select: { id: true },
    });
    if (!allowed) throw new BadRequestException('Transition de signalement non autorisee par le parametrage.');
    const updated = await this.prisma.healthDeclaration.update({
      where: { id },
      data: { status, reviewedById: user.id, reviewedAt: new Date() },
    });
    await this.audit.record({ actorId: user.id, action: 'QUALIFY', entityType: 'HealthDeclaration', entityId: id, before: current, after: updated });
    return updated;
  }

  async vaccinationCalendar(batchId: string, user: AuthenticatedUser) {
    const batch = await this.batches.findOne(batchId, user);
    const calendars = await this.prisma.vaccinationCalendar.findMany({
      where: { OR: [{ provinceCode: null }, { provinceCode: batch.farm.provinceCode }] },
      orderBy: { ageDay: 'asc' },
    });
    const administered = await this.prisma.vaccination.findMany({ where: { batchId, calendarId: { not: null } } });
    const byCalendar = new Map(administered.map((entry) => [entry.calendarId!, entry]));
    const now = new Date();
    return calendars.map((entry) => {
      const dueAt = new Date(batch.placedAt.getTime() + (entry.ageDay - 1) * 86_400_000);
      const vaccination = byCalendar.get(entry.id);
      return { ...entry, dueAt, vaccination: vaccination ?? null, delayed: !vaccination && dueAt < now };
    });
  }

  async createVaccination(batchId: string, input: CreateVaccinationDto, user: AuthenticatedUser) {
    const batch = await this.batches.assertWritable(batchId, user);
    const existing = await this.prisma.vaccination.findUnique({ where: { clientUuid: input.clientUuid } });
    if (existing) {
      if (existing.batchId !== batchId) throw new ConflictException('UUID client deja utilise pour une autre bande.');
      return existing;
    }
    if (new Date(input.administeredAt) < batch.placedAt || new Date(input.administeredAt) > new Date()) {
      throw new BadRequestException('La date de vaccination est invalide.');
    }
    if (input.calendarId && !await this.prisma.vaccinationCalendar.findUnique({ where: { id: input.calendarId } })) {
      throw new BadRequestException('Entree de calendrier vaccinal introuvable.');
    }
    const vaccination = await this.prisma.vaccination.create({
      data: {
        clientUuid: input.clientUuid,
        batchId,
        calendarId: input.calendarId,
        vaccine: input.vaccine,
        administeredAt: new Date(input.administeredAt),
        dose: input.dose,
        quantity: input.quantity === undefined ? undefined : new Prisma.Decimal(input.quantity),
        batchNumber: input.batchNumber,
        administeredBy: user.id,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'Vaccination', entityId: vaccination.id, after: vaccination });
    return vaccination;
  }

  async listVaccinations(batchId: string, user: AuthenticatedUser) {
    await this.batches.findOne(batchId, user);
    return this.prisma.vaccination.findMany({
      where: { batchId },
      include: { calendar: true },
      orderBy: { administeredAt: 'desc' },
    });
  }

  async listTreatments(batchId: string, user: AuthenticatedUser) {
    await this.batches.findOne(batchId, user);
    return this.prisma.treatment.findMany({ where: { batchId }, include: { lot: { select: { code: true } } }, orderBy: { startedAt: 'desc' } });
  }

  async createTreatment(batchId: string, input: CreateTreatmentDto, user: AuthenticatedUser) {
    await this.batches.assertWritable(batchId, user);
    const existing = await this.prisma.treatment.findUnique({ where: { clientUuid: input.clientUuid } });
    if (existing) {
      if (existing.batchId !== batchId) throw new ConflictException('UUID client deja utilise pour une autre bande.');
      return existing;
    }
    if (input.lotId) {
      const lot = await this.prisma.lot.findFirst({ where: { id: input.lotId, batchId }, select: { id: true } });
      if (!lot) throw new BadRequestException('Le lot ne correspond pas a cette bande.');
    }
    const treatment = await this.prisma.treatment.create({
      data: {
        clientUuid: input.clientUuid,
        batchId,
        lotId: input.lotId,
        product: input.product,
        reason: input.reason,
        startedAt: new Date(input.startedAt),
        endedAt: input.endedAt ? new Date(input.endedAt) : undefined,
        dosage: input.dosage,
        withdrawalEndsAt: input.withdrawalEndsAt ? new Date(input.withdrawalEndsAt) : undefined,
        recordedById: user.id,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'Treatment', entityId: treatment.id, after: treatment });
    return treatment;
  }

  async createIntervention(input: CreateVetInterventionDto, user: AuthenticatedUser) {
    this.assertVeterinarian(user);
    await this.scopes.assertFarmAccess(user, input.farmId);
    if (input.batchId) {
      const batch = await this.prisma.batch.findFirst({ where: { id: input.batchId, farmId: input.farmId }, select: { id: true } });
      if (!batch) throw new BadRequestException('La bande n appartient pas a cette ferme.');
    }
    if (input.declarationId && !await this.prisma.healthDeclaration.findFirst({
      where: { id: input.declarationId, farmId: input.farmId },
      select: { id: true },
    })) {
      throw new BadRequestException('Le signalement ne correspond pas a cette ferme.');
    }
    const existing = await this.prisma.vetIntervention.findUnique({ where: { clientUuid: input.clientUuid } });
    if (existing) {
      if (existing.farmId !== input.farmId) throw new ConflictException('UUID client deja utilise pour une autre ferme.');
      return existing;
    }
    const intervention = await this.prisma.vetIntervention.create({
      data: {
        clientUuid: input.clientUuid,
        farmId: input.farmId,
        batchId: input.batchId,
        declarationId: input.declarationId,
        vetId: user.id,
        visitedAt: new Date(input.visitedAt),
        findings: input.findings,
        diagnosis: input.diagnosis,
        recommendations: input.recommendations,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE_VETERINARY_INTERVENTION', entityType: 'VetIntervention', entityId: intervention.id, after: intervention });
    return intervention;
  }

  async listInterventions(user: AuthenticatedUser) {
    this.assertVeterinarian(user);
    return this.prisma.vetIntervention.findMany({
      where: { farm: await this.scopes.farmWhere(user) },
      include: { farm: { select: { code: true, name: true } }, batch: { select: { code: true } } },
      orderBy: { visitedAt: 'desc' },
    });
  }

  private assertVeterinarian(user: AuthenticatedUser): void {
    if (!user.roles.includes(RoleCode.VETERINAIRE)) throw new ForbiddenException('Action reservee au role VETERINAIRE.');
  }

  private async notifyVeterinarians(farmId: string, declarationId: string, title: string, message: string): Promise<void> {
    const farm = await this.prisma.farm.findUnique({ where: { id: farmId }, select: { provinceCode: true } });
    if (!farm) throw new NotFoundException('Ferme introuvable.');
    const recipients = await this.prisma.user.findMany({
      where: {
        status: 'ACTIVE',
        roles: { some: { role: { code: RoleCode.VETERINAIRE } } },
        scopes: { some: { OR: [{ farmId }, { provinceCode: farm.provinceCode }] } },
      },
      select: { id: true },
    });
    await Promise.all(recipients.map(({ id }) => this.notifications.notify({
      userId: id,
      category: 'HEALTH_DECLARATION',
      title,
      message,
      entityType: 'HealthDeclaration',
      entityId: declarationId,
    })));
  }
}