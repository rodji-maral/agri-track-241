import { ForbiddenException } from '@nestjs/common';
import { RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { PrismaService } from '../prisma/prisma.service';
import { FormulaEngine } from './formula-engine';
import { ParametersService } from './parameters.service';

describe('ParametersService sanitary threshold authorization', () => {
  it('denies an ELEVEUR from changing a health threshold', async () => {
    const findFirst = jest.fn();
    const service = new ParametersService(
      { threshold: { findFirst } } as unknown as PrismaService,
      {} as AuditService,
      new FormulaEngine(),
    );

    await expect(service.createThreshold({ key: 'health.daily_mortality_rate', value: 5 }, {
      id: 'farmer-1',
      email: 'farmer@test.ga',
      roles: [RoleCode.ELEVEUR],
    })).rejects.toBeInstanceOf(ForbiddenException);
    expect(findFirst).not.toHaveBeenCalled();
  });
});