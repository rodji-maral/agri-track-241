import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import {
  ConfigurationStatus,
  ParameterValueType,
  Prisma,
  RoleCode,
} from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { PrismaService } from '../prisma/prisma.service';
import { CreateFormulaDto } from './dto/create-formula.dto';
import { CreateListValueDto } from './dto/create-list-value.dto';
import { CreateParameterDto } from './dto/create-parameter.dto';
import { CreateThresholdDto } from './dto/create-threshold.dto';
import { FormulaEngine } from './formula-engine';

@Injectable()
export class ParametersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly formulaEngine: FormulaEngine,
  ) {}

  listParameters(key?: string) {
    return this.prisma.parameter.findMany({ where: key ? { key } : {}, orderBy: [{ key: 'asc' }, { version: 'desc' }] });
  }

  async createParameter(input: CreateParameterDto, user: AuthenticatedUser) {
    this.validateParameterValue(input.valueType, input.value);
    const previous = await this.prisma.parameter.findFirst({ where: { key: input.key }, orderBy: { version: 'desc' } });
    const created = await this.prisma.parameter.create({
      data: {
        ...input,
        value: input.value as Prisma.InputJsonValue,
        version: (previous?.version ?? 0) + 1,
        status: ConfigurationStatus.PROPOSED,
        createdById: user.id,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE_VERSION', entityType: 'Parameter', entityId: created.id, after: created });
    return created;
  }

  listFormulas(key?: string) {
    return this.prisma.formula.findMany({ where: key ? { key } : {}, orderBy: [{ key: 'asc' }, { version: 'desc' }] });
  }

  async createFormula(input: CreateFormulaDto, user: AuthenticatedUser) {
    this.formulaEngine.validate(input.expression, input.variables);
    const previous = await this.prisma.formula.findFirst({ where: { key: input.key }, orderBy: { version: 'desc' } });
    const created = await this.prisma.formula.create({
      data: {
        ...input,
        variables: input.variables,
        version: (previous?.version ?? 0) + 1,
        status: ConfigurationStatus.PROPOSED,
        createdById: user.id,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE_VERSION', entityType: 'Formula', entityId: created.id, after: created });
    return created;
  }

  async evaluateFormula(key: string, version: number | undefined, values: Record<string, number>) {
    const formula = await this.prisma.formula.findFirst({
      where: {
        key,
        status: ConfigurationStatus.APPROVED,
        ...(version ? { version } : {}),
      },
      orderBy: { version: 'desc' },
    });
    if (!formula) throw new NotFoundException('Aucune formule approuvee correspondante.');
    return this.formulaEngine.evaluate(formula.expression, formula.variables as string[], values);
  }

  listThresholds(key?: string) {
    return this.prisma.threshold.findMany({ where: key ? { key } : {}, orderBy: [{ key: 'asc' }, { version: 'desc' }] });
  }

  async createThreshold(input: CreateThresholdDto, user: AuthenticatedUser) {
    this.assertVeterinarianForHealthThreshold(input.key, user);
    const previous = await this.prisma.threshold.findFirst({ where: { key: input.key }, orderBy: { version: 'desc' } });
    const created = await this.prisma.threshold.create({
      data: {
        ...input,
        value: new Prisma.Decimal(input.value),
        veterinarianOnly: input.key.startsWith('health.'),
        version: (previous?.version ?? 0) + 1,
        status: ConfigurationStatus.PROPOSED,
        createdById: user.id,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE_VERSION', entityType: 'Threshold', entityId: created.id, after: created });
    return created;
  }

  listValues(listKey?: string) {
    return this.prisma.listValue.findMany({ where: listKey ? { listKey } : {}, orderBy: [{ listKey: 'asc' }, { sortOrder: 'asc' }, { version: 'desc' }] });
  }

  async createListValue(input: CreateListValueDto, user: AuthenticatedUser) {
    const previous = await this.prisma.listValue.findFirst({
      where: { listKey: input.listKey, code: input.code },
      orderBy: { version: 'desc' },
    });
    const created = await this.prisma.listValue.create({
      data: {
        ...input,
        metadata: (input.metadata ?? {}) as Prisma.InputJsonValue,
        version: (previous?.version ?? 0) + 1,
        active: input.active ?? true,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE_VERSION', entityType: 'ListValue', entityId: created.id, after: created });
    return created;
  }

  async approve(kind: 'parameter' | 'formula' | 'threshold', id: string, user: AuthenticatedUser) {
    const approval = { status: ConfigurationStatus.APPROVED, approvedById: user.id, effectiveAt: new Date() };
    if (kind === 'parameter') {
      const current = await this.prisma.parameter.findUnique({ where: { id } });
      this.assertProposed(current);
      const updated = await this.prisma.parameter.update({ where: { id }, data: approval });
      await this.audit.record({ actorId: user.id, action: 'APPROVE', entityType: kind, entityId: id, before: current, after: updated });
      return updated;
    }
    if (kind === 'formula') {
      const current = await this.prisma.formula.findUnique({ where: { id } });
      this.assertProposed(current);
      const updated = await this.prisma.formula.update({ where: { id }, data: approval });
      await this.audit.record({ actorId: user.id, action: 'APPROVE', entityType: kind, entityId: id, before: current, after: updated });
      return updated;
    }
    const current = await this.prisma.threshold.findUnique({ where: { id } });
    this.assertProposed(current);
    this.assertVeterinarianForHealthThreshold(current.key, user);
    const updated = await this.prisma.threshold.update({ where: { id }, data: approval });
    await this.audit.record({ actorId: user.id, action: 'APPROVE', entityType: kind, entityId: id, before: current, after: updated });
    return updated;
  }

  private validateParameterValue(type: ParameterValueType, value: unknown): void {
    const valid = type === ParameterValueType.STRING
      ? typeof value === 'string'
      : type === ParameterValueType.NUMBER
        ? typeof value === 'number' && Number.isFinite(value)
        : type === ParameterValueType.BOOLEAN
          ? typeof value === 'boolean'
          : value === null || typeof value === 'object';
    if (!valid) throw new BadRequestException(`La valeur ne correspond pas au type ${type}.`);
    try {
      JSON.stringify(value);
    } catch {
      throw new BadRequestException('La valeur doit etre serialisable en JSON.');
    }
  }

  private assertVeterinarianForHealthThreshold(key: string, user: AuthenticatedUser): void {
    if (key.startsWith('health.') && !user.roles.includes(RoleCode.VETERINAIRE)) {
      throw new ForbiddenException('Seul le role VETERINAIRE peut modifier un seuil sanitaire.');
    }
  }

  private assertProposed<T extends { status: ConfigurationStatus }>(record: T | null): asserts record is T {
    if (!record) throw new NotFoundException('Version de configuration introuvable.');
    if (record.status !== ConfigurationStatus.PROPOSED) {
      throw new BadRequestException('Seule une version proposee peut etre validee.');
    }
  }
}
