import { BadRequestException, Injectable } from '@nestjs/common';
import { all, create, MathNode } from 'mathjs';

const restrictedMath = create(all, { number: 'number', precision: 64 });
const allowedOperators = new Set(['+', '-', '*', '/', '^', '%']);

@Injectable()
export class FormulaEngine {
  validate(expression: string, variables: readonly string[]): void {
    if (!expression.trim() || expression.length > 500) {
      throw new BadRequestException('Expression vide ou trop longue.');
    }
    const declared = new Set(variables);
    if (declared.size !== variables.length || variables.some((name) => !/^[a-zA-Z][a-zA-Z0-9_]{0,63}$/.test(name))) {
      throw new BadRequestException('Liste de variables invalide ou dupliquee.');
    }
    let node: MathNode;
    try {
      node = restrictedMath.parse(expression);
    } catch {
      throw new BadRequestException('Expression mathematique invalide.');
    }
    node.traverse((child) => {
      if (child.type === 'OperatorNode') {
        const operator = child as MathNode & { op: string };
        if (!allowedOperators.has(operator.op)) throw new BadRequestException('Operateur interdit.');
        return;
      }
      if (child.type === 'ConstantNode') {
        const constant = child as MathNode & { value: unknown };
        if (typeof constant.value !== 'number' || !Number.isFinite(constant.value)) {
          throw new BadRequestException('Seules les constantes numeriques sont autorisees.');
        }
        return;
      }
      if (child.type === 'SymbolNode') {
        const symbol = child as MathNode & { name: string };
        if (!declared.has(symbol.name)) throw new BadRequestException(`Variable non declaree: ${symbol.name}.`);
        return;
      }
      if (child.type !== 'ParenthesisNode') {
        throw new BadRequestException(`Type d'expression interdit: ${child.type}.`);
      }
    });
  }

  evaluate(expression: string, variables: readonly string[], values: Record<string, number>): number {
    this.validate(expression, variables);
    const scope: Record<string, number> = {};
    for (const name of variables) {
      const value = values[name];
      if (typeof value !== 'number' || !Number.isFinite(value)) {
        throw new BadRequestException(`Valeur numerique invalide pour ${name}.`);
      }
      scope[name] = value;
    }
    try {
      const result: unknown = restrictedMath.parse(expression).compile().evaluate(scope);
      if (typeof result !== 'number' || !Number.isFinite(result)) {
        throw new BadRequestException('Le resultat de la formule doit etre un nombre fini.');
      }
      return result;
    } catch (error) {
      if (error instanceof BadRequestException) throw error;
      throw new BadRequestException('Impossible d evaluer la formule.');
    }
  }
}
