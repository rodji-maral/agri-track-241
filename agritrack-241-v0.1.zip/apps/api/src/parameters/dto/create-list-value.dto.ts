import { IsBoolean, IsInt, IsObject, IsOptional, IsString, Matches, MaxLength, Min } from 'class-validator';

export class CreateListValueDto {
  @IsString()
  @Matches(/^[a-z][a-z0-9_.-]{1,99}$/)
  listKey!: string;

  @IsString()
  @Matches(/^[A-Z0-9_-]{1,64}$/)
  code!: string;

  @IsString()
  @MaxLength(120)
  label!: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  sortOrder?: number;

  @IsOptional()
  @IsBoolean()
  active?: boolean;

  @IsOptional()
  @IsObject()
  metadata?: Record<string, unknown>;
}
