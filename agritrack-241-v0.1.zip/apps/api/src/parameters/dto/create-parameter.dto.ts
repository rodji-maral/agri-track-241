import { IsDefined, IsEnum, IsOptional, IsString, Matches, MaxLength } from 'class-validator';
import { ParameterValueType } from '@prisma/client';

export class CreateParameterDto {
  @IsString()
  @Matches(/^[a-z][a-z0-9_.-]{1,99}$/)
  key!: string;

  @IsEnum(ParameterValueType)
  valueType!: ParameterValueType;

  @IsDefined()
  value!: unknown;

  @IsOptional()
  @IsString()
  @MaxLength(300)
  description?: string;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  unit?: string;
}
