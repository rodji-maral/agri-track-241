import { ArrayUnique, IsArray, IsOptional, IsString, Matches, MaxLength } from 'class-validator';

export class CreateFormulaDto {
  @IsString()
  @Matches(/^[a-z][a-z0-9_.-]{1,99}$/)
  key!: string;

  @IsString()
  @MaxLength(120)
  name!: string;

  @IsString()
  @MaxLength(500)
  expression!: string;

  @IsArray()
  @ArrayUnique()
  @IsString({ each: true })
  variables!: string[];

  @IsOptional()
  @IsString()
  @MaxLength(300)
  description?: string;
}
