import { ArrayUnique, IsArray, IsInt, IsNumber, IsObject, IsOptional, IsString, Matches, Min } from 'class-validator';

export class EvaluateFormulaDto {
  @IsString()
  @Matches(/^[a-z][a-z0-9_.-]{1,99}$/)
  key!: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  version?: number;

  @IsArray()
  @ArrayUnique()
  @IsString({ each: true })
  variables!: string[];

  @IsObject()
  @IsNumber({ allowNaN: false, allowInfinity: false }, { each: true })
  values!: Record<string, number>;
}