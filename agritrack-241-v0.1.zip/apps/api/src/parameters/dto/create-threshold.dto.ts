import { IsBoolean, IsNumber, IsOptional, IsString, Matches, MaxLength } from 'class-validator';

export class CreateThresholdDto {
  @IsString()
  @Matches(/^[a-z][a-z0-9_.-]{1,99}$/)
  key!: string;

  @IsNumber({ allowNaN: false, allowInfinity: false })
  value!: number;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  unit?: string;

  @IsOptional()
  @IsBoolean()
  veterinarianOnly?: boolean;

  @IsOptional()
  @IsString()
  @MaxLength(300)
  description?: string;
}
