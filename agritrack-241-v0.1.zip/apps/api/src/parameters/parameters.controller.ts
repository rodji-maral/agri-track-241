import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { CreateFormulaDto } from './dto/create-formula.dto';
import { CreateListValueDto } from './dto/create-list-value.dto';
import { CreateParameterDto } from './dto/create-parameter.dto';
import { CreateThresholdDto } from './dto/create-threshold.dto';
import { EvaluateFormulaDto } from './dto/evaluate-formula.dto';
import { ParametersService } from './parameters.service';

@ApiTags('Parametrage')
@ApiBearerAuth()
@Controller('configuration')
export class ParametersController {
  constructor(private readonly parameters: ParametersService) {}

  @Get('parameters')
  @Permissions('parameter', PermissionAction.CONSULT)
  listParameters(@Query('key') key?: string) {
    return this.parameters.listParameters(key);
  }

  @Post('parameters')
  @Permissions('parameter', PermissionAction.MODIFY)
  createParameter(@Body() body: CreateParameterDto, @CurrentUser() user: AuthenticatedUser) {
    return this.parameters.createParameter(body, user);
  }

  @Get('formulas')
  @Permissions('parameter', PermissionAction.CONSULT)
  listFormulas(@Query('key') key?: string) {
    return this.parameters.listFormulas(key);
  }

  @Post('formulas')
  @Permissions('parameter', PermissionAction.MODIFY)
  createFormula(@Body() body: CreateFormulaDto, @CurrentUser() user: AuthenticatedUser) {
    return this.parameters.createFormula(body, user);
  }

  @Post('formulas/evaluate')
  @Permissions('parameter', PermissionAction.CONSULT)
  async evaluateFormula(@Body() body: EvaluateFormulaDto) {
    return { result: await this.parameters.evaluateFormula(body.key, body.version, body.values) };
  }

  @Get('thresholds')
  @Permissions('parameter', PermissionAction.CONSULT)
  listThresholds(@Query('key') key?: string) {
    return this.parameters.listThresholds(key);
  }

  @Post('thresholds')
  @Permissions('parameter', PermissionAction.MODIFY)
  createThreshold(@Body() body: CreateThresholdDto, @CurrentUser() user: AuthenticatedUser) {
    return this.parameters.createThreshold(body, user);
  }

  @Get('lists')
  @Permissions('parameter', PermissionAction.CONSULT)
  listValues(@Query('key') key?: string) {
    return this.parameters.listValues(key);
  }

  @Post('lists')
  @Permissions('parameter', PermissionAction.MODIFY)
  createListValue(@Body() body: CreateListValueDto, @CurrentUser() user: AuthenticatedUser) {
    return this.parameters.createListValue(body, user);
  }

  @Post(':kind/:id/approve')
  @Permissions('parameter', PermissionAction.VALIDATE)
  approve(
    @Param('kind') kind: 'parameter' | 'formula' | 'threshold',
    @Param('id') id: string,
    @CurrentUser() user: AuthenticatedUser,
  ) {
    return this.parameters.approve(kind, id, user);
  }
}
