import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { ParametersController } from './parameters.controller';
import { FormulaEngine } from './formula-engine';
import { ParametersService } from './parameters.service';

@Module({
  imports: [AuditModule],
  controllers: [ParametersController],
  providers: [ParametersService, FormulaEngine],
  exports: [ParametersService, FormulaEngine],
})
export class ParametersModule {}