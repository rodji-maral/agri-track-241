import { BadRequestException } from '@nestjs/common';
import { FormulaEngine } from './formula-engine';

describe('FormulaEngine', () => {
  const engine = new FormulaEngine();

  it('calcule le GMQ en grammes par jour', () => {
    const result = engine.evaluate(
      '(current_average_weight - initial_weight) / age_days * 1000',
      ['current_average_weight', 'initial_weight', 'age_days'],
      { current_average_weight: 0.75, initial_weight: 0.05, age_days: 35 },
    );
    expect(result).toBe(20);
  });

  it('refuse les fonctions et symboles non declares', () => {
    expect(() => engine.evaluate('sqrt(weight)', ['weight'], { weight: 4 })).toThrow(BadRequestException);
    expect(() => engine.evaluate('weight + secret', ['weight'], { weight: 4, secret: 2 })).toThrow(BadRequestException);
  });

  it('refuse les valeurs non numeriques et les resultats infinis', () => {
    expect(() => engine.evaluate('weight / denominator', ['weight', 'denominator'], { weight: 10, denominator: 0 })).toThrow(BadRequestException);
    expect(() => engine.evaluate('weight', ['weight'], { weight: Number.NaN })).toThrow(BadRequestException);
  });
});