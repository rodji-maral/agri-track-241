import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { Request, Response } from 'express';

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const context = host.switchToHttp();
    const request = context.getRequest<Request>();
    const response = context.getResponse<Response>();
    const requestId = randomUUID();
    const status = exception instanceof HttpException ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
    if (status >= HttpStatus.INTERNAL_SERVER_ERROR) {
      const details = exception instanceof Error ? exception.stack ?? exception.message : String(exception);
      this.logger.error(`requestId=${requestId} path=${request.originalUrl.split('?')[0]} ${details}`);
    }
    const rawResponse = exception instanceof HttpException ? exception.getResponse() : null;
    const message = typeof rawResponse === 'object' && rawResponse !== null && 'message' in rawResponse
      ? (rawResponse as { message: unknown }).message
      : exception instanceof Error ? exception.message : 'Erreur interne.';
    response.status(status).json({
      statusCode: status,
      error: status >= 500 ? 'Erreur interne.' : message,
      path: request.originalUrl.split('?')[0],
      timestamp: new Date().toISOString(),
      requestId,
    });
  }
}