import { IsBoolean, IsDateString, IsNumber, IsOptional, IsString, IsUUID, MaxLength, Min } from 'class-validator';

export class CreateDailyRecordDto {
  @IsUUID()
  clientUuid!: string;

  @IsDateString()
  recordDate!: string;

  @IsNumber({ allowNaN: false, allowInfinity: false, maxDecimalPlaces: 0 })
  @Min(0)
  deaths!: number;

  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0)
  feedConsumedKg!: number;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0)
  waterConsumedLiters?: number;

  @IsOptional()
  @IsBoolean()
  suspicionReported?: boolean;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}