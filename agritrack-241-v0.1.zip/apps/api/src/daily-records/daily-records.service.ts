import { BadRequestException, ConflictException, Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AlertsService } from '../alerts/alerts.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { BatchesService } from '../batches/batches.service';
import { PerformanceService } from '../performance/performance.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateDailyRecordDto } from './dto/create-daily-record.dto';

@Injectable()
export class DailyRecordsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly batches: BatchesService,
    private readonly performance: PerformanceService,
    private readonly audit: AuditService,
    private readonly alerts: AlertsService,
  ) {}

  async list(batchId: string, user: AuthenticatedUser) {
    await this.batches.assertWritable(batchId, user).catch(async (error: unknown) => {
      if (error instanceof ConflictException) return this.batches.findOne(batchId, user);
      throw error;
    });
    return this.prisma.dailyRecord.findMany({ where: { batchId }, orderBy: { recordDate: 'asc' } });
  }

  async create(batchId: string, input: CreateDailyRecordDto, user: AuthenticatedUser) {
    const batch = await this.batches.assertWritable(batchId, user);
    const date = new Date(input.recordDate);
    const recordDate = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
    if (recordDate < batch.placedAt || recordDate > new Date()) {
      throw new BadRequestException('La date de saisie doit etre comprise entre la mise en place et aujourd hui.');
    }
    const outcome = await this.prisma.$transaction(async (transaction) => {
      await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`batch:${batchId}`}))`;
      const currentBatch = await transaction.batch.findUnique({ where: { id: batchId } });
      if (!currentBatch || currentBatch.isLocked || currentBatch.status !== 'ACTIVE') {
        throw new ConflictException('La bande est cloturee ou indisponible.');
      }
      const duplicateUuid = await transaction.dailyRecord.findUnique({ where: { clientUuid: input.clientUuid } });
      if (duplicateUuid) {
        if (duplicateUuid.batchId !== batchId) throw new ConflictException('UUID client deja utilise pour une autre bande.');
        return { record: duplicateUuid, idempotentReplay: true };
      }
      const priorRecords = await transaction.dailyRecord.findMany({ where: { batchId, recordDate: { lt: recordDate } }, select: { deaths: true } });
      const priorOutflows = await transaction.outflow.findMany({ where: { batchId, occurredAt: { lt: recordDate } }, select: { quantity: true } });
      const deathsBefore = priorRecords.reduce((sum, row) => sum + row.deaths, 0);
      const outflowsBefore = priorOutflows.reduce((sum, row) => sum + row.quantity, 0);
      const presentBefore = currentBatch.placedCount - deathsBefore - outflowsBefore;
      if (input.deaths > presentBefore) throw new BadRequestException('Les mortalites du jour depassent l effectif present.');
      const existingDate = await transaction.dailyRecord.findUnique({ where: { batchId_recordDate: { batchId, recordDate } } });
      if (existingDate) throw new ConflictException('Une saisie existe deja pour cette date et cette bande.');
      const record = await transaction.dailyRecord.create({
        data: {
          clientUuid: input.clientUuid,
          batchId,
          recordDate,
          deaths: input.deaths,
          feedConsumedKg: new Prisma.Decimal(input.feedConsumedKg),
          waterConsumedLiters: input.waterConsumedLiters === undefined ? undefined : new Prisma.Decimal(input.waterConsumedLiters),
          suspicionReported: input.suspicionReported ?? false,
          notes: input.notes,
          recordedById: user.id,
          recordedAt: new Date(),
          syncUpdatedAt: new Date(),
        },
      });
      return { record, idempotentReplay: false };
    });
    if (outcome.idempotentReplay) {
      await this.alerts.evaluateDailyRecord(outcome.record.id, user.id);
      return { ...outcome, performance: await this.performance.calculate(batchId, recordDate) };
    }
    const record = outcome.record;
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'DailyRecord', entityId: record.id, after: record });
    await this.alerts.evaluateDailyRecord(record.id, user.id);
    await this.batches.maybeAutoClose(batchId, user.id, new Date());
    return { record, idempotentReplay: false, performance: await this.performance.calculate(batchId, recordDate) };
  }
}