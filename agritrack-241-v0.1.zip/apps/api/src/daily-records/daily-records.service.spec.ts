import { BadRequestException } from '@nestjs/common';
import { AuditService } from '../audit/audit.service';
import { BatchesService } from '../batches/batches.service';
import { PerformanceService } from '../performance/performance.service';
import { PrismaService } from '../prisma/prisma.service';
import { DailyRecordsService } from './daily-records.service';

describe('DailyRecordsService coherence', () => {
  it('bloque des mortalités supérieures à l’effectif présent', async () => {
    const create = jest.fn();
    const transaction = {
      $queryRaw: jest.fn(),
      batch: { findUnique: jest.fn().mockResolvedValue({ id: 'batch-1', placedCount: 100, status: 'ACTIVE', isLocked: false }) },
      dailyRecord: { findUnique: jest.fn().mockResolvedValue(null), findMany: jest.fn().mockResolvedValue([{ deaths: 98 }]), create },
      outflow: { findMany: jest.fn().mockResolvedValue([]) },
    };
    const service = new DailyRecordsService(
      { $transaction: jest.fn((callback: (tx: typeof transaction) => unknown) => callback(transaction)) } as unknown as PrismaService,
      { assertWritable: jest.fn().mockResolvedValue({ id: 'batch-1', placedAt: new Date('2026-01-01'), placedCount: 100 }) } as unknown as BatchesService,
      { calculate: jest.fn() } as unknown as PerformanceService,
      {} as AuditService,
      { evaluateDailyRecord: jest.fn() } as never,
    );

    await expect(service.create('batch-1', {
      clientUuid: 'ad0d6856-ff79-4b9e-9f31-cfb5c67ed655',
      recordDate: '2026-01-05T00:00:00.000Z',
      deaths: 3,
      feedConsumedKg: 20,
    }, { id: 'user-1', email: 'farmer@test.ga', roles: [] })).rejects.toBeInstanceOf(BadRequestException);
    expect(create).not.toHaveBeenCalled();
  });
});