import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { CreateDailyRecordDto } from './dto/create-daily-record.dto';
import { DailyRecordsService } from './daily-records.service';

@ApiTags('Fiches quotidiennes')
@ApiBearerAuth()
@Controller('batches/:batchId/daily-records')
export class DailyRecordsController {
  constructor(private readonly records: DailyRecordsService) {}

  @Get()
  @Permissions('daily_record', PermissionAction.CONSULT)
  list(@Param('batchId') batchId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.records.list(batchId, user);
  }

  @Post()
  @Permissions('daily_record', PermissionAction.CREATE)
  create(@Param('batchId') batchId: string, @Body() body: CreateDailyRecordDto, @CurrentUser() user: AuthenticatedUser) {
    return this.records.create(batchId, body, user);
  }
}