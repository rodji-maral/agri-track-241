import { Injectable, NotFoundException } from '@nestjs/common';
import { ConfigurationStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { FormulaEngine } from '../parameters/formula-engine';

export interface PerformanceMetrics {
  ageDays: number;
  placedCount: number;
  cumulativeDeaths: number;
  cumulativeOutflows: number;
  feedConsumedKg: number;
  presentCount: number | null;
  mortalityRate: number | null;
  viabilityRate: number | null;
  averageWeightKg: number | null;
  dailyGainGrams: number | null;
  liveWeightProducedKg: number | null;
  feedConversionRatio: number | null;
  occupancyRate: number | null;
  dataCompleteness: number | null;
  recordedDays: number;
  elapsedDays: number;
}

export interface FormulaConfig {
  expression: string;
  variables: string[];
}

interface Snapshot {
  placedAt: Date;
  placedCount: number;
  initialAverageWeight: number;
  capacity: number;
  deaths: number;
  outflows: { quantity: number; averageWeight: number | null }[];
  feedConsumedKg: number;
  weighings: { weighedAt: Date; averageWeight: number }[];
  recordedDays: number;
  asOf: Date;
}

@Injectable()
export class PerformanceService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly formulas: FormulaEngine,
  ) {}

  async calculate(batchId: string, requestedDate?: Date) {
    const batch = await this.prisma.batch.findUnique({
      where: { id: batchId },
      include: {
        farm: { select: { capacity: true } },
        dailyRecords: true,
        outflows: true,
        weighings: true,
      },
    });
    if (!batch) throw new NotFoundException('Bande introuvable.');
    const asOf = requestedDate ?? new Date();
    const formulaRecords = await this.prisma.formula.findMany({
      where: { status: ConfigurationStatus.APPROVED },
      orderBy: { version: 'desc' },
    });
    const formulaMap = new Map<string, FormulaConfig>();
    for (const formula of formulaRecords) {
      if (!formulaMap.has(formula.key)) {
        formulaMap.set(formula.key, {
          expression: formula.expression,
          variables: formula.variables as string[],
        });
      }
    }
    const atDate = this.calculateSnapshot({
      placedAt: batch.placedAt,
      placedCount: batch.placedCount,
      initialAverageWeight: batch.initialAverageWeight?.toNumber() ?? 0,
      capacity: batch.farm.capacity,
      deaths: batch.dailyRecords.filter((row) => row.recordDate <= asOf).reduce((sum, row) => sum + row.deaths, 0),
      outflows: batch.outflows.filter((row) => row.occurredAt <= asOf).map((row) => ({
        quantity: row.quantity,
        averageWeight: row.averageWeight?.toNumber() ?? null,
      })),
      feedConsumedKg: batch.dailyRecords.filter((row) => row.recordDate <= asOf).reduce((sum, row) => sum + row.feedConsumedKg.toNumber(), 0),
      weighings: batch.weighings.filter((row) => row.weighedAt <= asOf).map((row) => ({
        weighedAt: row.weighedAt,
        averageWeight: row.averageWeight.toNumber(),
      })),
      recordedDays: batch.dailyRecords.filter((row) => row.recordDate <= asOf).length,
      asOf,
    }, formulaMap);

    const atEnd = batch.status === 'CLOSED' && batch.closedAt
      ? this.calculateSnapshot({
        placedAt: batch.placedAt,
        placedCount: batch.placedCount,
        initialAverageWeight: batch.initialAverageWeight?.toNumber() ?? 0,
        capacity: batch.farm.capacity,
        deaths: batch.dailyRecords.filter((row) => row.recordDate <= batch.closedAt!).reduce((sum, row) => sum + row.deaths, 0),
        outflows: batch.outflows.filter((row) => row.occurredAt <= batch.closedAt!).map((row) => ({
          quantity: row.quantity,
          averageWeight: row.averageWeight?.toNumber() ?? null,
        })),
        feedConsumedKg: batch.dailyRecords.filter((row) => row.recordDate <= batch.closedAt!).reduce((sum, row) => sum + row.feedConsumedKg.toNumber(), 0),
        weighings: batch.weighings.filter((row) => row.weighedAt <= batch.closedAt!).map((row) => ({
          weighedAt: row.weighedAt,
          averageWeight: row.averageWeight.toNumber(),
        })),
        recordedDays: batch.dailyRecords.filter((row) => row.recordDate <= batch.closedAt!).length,
        asOf: batch.closedAt,
      }, formulaMap)
      : null;
    return { batchId, evaluatedAt: asOf.toISOString(), atDate, atEnd };
  }

  calculateSnapshot(snapshot: Snapshot, formulaMap: Map<string, FormulaConfig>): PerformanceMetrics {
    const elapsedDays = Math.max(1, this.calendarDays(snapshot.placedAt, snapshot.asOf) + 1);
    const ageDays = Math.max(1, elapsedDays);
    const cumulativeOutflows = snapshot.outflows.reduce((sum, row) => sum + row.quantity, 0);
    const presentCount = this.evaluate(formulaMap, 'present_count', {
      placed: snapshot.placedCount,
      cumulative_deaths: snapshot.deaths,
      cumulative_outflows: cumulativeOutflows,
    });
    const mortalityRate = this.evaluate(formulaMap, 'mortality_rate', {
      cumulative_deaths: snapshot.deaths,
      placed: snapshot.placedCount,
    });
    const viabilityRate = mortalityRate === null
      ? null
      : this.evaluate(formulaMap, 'viability_rate', { mortality_rate: mortalityRate });
    const latestWeighing = [...snapshot.weighings].sort((a, b) => b.weighedAt.getTime() - a.weighedAt.getTime())[0];
    const averageWeightKg = latestWeighing?.averageWeight ?? (snapshot.initialAverageWeight > 0 ? snapshot.initialAverageWeight : null);
    const dailyGainGrams = averageWeightKg === null
      ? null
      : this.evaluate(formulaMap, 'daily_gain', {
        current_average_weight: averageWeightKg,
        initial_weight: snapshot.initialAverageWeight,
        age_days: ageDays,
      });
    const outflowWeight = snapshot.outflows.reduce((sum, row) =>
      sum + row.quantity * (row.averageWeight ?? averageWeightKg ?? 0), 0);
    const liveWeightProducedKg = presentCount === null || averageWeightKg === null
      ? null
      : this.evaluate(formulaMap, 'live_weight_produced', {
        outflow_weight: outflowWeight,
        present_count: presentCount,
        current_average_weight: averageWeightKg,
        placed: snapshot.placedCount,
        initial_weight: snapshot.initialAverageWeight,
      });
    const feedConversionRatio = liveWeightProducedKg === null
      ? null
      : this.evaluate(formulaMap, 'feed_conversion', {
        feed_consumed_kg: snapshot.feedConsumedKg,
        live_weight_produced_kg: liveWeightProducedKg,
      });
    return {
      ageDays,
      placedCount: snapshot.placedCount,
      cumulativeDeaths: snapshot.deaths,
      cumulativeOutflows,
      feedConsumedKg: snapshot.feedConsumedKg,
      presentCount,
      mortalityRate,
      viabilityRate,
      averageWeightKg,
      dailyGainGrams,
      liveWeightProducedKg,
      feedConversionRatio,
      occupancyRate: this.evaluate(formulaMap, 'occupancy_rate', { placed: snapshot.placedCount, capacity: snapshot.capacity }),
      dataCompleteness: this.evaluate(formulaMap, 'entry_completeness', { recorded_days: snapshot.recordedDays, elapsed_days: elapsedDays }),
      recordedDays: snapshot.recordedDays,
      elapsedDays,
    };
  }

  private evaluate(formulas: Map<string, FormulaConfig>, key: string, values: Record<string, number>): number | null {
    const formula = formulas.get(key);
    if (!formula) return null;
    try {
      return this.formulas.evaluate(formula.expression, formula.variables, values);
    } catch {
      return null;
    }
  }

  private calendarDays(start: Date, end: Date): number {
    const startUtc = Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate());
    const endUtc = Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), end.getUTCDate());
    return Math.floor((endUtc - startUtc) / 86_400_000);
  }
}