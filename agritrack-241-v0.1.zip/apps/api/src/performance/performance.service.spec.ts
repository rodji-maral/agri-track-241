import { FormulaEngine } from '../parameters/formula-engine';
import { PrismaService } from '../prisma/prisma.service';
import { FormulaConfig, PerformanceService } from './performance.service';

describe('PerformanceService', () => {
  const engine = new FormulaEngine();
  const service = new PerformanceService({} as PrismaService, engine);
  const formulas = new Map<string, FormulaConfig>([
    ['present_count', { expression: 'placed - cumulative_deaths - cumulative_outflows', variables: ['placed', 'cumulative_deaths', 'cumulative_outflows'] }],
    ['mortality_rate', { expression: 'cumulative_deaths / placed * 100', variables: ['cumulative_deaths', 'placed'] }],
    ['viability_rate', { expression: '100 - mortality_rate', variables: ['mortality_rate'] }],
    ['daily_gain', { expression: '(current_average_weight - initial_weight) / age_days * 1000', variables: ['current_average_weight', 'initial_weight', 'age_days'] }],
    ['live_weight_produced', { expression: 'outflow_weight + present_count * current_average_weight - placed * initial_weight', variables: ['outflow_weight', 'present_count', 'current_average_weight', 'placed', 'initial_weight'] }],
    ['feed_conversion', { expression: 'feed_consumed_kg / live_weight_produced_kg', variables: ['feed_consumed_kg', 'live_weight_produced_kg'] }],
    ['occupancy_rate', { expression: 'placed / capacity * 100', variables: ['placed', 'capacity'] }],
    ['entry_completeness', { expression: 'recorded_days / elapsed_days * 100', variables: ['recorded_days', 'elapsed_days'] }],
  ]);

  it('calcule des indicateurs de production à date avec valeurs connues', () => {
    const metrics = service.calculateSnapshot({
      placedAt: new Date('2026-01-01T00:00:00.000Z'),
      placedCount: 1000,
      initialAverageWeight: 0.05,
      capacity: 1200,
      deaths: 20,
      outflows: [{ quantity: 50, averageWeight: 1.4 }],
      feedConsumedKg: 2000,
      weighings: [{ weighedAt: new Date('2026-01-30T12:00:00.000Z'), averageWeight: 1.5 }],
      recordedDays: 30,
      asOf: new Date('2026-01-30T12:00:00.000Z'),
    }, formulas);

    expect(metrics.presentCount).toBe(930);
    expect(metrics.mortalityRate).toBe(2);
    expect(metrics.viabilityRate).toBe(98);
    expect(metrics.dailyGainGrams).toBeCloseTo(1450 / 30, 8);
    expect(metrics.liveWeightProducedKg).toBe(1415);
    expect(metrics.feedConversionRatio).toBeCloseTo(2000 / 1415, 8);
    expect(metrics.occupancyRate).toBeCloseTo(83.333333, 5);
    expect(metrics.dataCompleteness).toBe(100);
  });

  it('laisse les indicateurs non disponibles non renseignés sans formule approuvée', () => {
    const metrics = service.calculateSnapshot({
      placedAt: new Date('2026-01-01T00:00:00.000Z'),
      placedCount: 100,
      initialAverageWeight: 0.04,
      capacity: 100,
      deaths: 0,
      outflows: [],
      feedConsumedKg: 0,
      weighings: [],
      recordedDays: 0,
      asOf: new Date('2026-01-01T00:00:00.000Z'),
    }, new Map());
    expect(metrics.presentCount).toBeNull();
    expect(metrics.mortalityRate).toBeNull();
    expect(metrics.recordedDays).toBe(0);
  });
});