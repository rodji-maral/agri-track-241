import { Module } from '@nestjs/common';
import { ParametersModule } from '../parameters/parameters.module';
import { PerformanceService } from './performance.service';

@Module({
  imports: [ParametersModule],
  providers: [PerformanceService],
  exports: [PerformanceService],
})
export class PerformanceModule {}