import { IsDateString, IsObject, IsString, IsUUID, MaxLength, Matches } from 'class-validator';

export class SubmitEmaEventDto {
  @IsUUID()
  eventId!: string;

  @IsString()
  @Matches(/^[A-Z]{3}-\d{4}$/)
  farmCode!: string;

  @IsString()
  @MaxLength(80)
  eventType!: string;

  @IsDateString()
  occurredAt!: string;

  @IsObject()
  payload!: Record<string, unknown>;
}