import { Injectable } from '@nestjs/common';
import { EmaiPlusAdapter, EmaiPlusEvent } from './ema-i-plus.types';

@Injectable()
export class NullEmaiPlusAdapter implements EmaiPlusAdapter {
  async status(): Promise<{ configured: boolean; provider: string }> {
    return { configured: false, provider: 'EMA-i Plus (stub)' };
  }

  async submit(_event: EmaiPlusEvent): Promise<{ accepted: boolean; reference: string | null }> {
    return { accepted: false, reference: null };
  }
}