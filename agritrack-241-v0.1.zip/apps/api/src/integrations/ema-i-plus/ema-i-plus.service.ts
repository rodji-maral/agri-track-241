import { Inject, Injectable } from '@nestjs/common';
import { AuditService } from '../../audit/audit.service';
import { AuthenticatedUser } from '../../auth/auth.types';
import { EMAI_PLUS_ADAPTER, EmaiPlusAdapter, EmaiPlusEvent } from './ema-i-plus.types';

@Injectable()
export class EmaiPlusService {
  constructor(
    @Inject(EMAI_PLUS_ADAPTER) private readonly adapter: EmaiPlusAdapter,
    private readonly audit: AuditService,
  ) {}

  status() {
    return this.adapter.status();
  }

  async submit(event: EmaiPlusEvent, user: AuthenticatedUser) {
    const result = await this.adapter.submit(event);
    await this.audit.record({
      actorId: user.id,
      action: 'EMA_I_PLUS_SUBMIT_STUB',
      entityType: 'EmaiPlusEvent',
      entityId: event.eventId,
      after: { eventType: event.eventType, farmCode: event.farmCode, accepted: result.accepted },
    });
    return { ...result, mode: 'stub' as const };
  }
}