import { Body, Controller, Get, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { PermissionAction, RoleCode } from '@prisma/client';
import { AuthenticatedUser } from '../../auth/auth.types';
import { CurrentUser } from '../../auth/current-user.decorator';
import { Permissions } from '../../auth/permissions.decorator';
import { Roles } from '../../auth/roles.decorator';
import { SubmitEmaEventDto } from './dto/submit-ema-event.dto';
import { EmaiPlusService } from './ema-i-plus.service';

@ApiTags('Integration EMA-i Plus')
@ApiBearerAuth()
@Controller('integrations/ema-i-plus')
@Roles(RoleCode.POUFA_DGE, RoleCode.ADMIN)
export class EmaiPlusController {
  constructor(private readonly emaiPlus: EmaiPlusService) {}

  @Get('status')
  @Permissions('health', PermissionAction.CONSULT)
  @ApiOperation({ summary: 'Etat du connecteur EMA-i Plus' })
  status() {
    return this.emaiPlus.status();
  }

  @Post('events')
  @Permissions('health', PermissionAction.CREATE)
  @ApiOperation({ summary: "Soumission vers le stub EMA-i Plus; aucun appel externe n'est effectue" })
  submit(@Body() body: SubmitEmaEventDto, @CurrentUser() user: AuthenticatedUser) {
    return this.emaiPlus.submit(body, user);
  }
}