import { Module } from '@nestjs/common';
import { AuditModule } from '../../audit/audit.module';
import { EMAI_PLUS_ADAPTER } from './ema-i-plus.types';
import { EmaiPlusController } from './ema-i-plus.controller';
import { EmaiPlusService } from './ema-i-plus.service';
import { NullEmaiPlusAdapter } from './null-ema-i-plus.adapter';

@Module({
  imports: [AuditModule],
  controllers: [EmaiPlusController],
  providers: [
    EmaiPlusService,
    NullEmaiPlusAdapter,
    { provide: EMAI_PLUS_ADAPTER, useExisting: NullEmaiPlusAdapter },
  ],
})
export class EmaiPlusModule {}