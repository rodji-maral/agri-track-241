export interface EmaiPlusEvent {
  eventId: string;
  farmCode: string;
  eventType: string;
  occurredAt: string;
  payload: Record<string, unknown>;
}

export interface EmaiPlusAdapter {
  status(): Promise<{ configured: boolean; provider: string }>;
  submit(event: EmaiPlusEvent): Promise<{ accepted: boolean; reference: string | null }>;
}

export const EMAI_PLUS_ADAPTER = Symbol('EMAI_PLUS_ADAPTER');