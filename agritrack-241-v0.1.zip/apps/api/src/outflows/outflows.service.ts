import { randomUUID } from 'node:crypto';
import { BadRequestException, ConflictException, Injectable } from '@nestjs/common';
import { OutflowType, Prisma } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { BatchesService } from '../batches/batches.service';
import { PerformanceService } from '../performance/performance.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateOutflowDto } from './dto/create-outflow.dto';

@Injectable()
export class OutflowsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly batches: BatchesService,
    private readonly performance: PerformanceService,
    private readonly audit: AuditService,
  ) {}

  async list(batchId: string, user: AuthenticatedUser) {
    await this.batches.findOne(batchId, user);
    return this.prisma.outflow.findMany({ where: { batchId }, orderBy: { occurredAt: 'asc' }, include: { lots: true, sale: true } });
  }

  async create(batchId: string, input: CreateOutflowDto, user: AuthenticatedUser) {
    const batch = await this.batches.assertWritable(batchId, user);
    const occurredAt = new Date(input.occurredAt);
    if (occurredAt < batch.placedAt || occurredAt > new Date()) throw new BadRequestException('Date de sortie invalide.');
    if (input.type === OutflowType.SALE && input.unitPrice === undefined) {
      throw new BadRequestException('Le prix unitaire est requis pour une sortie de type vente.');
    }
    if ((input.type === OutflowType.SALE || input.type === OutflowType.SLAUGHTER) && (!input.operatorId || !input.destination?.trim())) {
      throw new BadRequestException('Le destinataire et le lieu de destination sont obligatoires pour creer un lot.');
    }
    const day = new Date(Date.UTC(occurredAt.getUTCFullYear(), occurredAt.getUTCMonth(), occurredAt.getUTCDate()));
    const result = await this.prisma.$transaction(async (transaction) => {
      await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`batch:${batchId}`}))`;
      const currentBatch = await transaction.batch.findUnique({ where: { id: batchId } });
      if (!currentBatch || currentBatch.status !== 'ACTIVE' || currentBatch.isLocked) {
        throw new ConflictException('La bande est cloturee ou indisponible.');
      }
      const duplicate = await transaction.outflow.findUnique({ where: { clientUuid: input.clientUuid } });
      if (duplicate) {
        if (duplicate.batchId !== batchId) throw new ConflictException('UUID client deja utilise pour une autre bande.');
        return { outflow: duplicate, saleId: undefined, lotId: undefined, idempotentReplay: true };
      }
      const [records, previousOutflows] = await Promise.all([
        transaction.dailyRecord.findMany({ where: { batchId, recordDate: { lte: day } }, select: { deaths: true } }),
        transaction.outflow.findMany({ where: { batchId, occurredAt: { lt: occurredAt } }, select: { quantity: true } }),
      ]);
      const deaths = records.reduce((sum, record) => sum + record.deaths, 0);
      const outflows = previousOutflows.reduce((sum, record) => sum + record.quantity, 0);
      if (input.quantity > currentBatch.placedCount - deaths - outflows) {
        throw new BadRequestException('La sortie depasse l effectif present.');
      }
      if (input.operatorId) {
        const operator = await transaction.operator.findFirst({
          where: { id: input.operatorId, active: true, agreementSignedAt: { not: null }, OR: [{ agreementExpiresAt: null }, { agreementExpiresAt: { gt: occurredAt } }] },
          select: { id: true },
        });
        if (!operator) throw new BadRequestException('Operateur inactif ou convention non valide.');
      }
      const outflow = await transaction.outflow.create({
        data: {
          clientUuid: input.clientUuid,
          batchId,
          type: input.type,
          occurredAt,
          quantity: input.quantity,
          averageWeight: input.averageWeight === undefined ? undefined : new Prisma.Decimal(input.averageWeight),
          destination: input.destination,
          reference: input.reference,
          recordedById: user.id,
        },
      });
      let saleId: string | undefined;
      if (input.type === OutflowType.SALE && input.unitPrice !== undefined) {
        const sale = await transaction.sale.create({
          data: {
            clientUuid: randomUUID(),
            batchId,
            operatorId: input.operatorId,
            outflowId: outflow.id,
            soldAt: occurredAt,
            quantity: new Prisma.Decimal(input.quantity),
            unit: 'sujet',
            unitPrice: new Prisma.Decimal(input.unitPrice),
          },
        });
        saleId = sale.id;
      }
      let lotId: string | undefined;
      if (input.type === OutflowType.SLAUGHTER || input.type === OutflowType.SALE) {
        await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`lot:${batchId}`}))`;
        const rank = (await transaction.lot.aggregate({ where: { batchId }, _max: { rank: true } }))._max.rank ?? 0;
        if (rank >= 99) throw new ConflictException('Le nombre maximal de lots numerotes pour cette bande est atteint.');
        const lot = await transaction.lot.create({
          data: {
            code: `${batch.code}-L${String(rank + 1).padStart(2, '0')}`,
            batchId,
            operatorId: input.operatorId,
            outflowId: outflow.id,
            rank: rank + 1,
            quantity: input.quantity,
            producedAt: occurredAt,
          },
        });
        await transaction.qrCode.create({ data: { lotId: lot.id } });
        await transaction.lotEvent.create({
          data: {
            clientUuid: randomUUID(),
            lotId: lot.id,
            eventType: input.type === OutflowType.SLAUGHTER ? 'SLAUGHTERED' : 'SOLD',
            occurredAt,
            location: input.destination,
            details: { outflowId: outflow.id, saleId },
            recordedById: user.id,
          },
        });
        lotId = lot.id;
      }
      return { outflow, saleId, lotId, idempotentReplay: false };
    });
    if (result.idempotentReplay) {
      return { ...result, performance: await this.performance.calculate(batchId, occurredAt) };
    }
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'Outflow', entityId: result.outflow.id, after: result });
    const performance = await this.performance.calculate(batchId, occurredAt);
    await this.batches.maybeAutoClose(batchId, user.id, new Date());
    return { ...result, performance };
  }
}