import { BadRequestException } from '@nestjs/common';
import { AuditService } from '../audit/audit.service';
import { BatchesService } from '../batches/batches.service';
import { PerformanceService } from '../performance/performance.service';
import { PrismaService } from '../prisma/prisma.service';
import { OutflowsService } from './outflows.service';

describe('OutflowsService coherence', () => {
  it('bloque les sorties supérieures à l’effectif restant', async () => {
    const create = jest.fn();
    const transaction = {
      $queryRaw: jest.fn(),
      batch: { findUnique: jest.fn().mockResolvedValue({ id: 'batch-1', placedCount: 100, status: 'ACTIVE', isLocked: false }) },
      outflow: {
        findUnique: jest.fn().mockResolvedValue(null),
        findMany: jest.fn().mockResolvedValue([{ quantity: 15 }]),
        create,
      },
      dailyRecord: { findMany: jest.fn().mockResolvedValue([{ deaths: 80 }]) },
      operator: { findFirst: jest.fn() },
    };
    const service = new OutflowsService(
      {
        $transaction: jest.fn((callback: (tx: typeof transaction) => unknown) => callback(transaction)),
      } as unknown as PrismaService,
      { assertWritable: jest.fn().mockResolvedValue({ id: 'batch-1', code: 'EST-0001-B01', placedAt: new Date('2026-01-01'), placedCount: 100 }) } as unknown as BatchesService,
      { calculate: jest.fn() } as unknown as PerformanceService,
      {} as AuditService,
    );

    await expect(service.create('batch-1', {
      clientUuid: 'ad0d6856-ff79-4b9e-9f31-cfb5c67ed656',
      type: 'TRANSFER',
      occurredAt: new Date().toISOString(),
      quantity: 6,
    }, { id: 'user-1', email: 'farmer@test.ga', roles: [] })).rejects.toBeInstanceOf(BadRequestException);
    expect(create).not.toHaveBeenCalled();
  });
});