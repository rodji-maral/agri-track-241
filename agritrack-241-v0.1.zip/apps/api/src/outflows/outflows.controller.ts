import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { CreateOutflowDto } from './dto/create-outflow.dto';
import { OutflowsService } from './outflows.service';

@ApiTags('Sorties')
@ApiBearerAuth()
@Controller('batches/:batchId/outflows')
export class OutflowsController {
  constructor(private readonly outflows: OutflowsService) {}

  @Get()
  @Permissions('outflow', PermissionAction.CONSULT)
  list(@Param('batchId') batchId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.outflows.list(batchId, user);
  }

  @Post()
  @Permissions('outflow', PermissionAction.CREATE)
  create(@Param('batchId') batchId: string, @Body() body: CreateOutflowDto, @CurrentUser() user: AuthenticatedUser) {
    return this.outflows.create(batchId, body, user);
  }
}