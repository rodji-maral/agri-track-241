import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { BatchesModule } from '../batches/batches.module';
import { PerformanceModule } from '../performance/performance.module';
import { OutflowsController } from './outflows.controller';
import { OutflowsService } from './outflows.service';

@Module({
  imports: [AuditModule, BatchesModule, PerformanceModule],
  controllers: [OutflowsController],
  providers: [OutflowsService],
})
export class OutflowsModule {}