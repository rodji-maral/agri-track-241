import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { ParametersModule } from '../parameters/parameters.module';
import { ScopeModule } from '../scopes/scope.module';
import { InputsController } from './inputs.controller';
import { InputsService } from './inputs.service';

@Module({
  imports: [AuditModule, NotificationsModule, ParametersModule, ScopeModule],
  controllers: [InputsController],
  providers: [InputsService],
  exports: [InputsService],
})
export class InputsModule {}