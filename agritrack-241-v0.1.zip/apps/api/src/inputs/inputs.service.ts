import { randomUUID } from 'node:crypto';
import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigurationStatus, Prisma, RoleCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { NotificationsService } from '../notifications/notifications.service';
import { FormulaEngine } from '../parameters/formula-engine';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { ConfirmInputReceiptDto } from './dto/confirm-input-receipt.dto';
import { CreateInputOrderDto } from './dto/create-input-order.dto';
import { CreateInputReceiptDto } from './dto/create-input-receipt.dto';
import { CreateInputUsageDto } from './dto/create-input-usage.dto';

class NegativeStockError extends Error {
  constructor(readonly available: number, readonly requested: number) {
    super('Stock intrant insuffisant.');
  }
}

@Injectable()
export class InputsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationsService,
    private readonly formulaEngine: FormulaEngine,
  ) {}

  async listReceipts(user: AuthenticatedUser, farmId?: string) {
    const farmWhere = await this.scopes.farmWhere(user, farmId);
    return this.prisma.inputReceipt.findMany({
      where: { farm: farmWhere },
      orderBy: { receivedAt: 'desc' },
      include: { farm: { select: { id: true, code: true, name: true } }, batch: { select: { id: true, code: true } } },
    });
  }

  async createReceipt(input: CreateInputReceiptDto, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, input.farmId);
    if (new Date(input.receivedAt) > new Date()) throw new BadRequestException('La date de reception ne peut pas etre future.');
    if (input.batchId && !await this.prisma.batch.findFirst({ where: { id: input.batchId, farmId: input.farmId }, select: { id: true } })) {
      throw new BadRequestException('La bande n appartient pas a cette ferme.');
    }
    const existingUnit = await this.prisma.inputReceipt.findFirst({ where: { farmId: input.farmId, inputCode: input.inputCode }, select: { unit: true } });
    if (existingUnit && existingUnit.unit !== input.unit) throw new BadRequestException('Une unite unique doit etre conservee pour cet intrant dans la ferme.');
    const existing = await this.prisma.inputReceipt.findUnique({ where: { clientUuid: input.clientUuid } });
    if (existing) {
      if (existing.farmId !== input.farmId || existing.inputCode !== input.inputCode) {
        throw new ConflictException('UUID client deja utilise pour une autre reception.');
      }
      return existing;
    }
    const receipt = await this.prisma.inputReceipt.create({
      data: {
        clientUuid: input.clientUuid,
        farmId: input.farmId,
        batchId: input.batchId,
        inputCode: input.inputCode,
        quantity: new Prisma.Decimal(input.quantity),
        unitCost: input.unitCost === undefined ? undefined : new Prisma.Decimal(input.unitCost),
        unit: input.unit,
        receivedAt: new Date(input.receivedAt),
        supplier: input.supplier,
        subsidized: Boolean(input.subsidyReference),
        subsidyReference: input.subsidyReference,
        lotNumber: input.lotNumber,
        recordedById: user.id,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'InputReceipt', entityId: receipt.id, after: receipt });
    return receipt;
  }

  async confirmReceipt(id: string, input: ConfirmInputReceiptDto, user: AuthenticatedUser) {
    if (!user.roles.includes(RoleCode.ELEVEUR)) throw new ForbiddenException('La confirmation de reception est reservee a l eleveur.');
    const receipt = await this.prisma.inputReceipt.findUnique({ where: { id } });
    if (!receipt) throw new NotFoundException('Reception intrant introuvable.');
    await this.scopes.assertFarmAccess(user, receipt.farmId);
    if (receipt.confirmedAt) return receipt;
    const updated = await this.prisma.inputReceipt.update({
      where: { id, confirmedAt: null },
      data: {
        confirmedQuantity: new Prisma.Decimal(input.confirmedQuantity),
        confirmedAt: new Date(),
        confirmedById: user.id,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CONFIRM', entityType: 'InputReceipt', entityId: id, before: receipt, after: updated });
    return updated;
  }

  async createUsage(input: CreateInputUsageDto, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, input.farmId);
    if (input.batchId) await this.prisma.batch.findFirstOrThrow({
      where: { id: input.batchId, farmId: input.farmId },
      select: { id: true },
    }).catch(() => { throw new BadRequestException('La bande n appartient pas a cette ferme.'); });
    const usageDate = new Date(input.usedAt);
    if (usageDate > new Date()) throw new BadRequestException('La date d utilisation ne peut pas etre future.');
    try {
      const usage = await this.prisma.$transaction(async (transaction) => {
        await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`input:${input.farmId}:${input.inputCode}`}))`;
        const duplicate = await transaction.inputUsage.findUnique({ where: { clientUuid: input.clientUuid } });
        if (duplicate) {
          if (duplicate.farmId !== input.farmId || duplicate.inputCode !== input.inputCode || duplicate.batchId !== input.batchId) {
            throw new ConflictException('UUID client deja utilise pour un autre usage.');
          }
          return duplicate;
        }
        if (input.receiptId) {
          const receipt = await transaction.inputReceipt.findFirst({
            where: { id: input.receiptId, farmId: input.farmId, inputCode: input.inputCode, confirmedAt: { not: null } },
            select: { id: true, unit: true },
          });
          if (!receipt) throw new BadRequestException('La reception liee est absente, non confirmee ou incompatible.');
          if (receipt.unit !== input.unit) throw new BadRequestException('Unite incompatible avec la reception.');
        }
        const receiptWithUnit = await transaction.inputReceipt.findFirst({
          where: { farmId: input.farmId, inputCode: input.inputCode, confirmedAt: { not: null } },
          select: { unit: true },
        });
        if (receiptWithUnit && receiptWithUnit.unit !== input.unit) {
          throw new BadRequestException('Unite incompatible avec le stock confirme.');
        }
        const [receipts, used] = await Promise.all([
          transaction.inputReceipt.aggregate({
            where: { farmId: input.farmId, inputCode: input.inputCode, confirmedAt: { not: null } },
            _sum: { confirmedQuantity: true },
          }),
          transaction.inputUsage.aggregate({
            where: { farmId: input.farmId, inputCode: input.inputCode },
            _sum: { quantity: true },
          }),
        ]);
        const received = receipts._sum.confirmedQuantity?.toNumber() ?? 0;
        const alreadyUsed = used._sum.quantity?.toNumber() ?? 0;
        const available = received - alreadyUsed;
        if (input.quantity > available) throw new NegativeStockError(available, input.quantity);
        return transaction.inputUsage.create({
          data: {
            clientUuid: input.clientUuid,
            farmId: input.farmId,
            batchId: input.batchId,
            inputCode: input.inputCode,
            quantity: new Prisma.Decimal(input.quantity),
            unit: input.unit,
            usedAt: usageDate,
            receiptId: input.receiptId,
            recordedById: user.id,
          },
        });
      });
      await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'InputUsage', entityId: usage.id, after: usage });
      return { usage, stock: await this.stock(input.farmId, input.inputCode, user) };
    } catch (error) {
      if (error instanceof NegativeStockError) {
        await this.notifications.notify({
          userId: user.id,
          category: 'INPUT_STOCK',
          title: 'Stock intrant insuffisant',
          message: `Utilisation refusee : stock disponible ${error.available}, demande ${error.requested}.`,
          entityType: 'Farm',
          entityId: input.farmId,
        });
        await this.audit.record({
          actorId: user.id,
          action: 'BLOCKED_NEGATIVE_STOCK',
          entityType: 'InputUsage',
          entityId: input.clientUuid,
          metadata: { farmId: input.farmId, inputCode: input.inputCode, available: error.available, requested: error.requested },
        });
        throw new BadRequestException('Le stock intrant ne peut pas devenir negatif.');
      }
      throw error;
    }
  }

  async stock(farmId: string, inputCode: string, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, farmId);
    const [receipts, usages] = await Promise.all([
      this.prisma.inputReceipt.aggregate({ where: { farmId, inputCode, confirmedAt: { not: null } }, _sum: { confirmedQuantity: true } }),
      this.prisma.inputUsage.aggregate({ where: { farmId, inputCode }, _sum: { quantity: true } }),
    ]);
    const received = receipts._sum.confirmedQuantity?.toNumber() ?? 0;
    const used = usages._sum.quantity?.toNumber() ?? 0;
    const sample = await this.prisma.inputReceipt.findFirst({ where: { farmId, inputCode, confirmedAt: { not: null } }, select: { unit: true }, orderBy: { receivedAt: 'desc' } });
    return { farmId, inputCode, received, used, stock: received - used, unit: sample?.unit ?? null };
  }

  async discrepancyReport(farmId: string, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, farmId);
    const [receipts, usages, threshold, formula] = await Promise.all([
      this.prisma.inputReceipt.findMany({ where: { farmId, confirmedAt: { not: null } } }),
      this.prisma.inputUsage.findMany({ where: { farmId } }),
      this.prisma.threshold.findFirst({ where: { key: 'input.variance_rate', status: ConfigurationStatus.APPROVED }, orderBy: { version: 'desc' } }),
      this.prisma.formula.findFirst({ where: { key: 'input_variance_rate', status: ConfigurationStatus.APPROVED }, orderBy: { version: 'desc' } }),
    ]);
    const codes = new Set([...receipts.map((item) => item.inputCode), ...usages.map((item) => item.inputCode)]);
    const rows = [...codes].map((inputCode) => {
      const delivered = receipts.filter((item) => item.inputCode === inputCode).reduce((sum, item) => sum + item.quantity.toNumber(), 0);
      const confirmed = receipts.filter((item) => item.inputCode === inputCode).reduce((sum, item) => sum + (item.confirmedQuantity?.toNumber() ?? 0), 0);
      const used = usages.filter((item) => item.inputCode === inputCode).reduce((sum, item) => sum + item.quantity.toNumber(), 0);
      const currentStock = confirmed - used;
      const discrepancyRate = delivered > 0 && formula
        ? this.formulaEngine.evaluate(formula.expression, formula.variables as string[], { delivered, used, stock: currentStock })
        : null;
      const thresholdValue = threshold?.value.toNumber() ?? null;
      return {
        inputCode,
        delivered,
        confirmed,
        used,
        stock: currentStock,
        discrepancyRate,
        threshold: thresholdValue,
        exceedsThreshold: discrepancyRate !== null && thresholdValue !== null && Math.abs(discrepancyRate) > thresholdValue,
      };
    });
    return { farmId, generatedAt: new Date().toISOString(), rows };
  }

  async createOrder(input: CreateInputOrderDto, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, input.farmId);
    const order = await this.prisma.inputOrder.create({
      data: {
        clientUuid: input.clientUuid,
        farmId: input.farmId,
        orderNumber: `IN-${randomUUID()}`,
        items: input.items as unknown as Prisma.InputJsonValue,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE_STUB', entityType: 'InputOrder', entityId: order.id, after: order });
    return order;
  }
}