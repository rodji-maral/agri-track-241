import { IsNumber, Min } from 'class-validator';

export class ConfirmInputReceiptDto {
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0.001)
  confirmedQuantity!: number;
}