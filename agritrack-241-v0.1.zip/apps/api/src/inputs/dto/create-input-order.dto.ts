import { Type } from 'class-transformer';
import { ArrayMinSize, IsArray, IsNumber, IsString, IsUUID, Matches, MaxLength, Min, ValidateNested } from 'class-validator';

class InputOrderItemDto {
  @IsString()
  @Matches(/^[A-Z0-9_-]{1,64}$/)
  inputCode!: string;

  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0.001)
  quantity!: number;

  @IsString()
  @MaxLength(24)
  unit!: string;
}

export class CreateInputOrderDto {
  @IsUUID()
  clientUuid!: string;

  @IsString()
  @MaxLength(100)
  farmId!: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => InputOrderItemDto)
  items!: InputOrderItemDto[];
}