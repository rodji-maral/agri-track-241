import { IsDateString, IsNumber, IsOptional, IsString, IsUUID, Matches, MaxLength, Min } from 'class-validator';

export class CreateInputUsageDto {
  @IsUUID()
  clientUuid!: string;

  @IsString()
  @MaxLength(100)
  farmId!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  batchId?: string;

  @IsString()
  @Matches(/^[A-Z0-9_-]{1,64}$/)
  inputCode!: string;

  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0.001)
  quantity!: number;

  @IsString()
  @MaxLength(24)
  unit!: string;

  @IsDateString()
  usedAt!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  receiptId?: string;
}