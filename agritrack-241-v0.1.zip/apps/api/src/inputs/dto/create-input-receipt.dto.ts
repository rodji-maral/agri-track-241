import { IsDateString, IsNumber, IsOptional, IsString, IsUUID, Matches, MaxLength, Min } from 'class-validator';

export class CreateInputReceiptDto {
  @IsUUID()
  clientUuid!: string;

  @IsString()
  @MaxLength(100)
  farmId!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  batchId?: string;

  @IsString()
  @Matches(/^[A-Z0-9_-]{1,64}$/)
  inputCode!: string;

  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0.001)
  quantity!: number;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0)
  unitCost?: number;

  @IsString()
  @MaxLength(24)
  unit!: string;

  @IsDateString()
  receivedAt!: string;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  supplier?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  subsidyReference?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  lotNumber?: string;
}