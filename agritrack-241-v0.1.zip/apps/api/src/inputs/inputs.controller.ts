import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { ConfirmInputReceiptDto } from './dto/confirm-input-receipt.dto';
import { CreateInputOrderDto } from './dto/create-input-order.dto';
import { CreateInputReceiptDto } from './dto/create-input-receipt.dto';
import { CreateInputUsageDto } from './dto/create-input-usage.dto';
import { InputsService } from './inputs.service';

@ApiTags('Intrants')
@ApiBearerAuth()
@Controller('inputs')
export class InputsController {
  constructor(private readonly inputs: InputsService) {}

  @Get('receipts')
  @Permissions('input', PermissionAction.CONSULT)
  listReceipts(@CurrentUser() user: AuthenticatedUser, @Query('farmId') farmId?: string) {
    return this.inputs.listReceipts(user, farmId);
  }

  @Post('receipts')
  @Permissions('input', PermissionAction.CREATE)
  createReceipt(@Body() body: CreateInputReceiptDto, @CurrentUser() user: AuthenticatedUser) {
    return this.inputs.createReceipt(body, user);
  }

  @Patch('receipts/:id/confirm')
  @Permissions('input', PermissionAction.MODIFY)
  confirmReceipt(@Param('id') id: string, @Body() body: ConfirmInputReceiptDto, @CurrentUser() user: AuthenticatedUser) {
    return this.inputs.confirmReceipt(id, body, user);
  }

  @Post('usages')
  @Permissions('input', PermissionAction.CREATE)
  createUsage(@Body() body: CreateInputUsageDto, @CurrentUser() user: AuthenticatedUser) {
    return this.inputs.createUsage(body, user);
  }

  @Get('stock')
  @Permissions('input', PermissionAction.CONSULT)
  stock(@Query('farmId') farmId: string, @Query('inputCode') inputCode: string, @CurrentUser() user: AuthenticatedUser) {
    return this.inputs.stock(farmId, inputCode, user);
  }

  @Get('discrepancies')
  @Permissions('input', PermissionAction.CONSULT)
  discrepancyReport(@Query('farmId') farmId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.inputs.discrepancyReport(farmId, user);
  }

  @Post('orders')
  @Permissions('input', PermissionAction.CREATE)
  createOrder(@Body() body: CreateInputOrderDto, @CurrentUser() user: AuthenticatedUser) {
    return this.inputs.createOrder(body, user);
  }
}