import { Module } from '@nestjs/common';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { ConfigModule } from '@nestjs/config';
import { configurationSchema } from './config/configuration';
import { AuthModule } from './auth/auth.module';
import { JwtAuthGuard } from './auth/jwt-auth.guard';
import { AccessControlGuard } from './auth/access-control.guard';
import { AuditModule } from './audit/audit.module';
import { AuditInterceptor } from './audit/audit.interceptor';
import { PrismaModule } from './prisma/prisma.module';
import { ParametersModule } from './parameters/parameters.module';
import { FarmsModule } from './farms/farms.module';
import { BatchesModule } from './batches/batches.module';
import { DailyRecordsModule } from './daily-records/daily-records.module';
import { WeighingsModule } from './weighings/weighings.module';
import { OutflowsModule } from './outflows/outflows.module';
import { HttpExceptionFilter } from './common/http-exception.filter';
import { NotificationsModule } from './notifications/notifications.module';
import { InputsModule } from './inputs/inputs.module';
import { AlertsModule } from './alerts/alerts.module';
import { HealthModule } from './health/health.module';
import { EmaiPlusModule } from './integrations/ema-i-plus/ema-i-plus.module';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { OperatorsModule } from './operators/operators.module';
import { TraceabilityModule } from './traceability/traceability.module';
import { EconomicsModule } from './economics/economics.module';
import { DashboardsModule } from './dashboards/dashboards.module';
import { ReportsModule } from './reports/reports.module';

@Module({
	imports: [
		ConfigModule.forRoot({ isGlobal: true, validationSchema: configurationSchema }),
		PrismaModule,
		AuthModule,
		AuditModule,
		ParametersModule,
		FarmsModule,
		BatchesModule,
		DailyRecordsModule,
		WeighingsModule,
		OutflowsModule,
			NotificationsModule,
			InputsModule,
			AlertsModule,
			HealthModule,
			EmaiPlusModule,
			OperatorsModule,
			TraceabilityModule,
			EconomicsModule,
			DashboardsModule,
			ReportsModule,
			ThrottlerModule.forRoot([{ ttl: 60_000, limit: 120 }]),
	],
	providers: [
		{ provide: APP_GUARD, useExisting: JwtAuthGuard },
		{ provide: APP_GUARD, useExisting: AccessControlGuard },
		{ provide: APP_GUARD, useClass: ThrottlerGuard },
		{ provide: APP_INTERCEPTOR, useExisting: AuditInterceptor },
		{ provide: APP_FILTER, useClass: HttpExceptionFilter },
	],
})
export class AppModule {}
