import { FarmStatus } from '@prisma/client';
import { IsEnum, IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateFarmStatusDto {
  @IsEnum(FarmStatus)
  status!: FarmStatus;

  @IsOptional()
  @IsString()
  @MaxLength(300)
  reason?: string;
}