import { IsString, MaxLength } from 'class-validator';

export class ImportFarmsDto {
  @IsString()
  @MaxLength(180)
  fileName!: string;

  @IsString()
  @MaxLength(2_000_000)
  csv!: string;
}