import { Cohort, ProvinceCode } from '@prisma/client';
import { IsBoolean, IsEnum, IsNumber, IsObject, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';

export class UpdateFarmDto {
  @IsOptional()
  @IsString()
  @MaxLength(120)
  name?: string;

  @IsOptional()
  @IsEnum(Cohort)
  cohort?: Cohort;

  @IsOptional()
  @IsEnum(ProvinceCode)
  provinceCode?: ProvinceCode;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  locality?: string;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(-5)
  @Max(5)
  latitude?: number;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(8)
  @Max(15)
  longitude?: number;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false, maxDecimalPlaces: 0 })
  @Min(1)
  capacity?: number;

  @IsOptional()
  @IsObject()
  infrastructure?: Record<string, unknown>;

  @IsOptional()
  @IsBoolean()
  bcegFinanced?: boolean;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  revenueDomiciliation?: string;
}