import { Cohort, ProvinceCode } from '@prisma/client';
import { IsBoolean, IsEnum, IsNumber, IsObject, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';

export class CreateFarmDto {
  @IsString()
  @MaxLength(120)
  name!: string;

  @IsEnum(Cohort)
  cohort!: Cohort;

  @IsEnum(ProvinceCode)
  provinceCode!: ProvinceCode;

  @IsString()
  @MaxLength(100)
  locality!: string;

  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(-5)
  @Max(5)
  latitude!: number;

  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(8)
  @Max(15)
  longitude!: number;

  @IsNumber({ allowNaN: false, allowInfinity: false, maxDecimalPlaces: 0 })
  @Min(1)
  capacity!: number;

  @IsOptional()
  @IsObject()
  infrastructure?: Record<string, unknown>;

  @IsOptional()
  @IsBoolean()
  bcegFinanced?: boolean;

  @IsOptional()
  @IsBoolean()
  bcegConsent?: boolean;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  revenueDomiciliation?: string;
}