import { BadRequestException } from '@nestjs/common';
import { ProvinceCode } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { FarmsService } from './farms.service';

describe('FarmsService province coherence', () => {
  it('bloque des coordonnées hors des bornes configurées de la province', async () => {
    const transaction = jest.fn();
    const service = new FarmsService(
      {
        province: {
          findUnique: jest.fn().mockResolvedValue({
            code: ProvinceCode.ESTUAIRE,
            minLatitude: { toNumber: () => -0.5 },
            maxLatitude: { toNumber: () => 1.2 },
            minLongitude: { toNumber: () => 9 },
            maxLongitude: { toNumber: () => 11.5 },
          }),
        },
        $transaction: transaction,
      } as unknown as PrismaService,
      { assertProvinceAccess: jest.fn() } as unknown as ScopeService,
      {} as AuditService,
    );

    await expect(service.create({
      name: 'Ferme hors province',
      cohort: 'COHORTE_1',
      provinceCode: ProvinceCode.ESTUAIRE,
      locality: 'Libreville',
      latitude: 3,
      longitude: 10,
      capacity: 100,
    }, { id: 'user-1', email: 'user@test.ga', roles: [] })).rejects.toBeInstanceOf(BadRequestException);
    expect(transaction).not.toHaveBeenCalled();
  });
});