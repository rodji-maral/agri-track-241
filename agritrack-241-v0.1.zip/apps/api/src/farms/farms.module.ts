import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { ScopeModule } from '../scopes/scope.module';
import { FarmsController } from './farms.controller';
import { FarmsService } from './farms.service';

@Module({
  imports: [AuditModule, ScopeModule],
  controllers: [FarmsController],
  providers: [FarmsService],
  exports: [FarmsService],
})
export class FarmsModule {}