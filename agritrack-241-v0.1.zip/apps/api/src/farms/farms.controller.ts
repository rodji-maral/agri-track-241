import { Body, Controller, Get, Param, Patch, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { CreateFarmDto } from './dto/create-farm.dto';
import { ImportFarmsDto } from './dto/import-farms.dto';
import { UpdateFarmStatusDto } from './dto/update-farm-status.dto';
import { UpdateFarmDto } from './dto/update-farm.dto';
import { FarmsService } from './farms.service';

@ApiTags('Fermes')
@ApiBearerAuth()
@Controller('farms')
export class FarmsController {
  constructor(private readonly farms: FarmsService) {}

  @Get()
  @Permissions('farm', PermissionAction.CONSULT)
  list(@CurrentUser() user: AuthenticatedUser) {
    return this.farms.list(user);
  }

  @Get(':id')
  @Permissions('farm', PermissionAction.CONSULT)
  findOne(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.farms.findOne(id, user);
  }

  @Post()
  @Permissions('farm', PermissionAction.CREATE)
  create(@Body() body: CreateFarmDto, @CurrentUser() user: AuthenticatedUser) {
    return this.farms.create(body, user);
  }

  @Patch(':id')
  @Permissions('farm', PermissionAction.MODIFY)
  update(@Param('id') id: string, @Body() body: UpdateFarmDto, @CurrentUser() user: AuthenticatedUser) {
    return this.farms.update(id, body, user);
  }

  @Patch(':id/status')
  @Permissions('farm', PermissionAction.MODIFY)
  changeStatus(@Param('id') id: string, @Body() body: UpdateFarmStatusDto, @CurrentUser() user: AuthenticatedUser) {
    return this.farms.changeStatus(id, body, user);
  }

  @Post('import')
  @Permissions('farm', PermissionAction.CREATE)
  importCsv(@Body() body: ImportFarmsDto, @CurrentUser() user: AuthenticatedUser) {
    return this.farms.importCsv(body, user);
  }
}