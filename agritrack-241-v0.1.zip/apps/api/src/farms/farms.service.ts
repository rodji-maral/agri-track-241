import { createHash } from 'node:crypto';
import { validateOrReject } from 'class-validator';
import { plainToInstance } from 'class-transformer';
import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { parse } from 'csv-parse/sync';
import {
  Cohort,
  FarmStatus,
  Prisma,
  RoleCode,
} from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { CreateFarmDto } from './dto/create-farm.dto';
import { ImportFarmsDto } from './dto/import-farms.dto';
import { UpdateFarmStatusDto } from './dto/update-farm-status.dto';
import { UpdateFarmDto } from './dto/update-farm.dto';

interface FarmCsvRow {
  name: string;
  provinceCode: string;
  locality: string;
  latitude: string;
  longitude: string;
  capacity: string;
  cohort: string;
  bcegFinanced?: string;
  bcegConsent?: string;
  revenueDomiciliation?: string;
}

@Injectable()
export class FarmsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly audit: AuditService,
  ) {}

  async list(user: AuthenticatedUser) {
    const where = await this.scopes.farmWhere(user);
    const includeDomiciliation = user.roles.includes(RoleCode.BCEG);
    const farms = await this.prisma.farm.findMany({
      where,
      orderBy: [{ provinceCode: 'asc' }, { code: 'asc' }],
      select: {
        id: true,
        code: true,
        name: true,
        status: true,
        cohort: true,
        provinceCode: true,
        locality: { select: { name: true } },
        latitude: true,
        longitude: true,
        capacity: true,
        infrastructure: true,
        bcegFinanced: true,
        createdAt: true,
        updatedAt: true,
        ...(includeDomiciliation ? { consentHistory: { where: { status: 'GRANTED', revokedAt: null, purpose: 'BCEG_FINANCING' }, select: { id: true } } } : {}),
      },
    });
    if (!includeDomiciliation) return farms;
    const eligibleIds = farms.filter((farm) => farm.bcegFinanced && farm.consentHistory.length > 0).map((farm) => farm.id);
    const domiciliation = eligibleIds.length
      ? await this.prisma.farm.findMany({ where: { id: { in: eligibleIds } }, select: { id: true, revenueDomiciliation: true } })
      : [];
    const domiciliationByFarm = new Map(domiciliation.map((farm) => [farm.id, farm.revenueDomiciliation]));
    return farms.map(({ consentHistory: _consentHistory, ...farm }) => ({
      ...farm,
      ...(domiciliationByFarm.has(farm.id) ? { revenueDomiciliation: domiciliationByFarm.get(farm.id) } : {}),
    }));
  }

  async findOne(id: string, user: AuthenticatedUser) {
    const where = await this.scopes.farmWhere(user, id);
    const farm = await this.prisma.farm.findFirst({ where, include: { locality: true } });
    if (!farm) throw new NotFoundException('Ferme introuvable.');
    const mayReadDomiciliation = user.roles.includes(RoleCode.BCEG) && farm.bcegFinanced &&
      await this.hasActiveConsent(farm.id);
    if (!mayReadDomiciliation) {
      const { revenueDomiciliation: _revenueDomiciliation, ...safeFarm } = farm;
      return safeFarm;
    }
    return farm;
  }

  async create(input: CreateFarmDto, user: AuthenticatedUser) {
    await this.scopes.assertProvinceAccess(user, input.provinceCode);
    if (input.bcegFinanced && !input.bcegConsent) {
      throw new BadRequestException('Le consentement BCEG est requis pour declarer un financement.');
    }
    const province = await this.prisma.province.findUnique({ where: { code: input.provinceCode } });
    if (!province) throw new BadRequestException('Province inconnue.');
    this.validateProvinceCoordinates(input, province);
    const prefix = await this.prisma.listValue.findFirst({
      where: { listKey: 'farm_code_prefix', code: input.provinceCode, active: true },
      orderBy: { version: 'desc' },
      select: { label: true },
    });
    if (!prefix) throw new InternalServerErrorException('Prefixe de code ferme non configure pour cette province.');

    const localityName = input.locality.trim();
    const locality = await this.prisma.locality.findFirst({
      where: { provinceCode: input.provinceCode, name: { equals: localityName, mode: 'insensitive' } },
    });
    const duplicate = await this.prisma.farm.findFirst({
      where: {
        provinceCode: input.provinceCode,
        OR: [
          { name: { equals: input.name.trim(), mode: 'insensitive' } },
          { latitude: new Prisma.Decimal(input.latitude), longitude: new Prisma.Decimal(input.longitude) },
        ],
      },
      select: { id: true, code: true },
    });
    if (duplicate) throw new ConflictException(`Une ferme presente correspond deja (${duplicate.code}).`);

    const farm = await this.prisma.$transaction(async (transaction) => {
      await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`farm:${input.provinceCode}`}))`;
      const concurrentDuplicate = await transaction.farm.findFirst({
        where: {
          provinceCode: input.provinceCode,
          OR: [
            { name: { equals: input.name.trim(), mode: 'insensitive' } },
            { latitude: new Prisma.Decimal(input.latitude), longitude: new Prisma.Decimal(input.longitude) },
          ],
        },
        select: { code: true },
      });
      if (concurrentDuplicate) throw new ConflictException(`Une ferme presente correspond deja (${concurrentDuplicate.code}).`);
      const localityRecord = locality ?? await transaction.locality.create({
        data: { provinceCode: input.provinceCode, name: localityName },
      });
      const code = await this.nextCode(transaction, `farm:${input.provinceCode}`, prefix.label, 4);
      const created = await transaction.farm.create({
        data: {
          code,
          name: input.name.trim(),
          cohort: input.cohort,
          provinceCode: input.provinceCode,
          localityId: localityRecord.id,
          latitude: new Prisma.Decimal(input.latitude),
          longitude: new Prisma.Decimal(input.longitude),
          capacity: input.capacity,
          infrastructure: (input.infrastructure ?? {}) as Prisma.InputJsonValue,
          bcegFinanced: input.bcegFinanced ?? false,
          revenueDomiciliation: input.revenueDomiciliation,
          status: FarmStatus.DRAFT,
        },
      });
      await transaction.farmStatusHistory.create({
        data: { farmId: created.id, fromStatus: null, toStatus: FarmStatus.DRAFT, changedById: user.id, reason: 'Creation' },
      });
      if (input.bcegFinanced) {
        await transaction.farmConsentHistory.create({
          data: {
            farmId: created.id,
            status: 'GRANTED',
            purpose: 'BCEG_FINANCING',
            consentedBy: user.id,
            evidenceRef: `CONSENT-${created.code}`,
          },
        });
      }
      return created;
    });
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'Farm', entityId: farm.id, after: farm });
    return farm;
  }

  async update(id: string, input: UpdateFarmDto, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, id);
    const current = await this.prisma.farm.findUnique({ where: { id }, include: { locality: true } });
    if (!current) throw new NotFoundException('Ferme introuvable.');
    const provinceCode = input.provinceCode ?? current.provinceCode;
    if (provinceCode !== current.provinceCode) await this.scopes.assertProvinceAccess(user, provinceCode);
    const latitude = input.latitude ?? current.latitude.toNumber();
    const longitude = input.longitude ?? current.longitude.toNumber();
    const province = await this.prisma.province.findUnique({ where: { code: provinceCode } });
    if (!province) throw new BadRequestException('Province inconnue.');
    this.validateProvinceCoordinates({ latitude, longitude }, province);
    const duplicate = await this.prisma.farm.findFirst({
      where: {
        id: { not: id },
        provinceCode,
        OR: [
          { name: { equals: (input.name ?? current.name).trim(), mode: 'insensitive' } },
          { latitude: new Prisma.Decimal(latitude), longitude: new Prisma.Decimal(longitude) },
        ],
      },
      select: { code: true },
    });
    if (duplicate) throw new ConflictException(`Une ferme presente correspond deja (${duplicate.code}).`);
    if (input.bcegFinanced && !current.bcegFinanced && !await this.hasActiveConsent(id)) {
      throw new BadRequestException('Le consentement BCEG doit etre enregistre avant le financement.');
    }
    const localityName = input.locality?.trim() ?? (provinceCode !== current.provinceCode ? current.locality.name : undefined);
    const locality = localityName
      ? await this.prisma.locality.upsert({
        where: { provinceCode_name: { provinceCode, name: localityName } },
        update: {},
        create: { provinceCode, name: localityName },
      })
      : undefined;
    const updated = await this.prisma.farm.update({
      where: { id },
      data: {
        name: input.name?.trim(),
        cohort: input.cohort,
        provinceCode,
        localityId: locality?.id,
        latitude: input.latitude === undefined ? undefined : new Prisma.Decimal(input.latitude),
        longitude: input.longitude === undefined ? undefined : new Prisma.Decimal(input.longitude),
        capacity: input.capacity,
        infrastructure: input.infrastructure as Prisma.InputJsonValue | undefined,
        bcegFinanced: input.bcegFinanced,
        revenueDomiciliation: input.revenueDomiciliation,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'UPDATE', entityType: 'Farm', entityId: id, before: current, after: updated });
    return updated;
  }

  async changeStatus(id: string, input: UpdateFarmStatusDto, user: AuthenticatedUser) {
    await this.scopes.assertFarmAccess(user, id);
    const current = await this.prisma.farm.findUnique({ where: { id } });
    if (!current) throw new NotFoundException('Ferme introuvable.');
    if (current.status === input.status) return current;
    const transition = `${current.status}:${input.status}`;
    const allowed = await this.prisma.listValue.findFirst({
      where: { listKey: 'farm_status_transition', code: transition, active: true },
      select: { id: true },
    });
    if (!allowed) throw new BadRequestException('Transition de statut non autorisee par le parametrage.');
    const updated = await this.prisma.$transaction(async (transaction) => {
      const result = await transaction.farm.update({ where: { id }, data: { status: input.status } });
      await transaction.farmStatusHistory.create({
        data: { farmId: id, fromStatus: current.status, toStatus: input.status, changedById: user.id, reason: input.reason },
      });
      return result;
    });
    await this.audit.record({ actorId: user.id, action: 'STATUS_CHANGE', entityType: 'Farm', entityId: id, before: current, after: updated });
    return updated;
  }

  async importCsv(input: ImportFarmsDto, user: AuthenticatedUser) {
    let rows: FarmCsvRow[];
    try {
      rows = parse(input.csv, { columns: true, skip_empty_lines: true, trim: true, bom: true, relax_column_count: false }) as FarmCsvRow[];
    } catch {
      throw new BadRequestException('Fichier CSV invalide.');
    }
    if (rows.length > 5000) throw new BadRequestException('Le fichier depasse 5000 lignes.');
    const fileHash = createHash('sha256').update(input.csv).digest('hex');
    const report = await this.prisma.importReport.create({
      data: { uploadedById: user.id, fileName: input.fileName, fileHash, status: 'PROCESSING', totalRows: rows.length, startedAt: new Date() },
    });
    const errors: { row: number; message: string }[] = [];
    let successRows = 0;
    for (const [index, row] of rows.entries()) {
      try {
        const farmInput = plainToInstance(CreateFarmDto, {
          name: row.name,
          provinceCode: row.provinceCode as CreateFarmDto['provinceCode'],
          locality: row.locality,
          latitude: Number(row.latitude),
          longitude: Number(row.longitude),
          capacity: Number(row.capacity),
          cohort: row.cohort as Cohort,
          bcegFinanced: row.bcegFinanced?.toLowerCase() === 'true',
          bcegConsent: row.bcegConsent?.toLowerCase() === 'true',
          revenueDomiciliation: row.revenueDomiciliation,
        });
        await validateOrReject(farmInput, { whitelist: true, forbidNonWhitelisted: true });
        await this.create(farmInput, user);
        successRows += 1;
      } catch (error) {
        errors.push({ row: index + 2, message: error instanceof Error ? error.message : 'Ligne invalide.' });
      }
    }
    const errorRows = errors.length;
    const updated = await this.prisma.importReport.update({
      where: { id: report.id },
      data: {
        status: errorRows === 0 ? 'COMPLETED' : successRows === 0 ? 'FAILED' : 'PARTIAL',
        successRows,
        errorRows,
        completedAt: new Date(),
        report: { errors } as Prisma.InputJsonValue,
      },
    });
    await this.audit.record({ actorId: user.id, action: 'IMPORT', entityType: 'ImportReport', entityId: report.id, after: updated });
    return updated;
  }

  private validateProvinceCoordinates(
    input: Pick<CreateFarmDto, 'latitude' | 'longitude'>,
    province: { minLatitude: Prisma.Decimal | null; maxLatitude: Prisma.Decimal | null; minLongitude: Prisma.Decimal | null; maxLongitude: Prisma.Decimal | null },
  ): void {
    if (!province.minLatitude || !province.maxLatitude || !province.minLongitude || !province.maxLongitude) {
      throw new InternalServerErrorException('Bornes GPS de la province non configurees.');
    }
    if (
      input.latitude < province.minLatitude.toNumber() || input.latitude > province.maxLatitude.toNumber() ||
      input.longitude < province.minLongitude.toNumber() || input.longitude > province.maxLongitude.toNumber()
    ) {
      throw new BadRequestException('Les coordonnees GPS ne sont pas coherentes avec la province choisie.');
    }
  }

  private async nextCode(
    transaction: Prisma.TransactionClient,
    counterKey: string,
    prefix: string,
    width: number,
  ): Promise<string> {
    await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${counterKey}))`;
    const existingCodes = await transaction.farm.findMany({
      where: { code: { startsWith: `${prefix}-` } },
      select: { code: true },
    });
    const maxExisting = existingCodes.reduce((maximum, farm) => {
      const suffix = Number(farm.code.slice(prefix.length + 1));
      return Number.isSafeInteger(suffix) ? Math.max(maximum, suffix) : maximum;
    }, 0);
    const current = await transaction.identifierCounter.findUnique({ where: { key: counterKey } });
    const ordinal = Math.max(maxExisting + 1, current ? current.nextValue : 1);
    await transaction.identifierCounter.upsert({
      where: { key: counterKey },
      create: { key: counterKey, nextValue: ordinal + 1 },
      update: { nextValue: ordinal + 1 },
    });
    return `${prefix}-${String(ordinal).padStart(width, '0')}`;
  }

  private async hasActiveConsent(farmId: string): Promise<boolean> {
    return Boolean(await this.prisma.farmConsentHistory.findFirst({
      where: { farmId, purpose: 'BCEG_FINANCING', status: 'GRANTED', revokedAt: null },
      select: { id: true },
    }));
  }
}