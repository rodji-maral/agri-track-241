import { createHash, randomUUID } from 'node:crypto';
import { UnauthorizedException, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Prisma, UserStatus } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import { PrismaService } from '../prisma/prisma.service';
import { AuthenticatedUser } from './auth.types';
import { LoginDto } from './dto/login.dto';

interface RefreshPayload {
  sub: string;
  sid: string;
  typ: 'refresh';
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  tokenType: 'Bearer';
  expiresIn: number;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
  ) {}

  async login(input: LoginDto, userAgent?: string, ipHash?: string): Promise<TokenPair> {
    const user = await this.prisma.user.findUnique({
      where: { email: input.email },
      include: { roles: { include: { role: { select: { code: true } } } } },
    });
    const passwordMatches = user ? await bcrypt.compare(input.password, user.passwordHash) : false;
    if (!user || !passwordMatches || user.status !== UserStatus.ACTIVE) {
      throw new UnauthorizedException('Identifiants invalides.');
    }
    await this.prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    return this.issueTokens(
      { id: user.id, email: user.email, roles: user.roles.map(({ role }) => role.code) },
      userAgent,
      ipHash,
    );
  }

  async refresh(refreshToken: string, userAgent?: string, ipHash?: string): Promise<TokenPair> {
    const payload = await this.verifyRefreshToken(refreshToken);
    const refreshTokenHash = this.hashToken(refreshToken);
    const now = new Date();
    return this.prisma.$transaction(async (transaction) => {
      const session = await transaction.authSession.findUnique({
        where: { refreshTokenHash },
        include: { user: { include: { roles: { include: { role: { select: { code: true } } } } } } },
      });
      if (
        !session || session.id !== payload.sid || session.userId !== payload.sub ||
        session.revokedAt || session.expiresAt <= now || session.user.status !== UserStatus.ACTIVE
      ) {
        throw new UnauthorizedException('Session invalide ou expiree.');
      }
      const revoked = await transaction.authSession.updateMany({
        where: { id: session.id, revokedAt: null, expiresAt: { gt: now } },
        data: { revokedAt: now, lastUsedAt: now },
      });
      if (revoked.count !== 1) throw new UnauthorizedException('Session deja renouvelee.');
      return this.issueTokens(
        {
          id: session.user.id,
          email: session.user.email,
          roles: session.user.roles.map(({ role }) => role.code),
        },
        userAgent,
        ipHash,
        transaction,
      );
    });
  }

  async logout(userId: string, refreshToken: string): Promise<void> {
    const payload = await this.verifyRefreshToken(refreshToken);
    if (payload.sub !== userId) throw new UnauthorizedException('Session invalide.');
    await this.prisma.authSession.updateMany({
      where: { userId, id: payload.sid, refreshTokenHash: this.hashToken(refreshToken), revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }

  private async issueTokens(
    user: AuthenticatedUser,
    userAgent?: string,
    ipHash?: string,
    transaction: Prisma.TransactionClient = this.prisma,
  ): Promise<TokenPair> {
    const accessTtl = this.durationSeconds(this.config.getOrThrow<string>('JWT_ACCESS_TTL'));
    const refreshTtl = this.durationSeconds(this.config.getOrThrow<string>('JWT_REFRESH_TTL'));
    const sessionId = randomUUID();
    const refreshToken = await this.jwt.signAsync(
      { sub: user.id, sid: sessionId, typ: 'refresh' satisfies RefreshPayload['typ'] },
      { secret: this.config.getOrThrow<string>('JWT_REFRESH_SECRET'), expiresIn: refreshTtl },
    );
    const accessToken = await this.jwt.signAsync(
      { sub: user.id, email: user.email, roles: user.roles, typ: 'access' },
      { secret: this.config.getOrThrow<string>('JWT_ACCESS_SECRET'), expiresIn: accessTtl },
    );
    await transaction.authSession.create({
      data: {
        id: sessionId,
        userId: user.id,
        refreshTokenHash: this.hashToken(refreshToken),
        expiresAt: new Date(Date.now() + refreshTtl * 1000),
        userAgent,
        ipHash,
      },
    });
    return { accessToken, refreshToken, tokenType: 'Bearer', expiresIn: accessTtl };
  }

  private async verifyRefreshToken(token: string): Promise<RefreshPayload> {
    try {
      const payload = await this.jwt.verifyAsync<RefreshPayload>(token, {
        secret: this.config.getOrThrow<string>('JWT_REFRESH_SECRET'),
      });
      if (payload.typ !== 'refresh' || !payload.sub || !payload.sid) {
        throw new UnauthorizedException('Jeton invalide.');
      }
      return payload;
    } catch {
      throw new UnauthorizedException('Jeton de renouvellement invalide ou expire.');
    }
  }

  private hashToken(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }

  private durationSeconds(value: string): number {
    const match = /^([1-9]\d*)(s|m|h|d)$/.exec(value);
    if (!match) throw new Error('Duree JWT invalide dans la configuration.');
    const amount = Number(match[1]);
    const multiplier = { s: 1, m: 60, h: 3600, d: 86400 }[match[2] as 's' | 'm' | 'h' | 'd'];
    return amount * multiplier;
  }
}
