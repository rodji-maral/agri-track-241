import { IsJWT, IsString, MaxLength } from 'class-validator';

export class RefreshDto {
  @IsString()
  @IsJWT()
  @MaxLength(4096)
  refreshToken!: string;
}
