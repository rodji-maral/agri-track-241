import { Body, Controller, Post, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { createHash } from 'node:crypto';
import { Request } from 'express';
import { AuthService } from './auth.service';
import { CurrentUser } from './current-user.decorator';
import { Public } from './public.decorator';
import { AuthenticatedUser } from './auth.types';
import { Throttle } from '@nestjs/throttler';
import { LoginDto } from './dto/login.dto';
import { RefreshDto } from './dto/refresh.dto';

@ApiTags('Authentification')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post('login')
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  login(@Body() body: LoginDto, @Req() request: Request) {
    return this.authService.login(body, request.headers['user-agent'], this.hashIp(request.ip));
  }

  @Public()
  @Post('refresh')
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  refresh(@Body() body: RefreshDto, @Req() request: Request) {
    return this.authService.refresh(body.refreshToken, request.headers['user-agent'], this.hashIp(request.ip));
  }

  @ApiBearerAuth()
  @Post('logout')
  async logout(@CurrentUser() user: AuthenticatedUser, @Body() body: RefreshDto): Promise<{ success: true }> {
    await this.authService.logout(user.id, body.refreshToken);
    return { success: true };
  }

  private hashIp(ip: string | undefined): string | undefined {
    return ip ? createHash('sha256').update(ip).digest('hex') : undefined;
  }
}
