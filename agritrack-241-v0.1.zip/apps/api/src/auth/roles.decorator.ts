import { RoleCode } from '@prisma/client';
import { SetMetadata } from '@nestjs/common';
import { ROLES_KEY } from './auth.constants';

export const Roles = (...roles: RoleCode[]): MethodDecorator & ClassDecorator =>
  SetMetadata(ROLES_KEY, roles);
