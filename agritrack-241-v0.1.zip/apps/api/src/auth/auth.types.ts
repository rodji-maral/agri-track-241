import { RoleCode } from '@prisma/client';

export interface AuthenticatedUser {
  id: string;
  email: string;
  roles: RoleCode[];
}

export interface AccessTokenPayload {
  sub: string;
  email: string;
  roles: RoleCode[];
  typ: 'access';
}
