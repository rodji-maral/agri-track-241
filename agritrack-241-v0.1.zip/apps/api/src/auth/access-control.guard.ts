import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { RoleCode } from '@prisma/client';
import { Request } from 'express';
import { AuthenticatedUser } from './auth.types';
import { PERMISSIONS_KEY, ROLES_KEY } from './auth.constants';
import { RequiredPermission } from './permissions.decorator';
import { PrismaService } from '../prisma/prisma.service';

interface RequestWithUser extends Request {
  user?: AuthenticatedUser;
}

@Injectable()
export class AccessControlGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly prisma: PrismaService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<RequestWithUser>();
    const user = request.user;
    const requiredRoles = this.reflector.getAllAndOverride<RoleCode[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    const requiredPermissions = this.reflector.getAllAndOverride<RequiredPermission[]>(PERMISSIONS_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!requiredRoles?.length && !requiredPermissions?.length) return true;
    if (!user) throw new ForbiddenException('Identite absente.');
    if (requiredRoles?.length && !requiredRoles.some((role) => user.roles.includes(role))) {
      throw new ForbiddenException('Role insuffisant.');
    }
    if (!requiredPermissions?.length) return true;

    const granted = await this.prisma.rolePermission.findMany({
      where: {
        role: { users: { some: { userId: user.id } } },
        permission: {
          OR: requiredPermissions.map(({ resource, action }) => ({ resource, action })),
        },
      },
      select: { permission: { select: { resource: true, action: true } } },
    });
    const grantedKeys = new Set(granted.map(({ permission }) => `${permission.resource}:${permission.action}`));
    const permitted = requiredPermissions.every(({ resource, action }) =>
      grantedKeys.has(`${resource}:${action}`),
    );
    if (!permitted) throw new ForbiddenException('Permission insuffisante.');
    return true;
  }
}
