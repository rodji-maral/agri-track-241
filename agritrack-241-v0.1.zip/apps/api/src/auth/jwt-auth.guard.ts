import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Reflector } from '@nestjs/core';
import { Request } from 'express';
import { IS_PUBLIC_KEY } from './auth.constants';
import { AccessTokenPayload, AuthenticatedUser } from './auth.types';
import { PrismaService } from '../prisma/prisma.service';
import { UserStatus } from '@prisma/client';

interface AuthenticatedRequest extends Request {
  user?: AuthenticatedUser;
}

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly jwtService: JwtService,
    private readonly reflector: Reflector,
    private readonly prisma: PrismaService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();
    const [scheme, token] = request.headers.authorization?.split(' ') ?? [];
    if (scheme !== 'Bearer' || !token) throw new UnauthorizedException('Authentification requise.');

    try {
      const payload = await this.jwtService.verifyAsync<AccessTokenPayload>(token, {
        secret: process.env.JWT_ACCESS_SECRET,
      });
      if (payload.typ !== 'access' || !payload.sub || !Array.isArray(payload.roles)) {
        throw new UnauthorizedException('Jeton invalide.');
      }
      const currentUser = await this.prisma.user.findUnique({
        where: { id: payload.sub },
        select: { id: true, email: true, status: true, roles: { select: { role: { select: { code: true } } } } },
      });
      if (!currentUser || currentUser.status !== UserStatus.ACTIVE) {
        throw new UnauthorizedException('Compte inactif.');
      }
      request.user = { id: currentUser.id, email: currentUser.email, roles: currentUser.roles.map(({ role }) => role.code) };
      return true;
    } catch {
      throw new UnauthorizedException('Jeton invalide ou expire.');
    }
  }
}
