import { PermissionAction } from '@prisma/client';
import { SetMetadata } from '@nestjs/common';
import { PERMISSIONS_KEY } from './auth.constants';

export interface RequiredPermission {
  resource: string;
  action: PermissionAction;
}

export const Permissions = (
  resource: string,
  action: PermissionAction,
): MethodDecorator & ClassDecorator =>
  SetMetadata(PERMISSIONS_KEY, [{ resource, action } satisfies RequiredPermission]);
