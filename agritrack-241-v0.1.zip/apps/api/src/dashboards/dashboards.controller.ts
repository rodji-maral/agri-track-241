import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction, RoleCode } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { Roles } from '../auth/roles.decorator';
import { DashboardFilterDto } from './dto/dashboard-filter.dto';
import { DashboardsService } from './dashboards.service';

@ApiTags('Tableaux de bord')
@ApiBearerAuth()
@Controller('dashboards')
export class DashboardsController {
  constructor(private readonly dashboards: DashboardsService) {}

  @Get('farmer')
  @Roles(RoleCode.ELEVEUR, RoleCode.AGENT_TECHNIQUE, RoleCode.POUFA_DGE, RoleCode.ADMIN)
  @Permissions('batch', PermissionAction.CONSULT)
  farmer(@CurrentUser() user: AuthenticatedUser) {
    return this.dashboards.farmer(user);
  }

  @Get('overview')
  @Roles(RoleCode.POUFA_DGE, RoleCode.MAEDR, RoleCode.ADMIN)
  @Permissions('aggregate', PermissionAction.CONSULT)
  overview(@Query() filter: DashboardFilterDto, @CurrentUser() user: AuthenticatedUser) {
    return this.dashboards.overview(filter, user);
  }

  @Get('ranking')
  @Roles(RoleCode.POUFA_DGE, RoleCode.ADMIN)
  @Permissions('farm', PermissionAction.CONSULT)
  ranking(@CurrentUser() user: AuthenticatedUser) {
    return this.dashboards.ranking(user);
  }

  @Post('aggregates')
  @Roles(RoleCode.POUFA_DGE, RoleCode.ADMIN)
  @Permissions('aggregate', PermissionAction.CREATE)
  submitAggregate(@Body() filter: DashboardFilterDto, @CurrentUser() user: AuthenticatedUser) {
    return this.dashboards.submitAggregate(filter, user);
  }

  @Post('aggregates/:id/approve')
  @Roles(RoleCode.MAEDR)
  @Permissions('aggregate', PermissionAction.VALIDATE)
  approveAggregate(@Param('id') id: string, @CurrentUser() user: AuthenticatedUser) {
    return this.dashboards.approveAggregate(id, user);
  }
}