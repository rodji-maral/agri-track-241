import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { ParametersModule } from '../parameters/parameters.module';
import { PerformanceModule } from '../performance/performance.module';
import { ScopeModule } from '../scopes/scope.module';
import { DashboardsController } from './dashboards.controller';
import { DashboardsService } from './dashboards.service';

@Module({
  imports: [AuditModule, ParametersModule, PerformanceModule, ScopeModule],
  controllers: [DashboardsController],
  providers: [DashboardsService],
  exports: [DashboardsService],
})
export class DashboardsModule {}