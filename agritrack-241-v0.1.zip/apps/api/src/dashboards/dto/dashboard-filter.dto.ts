import { BatchStatus, Cohort, FarmStatus, ProvinceCode } from '@prisma/client';
import { IsDateString, IsEnum, IsOptional } from 'class-validator';

export class DashboardFilterDto {
  @IsOptional()
  @IsEnum(ProvinceCode)
  provinceCode?: ProvinceCode;

  @IsOptional()
  @IsEnum(Cohort)
  cohort?: Cohort;

  @IsOptional()
  @IsEnum(FarmStatus)
  farmStatus?: FarmStatus;

  @IsOptional()
  @IsEnum(BatchStatus)
  batchStatus?: BatchStatus;

  @IsOptional()
  @IsDateString()
  from?: string;

  @IsOptional()
  @IsDateString()
  to?: string;
}