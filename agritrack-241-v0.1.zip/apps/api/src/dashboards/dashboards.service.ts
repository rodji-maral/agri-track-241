import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import {
  AggregateStatus,
  BatchStatus,
  ConfigurationStatus,
  FarmStatus,
  Prisma,
  RoleCode,
} from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { FormulaEngine } from '../parameters/formula-engine';
import { PerformanceService } from '../performance/performance.service';
import { PrismaService } from '../prisma/prisma.service';
import { ScopeService } from '../scopes/scope.service';
import { DashboardFilterDto } from './dto/dashboard-filter.dto';

interface RankingCriterion {
  metricKey: keyof Awaited<ReturnType<PerformanceService['calculate']>>['atDate'] | 'occupancyRate';
  weight: number;
  maxValue: number;
  lowerBetter: boolean;
}

@Injectable()
export class DashboardsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly scopes: ScopeService,
    private readonly performance: PerformanceService,
    private readonly formulas: FormulaEngine,
    private readonly audit: AuditService,
  ) {}

  async farmer(user: AuthenticatedUser) {
    const batches = await this.prisma.batch.findMany({
      where: await this.scopes.batchWhere(user),
      include: { farm: { select: { id: true, code: true, name: true, capacity: true } } },
      orderBy: { placedAt: 'desc' },
    });
    const batchMetrics = await Promise.all(batches.map(async (batch) => ({
      batchId: batch.id,
      batchCode: batch.code,
      status: batch.status,
      farm: batch.farm,
      ...(await this.performance.calculate(batch.id)).atDate,
    })));
    const farmIds = [...new Set(batches.map((batch) => batch.farmId))];
    const [receipts, usages] = await Promise.all([
      this.prisma.inputReceipt.findMany({ where: { farmId: { in: farmIds }, confirmedAt: { not: null } }, select: { farmId: true, inputCode: true, confirmedQuantity: true } }),
      this.prisma.inputUsage.findMany({ where: { farmId: { in: farmIds } }, select: { farmId: true, inputCode: true, quantity: true } }),
    ]);
    const codes = [...new Set([...receipts.map((item) => item.inputCode), ...usages.map((item) => item.inputCode)])];
    const benchmarkAggregate = await this.prisma.publishedAggregate.findFirst({
      where: { reportKey: { startsWith: 'dashboard.NATIONAL.ALL.' }, status: AggregateStatus.PUBLISHED },
      orderBy: { periodEnd: 'desc' },
      select: { periodEnd: true, data: true },
    });
    const benchmarkData = benchmarkAggregate?.data as { stockAverageByInput?: { inputCode: string; averageStock: number }[] } | undefined;
    const stockComparison = codes.map((inputCode) => {
      const byFarm = farmIds.map((farmId) => {
        const received = receipts.filter((item) => item.farmId === farmId && item.inputCode === inputCode)
          .reduce((sum, item) => sum + (item.confirmedQuantity?.toNumber() ?? 0), 0);
        const used = usages.filter((item) => item.farmId === farmId && item.inputCode === inputCode)
          .reduce((sum, item) => sum + item.quantity.toNumber(), 0);
        return { farmId, stock: received - used };
      });
      const own = byFarm.reduce((sum, item) => sum + item.stock, 0);
      const publishedAverage = benchmarkData?.stockAverageByInput?.find((item) => item.inputCode === inputCode);
      return {
        inputCode,
        stock: own,
        averageStock: publishedAverage?.averageStock ?? null,
        benchmarkPeriodEnd: benchmarkAggregate?.periodEnd ?? null,
      };
    });
    return { batches: batchMetrics, stockComparison };
  }

  async overview(filter: DashboardFilterDto, user: AuthenticatedUser) {
    if (user.roles.includes(RoleCode.MAEDR)) return this.publishedOverview(filter);
    if (!user.roles.some((role) => role === RoleCode.ADMIN || role === RoleCode.POUFA_DGE)) {
      throw new ForbiddenException('Le tableau de bord consolide est reserve a la DGE et a la MAEDR.');
    }
    const scope = await this.scopes.farmWhere(user);
    const farmWhere: Prisma.FarmWhereInput = {
      AND: [
        scope,
        ...(filter.provinceCode ? [{ provinceCode: filter.provinceCode }] : []),
        ...(filter.cohort ? [{ cohort: filter.cohort }] : []),
        ...(filter.farmStatus ? [{ status: filter.farmStatus }] : []),
      ],
    };
    const farms = await this.prisma.farm.findMany({ where: farmWhere, select: { id: true, capacity: true, provinceCode: true, status: true } });
    const farmIds = farms.map((farm) => farm.id);
    const batchWhere: Prisma.BatchWhereInput = {
      farmId: { in: farmIds },
      ...(filter.batchStatus ? { status: filter.batchStatus } : {}),
      ...(filter.from || filter.to ? { placedAt: { ...(filter.from ? { gte: new Date(filter.from) } : {}), ...(filter.to ? { lte: new Date(filter.to) } : {}) } } : {}),
    };
    const batches = await this.prisma.batch.findMany({ where: batchWhere });
    const metrics = await Promise.all(batches.map((batch) => this.performance.calculate(batch.id)));
    const sales = await this.prisma.sale.findMany({
      where: {
        batchId: { in: batches.map((batch) => batch.id) },
        ...(filter.from || filter.to ? { soldAt: { ...(filter.from ? { gte: new Date(filter.from) } : {}), ...(filter.to ? { lte: new Date(filter.to) } : {}) } } : {}),
      },
      select: { quantity: true, unit: true, unitPrice: true },
    });
    const [alertCount, stockReceipts, stockUsages] = await Promise.all([
      this.prisma.alert.count({ where: { farmId: { in: farmIds }, status: { not: 'CLOSED' } } }),
      this.prisma.inputReceipt.findMany({ where: { farmId: { in: farmIds }, confirmedAt: { not: null } }, select: { farmId: true, inputCode: true, confirmedQuantity: true } }),
      this.prisma.inputUsage.findMany({ where: { farmId: { in: farmIds } }, select: { farmId: true, inputCode: true, quantity: true } }),
    ]);
    const volumeByUnit = new Map<string, number>();
    const priceByUnit = new Map<string, { total: number; count: number }>();
    for (const sale of sales) {
      volumeByUnit.set(sale.unit, (volumeByUnit.get(sale.unit) ?? 0) + sale.quantity.toNumber());
      const current = priceByUnit.get(sale.unit) ?? { total: 0, count: 0 };
      current.total += sale.unitPrice.toNumber();
      current.count += 1;
      priceByUnit.set(sale.unit, current);
    }
    const mortality = metrics.map((metric) => metric.atDate.mortalityRate).filter((value): value is number => value !== null);
    const inputCodes = [...new Set([...stockReceipts.map((item) => item.inputCode), ...stockUsages.map((item) => item.inputCode)])];
    const stockAverageByInput = inputCodes.map((inputCode) => {
      const farmStocks = farmIds.map((farmId) => {
        const received = stockReceipts.filter((item) => item.farmId === farmId && item.inputCode === inputCode)
          .reduce((sum, item) => sum + (item.confirmedQuantity?.toNumber() ?? 0), 0);
        const used = stockUsages.filter((item) => item.farmId === farmId && item.inputCode === inputCode)
          .reduce((sum, item) => sum + item.quantity.toNumber(), 0);
        return received - used;
      });
      return { inputCode, averageStock: farmStocks.length ? farmStocks.reduce((sum, value) => sum + value, 0) / farmStocks.length : 0 };
    });
    return {
      provinceCode: filter.provinceCode ?? null,
      cohort: filter.cohort ?? null,
      from: filter.from ?? null,
      to: filter.to ?? null,
      activeFarms: farms.filter((farm) => farm.status === FarmStatus.ACTIVE).length,
      farmsCount: farms.length,
      batchesCount: batches.length,
      placedCount: batches.reduce((sum, batch) => sum + batch.placedCount, 0),
      presentCount: metrics.reduce((sum, metric) => sum + (metric.atDate.presentCount ?? 0), 0),
      averageMortalityPercent: mortality.length ? mortality.reduce((sum, value) => sum + value, 0) / mortality.length : null,
      producedLiveWeightKg: metrics.reduce((sum, metric) => sum + (metric.atDate.liveWeightProducedKg ?? 0), 0),
      soldVolumeByUnit: [...volumeByUnit.entries()].map(([unit, quantity]) => ({ unit, quantity })),
      averagePriceByUnit: [...priceByUnit.entries()].map(([unit, value]) => ({ unit, averageUnitPrice: value.total / value.count })),
      openHealthAlerts: alertCount,
      stockAverageByInput,
    };
  }

  async submitAggregate(filter: DashboardFilterDto, user: AuthenticatedUser) {
    if (!user.roles.includes(RoleCode.POUFA_DGE) && !user.roles.includes(RoleCode.ADMIN)) {
      throw new ForbiddenException('Seule la DGE peut soumettre un agregat.');
    }
    if (!filter.from || !filter.to) throw new BadRequestException('La periode de consolidation est obligatoire.');
    const periodStart = new Date(filter.from);
    const periodEnd = new Date(filter.to);
    if (periodStart > periodEnd) throw new BadRequestException('La date de debut doit preceder la date de fin.');
    const data = await this.overview(filter, user);
    const province = filter.provinceCode ?? 'NATIONAL';
    const reportKey = this.aggregateReportKey(filter, province);
    const existing = await this.prisma.publishedAggregate.findUnique({
      where: { reportKey_periodStart_periodEnd: { reportKey, periodStart, periodEnd } },
    });
    if (existing?.status === AggregateStatus.PUBLISHED) {
      throw new BadRequestException('Un agregat publie est immuable; une nouvelle periode est requise.');
    }
    const aggregate = await this.prisma.publishedAggregate.upsert({
      where: {
        reportKey_periodStart_periodEnd: {
          reportKey,
          periodStart,
          periodEnd,
        },
      },
      update: {
        dimensions: { province, cohort: filter.cohort ?? null },
        data: data as unknown as Prisma.InputJsonValue,
        status: AggregateStatus.SUBMITTED,
        submittedAt: new Date(),
      },
      create: {
        reportKey,
        periodStart,
        periodEnd,
        dimensions: { province, cohort: filter.cohort ?? null },
        data: data as unknown as Prisma.InputJsonValue,
        status: AggregateStatus.SUBMITTED,
        submittedAt: new Date(),
      },
    });
    await this.audit.record({ actorId: user.id, action: 'SUBMIT_AGGREGATE', entityType: 'PublishedAggregate', entityId: aggregate.id, after: aggregate });
    return aggregate;
  }

  async approveAggregate(id: string, user: AuthenticatedUser) {
    if (!user.roles.includes(RoleCode.MAEDR)) throw new ForbiddenException('La validation des agregats est reservee a la MAEDR.');
    const aggregate = await this.prisma.publishedAggregate.findUnique({ where: { id } });
    if (!aggregate) throw new NotFoundException('Agregat introuvable.');
    if (aggregate.status !== AggregateStatus.SUBMITTED) throw new BadRequestException('Seul un agregat soumis peut etre valide.');
    const published = await this.prisma.publishedAggregate.update({
      where: { id },
      data: { status: AggregateStatus.PUBLISHED, approvedById: user.id, approvedAt: new Date(), publishedAt: new Date() },
    });
    await this.audit.record({ actorId: user.id, action: 'APPROVE_AND_PUBLISH', entityType: 'PublishedAggregate', entityId: id, before: aggregate, after: published });
    return published;
  }

  async ranking(user: AuthenticatedUser) {
    const parameter = await this.prisma.parameter.findFirst({
      where: { key: 'farm.ranking.criteria', status: ConfigurationStatus.APPROVED },
      orderBy: { version: 'desc' },
    });
    if (!parameter || !Array.isArray(parameter.value)) throw new BadRequestException('Les criteres de classement ne sont pas configures.');
    const criteria = parameter.value as unknown as RankingCriterion[];
    const farms = await this.prisma.farm.findMany({
      where: await this.scopes.farmWhere(user),
      include: { batches: { where: { status: BatchStatus.ACTIVE } } },
    });
    const ranking = await Promise.all(farms.map(async (farm) => {
      const batchMetrics = await Promise.all(farm.batches.map(async (batch) => (await this.performance.calculate(batch.id)).atDate));
      const scoreData: Record<string, number | null> = {};
      for (const criterion of criteria) {
        const values = batchMetrics.map((metric) => metric[criterion.metricKey]).filter((value): value is number => typeof value === 'number');
        scoreData[criterion.metricKey] = values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null;
      }
      const totalWeight = criteria.reduce((sum, criterion) => sum + criterion.weight, 0);
      const score = totalWeight > 0 ? criteria.reduce((sum, criterion) => {
        const value = scoreData[criterion.metricKey];
        if (value === null || value === undefined || criterion.maxValue <= 0) return sum;
        const normalized = Math.min(100, Math.max(0, value / criterion.maxValue * 100));
        return sum + (criterion.lowerBetter ? 100 - normalized : normalized) * criterion.weight;
      }, 0) / totalWeight : null;
      return { farmId: farm.id, code: farm.code, name: farm.name, provinceCode: farm.provinceCode, score, criteria: scoreData };
    }));
    return ranking.sort((left, right) => (right.score ?? -1) - (left.score ?? -1));
  }

  private async publishedOverview(filter: DashboardFilterDto) {
    if (!filter.from || !filter.to) throw new BadRequestException('La periode est obligatoire pour consulter un agregat publie.');
    const reportKey = this.aggregateReportKey(filter, filter.provinceCode ?? 'NATIONAL');
    const aggregate = await this.prisma.publishedAggregate.findFirst({
      where: {
        reportKey,
        periodStart: new Date(filter.from),
        periodEnd: new Date(filter.to),
        status: AggregateStatus.PUBLISHED,
      },
    });
    if (!aggregate) throw new NotFoundException('Aucune donnee agregee MAEDR publiee pour cette periode.');
    return aggregate.data;
  }

  private aggregateReportKey(filter: DashboardFilterDto, province: string): string {
    return `dashboard.${province}.${filter.cohort ?? 'ALL'}.${filter.farmStatus ?? 'ALL'}.${filter.batchStatus ?? 'ALL'}`;
  }
}