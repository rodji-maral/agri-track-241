import * as Joi from 'joi';

export const configurationSchema = Joi.object({
  NODE_ENV: Joi.string().valid('development', 'test', 'production').default('development'),
  DATABASE_URL: Joi.string().uri({ scheme: ['postgresql', 'postgres'] }).required(),
  JWT_ACCESS_SECRET: Joi.string().min(32).required(),
  JWT_REFRESH_SECRET: Joi.string().min(32).required().invalid(Joi.ref('JWT_ACCESS_SECRET')),
  JWT_ACCESS_TTL: Joi.string().default('15m'),
  JWT_REFRESH_TTL: Joi.string().default('30d'),
  API_PORT: Joi.number().port().default(3000),
  CORS_ORIGIN: Joi.string().default('http://localhost:5173').custom((value: string, helpers: Joi.CustomHelpers) => {
    const origins = value.split(',').map((origin) => origin.trim()).filter(Boolean);
    if (origins.length === 0 || origins.some((origin) => {
      if (origin === '*') return true;
      try {
        const parsed = new URL(origin);
        return !['http:', 'https:'].includes(parsed.protocol) || parsed.origin !== origin;
      } catch {
        return true;
      }
    })) return helpers.error('any.invalid');
    return origins.join(',');
  }),
  TZ: Joi.string().default('Africa/Libreville'),
});
