import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { PermissionAction } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { CurrentUser } from '../auth/current-user.decorator';
import { Permissions } from '../auth/permissions.decorator';
import { CreateWeighingDto } from './dto/create-weighing.dto';
import { WeighingsService } from './weighings.service';

@ApiTags('Pesees')
@ApiBearerAuth()
@Controller('batches/:batchId/weighings')
export class WeighingsController {
  constructor(private readonly weighings: WeighingsService) {}

  @Get()
  @Permissions('weighing', PermissionAction.CONSULT)
  list(@Param('batchId') batchId: string, @CurrentUser() user: AuthenticatedUser) {
    return this.weighings.list(batchId, user);
  }

  @Post()
  @Permissions('weighing', PermissionAction.CREATE)
  create(@Param('batchId') batchId: string, @Body() body: CreateWeighingDto, @CurrentUser() user: AuthenticatedUser) {
    return this.weighings.create(batchId, body, user);
  }
}