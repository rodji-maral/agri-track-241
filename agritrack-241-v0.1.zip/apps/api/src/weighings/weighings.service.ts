import { BadRequestException, ConflictException, Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { AuditService } from '../audit/audit.service';
import { AuthenticatedUser } from '../auth/auth.types';
import { BatchesService } from '../batches/batches.service';
import { PerformanceService } from '../performance/performance.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateWeighingDto } from './dto/create-weighing.dto';

@Injectable()
export class WeighingsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly batches: BatchesService,
    private readonly performance: PerformanceService,
    private readonly audit: AuditService,
  ) {}

  async list(batchId: string, user: AuthenticatedUser) {
    await this.batches.findOne(batchId, user);
    return this.prisma.weighing.findMany({ where: { batchId }, orderBy: { weighedAt: 'asc' } });
  }

  async create(batchId: string, input: CreateWeighingDto, user: AuthenticatedUser) {
    const batch = await this.batches.assertWritable(batchId, user);
    const weighedAt = new Date(input.weighedAt);
    if (weighedAt < batch.placedAt || weighedAt > new Date()) throw new BadRequestException('Date de pesee invalide.');
    if (input.minWeight !== undefined && input.minWeight > input.averageWeight) {
      throw new BadRequestException('Le poids minimal depasse le poids moyen.');
    }
    if (input.maxWeight !== undefined && input.maxWeight < input.averageWeight) {
      throw new BadRequestException('Le poids maximal est inferieur au poids moyen.');
    }
    const prior = await this.prisma.weighing.findUnique({ where: { clientUuid: input.clientUuid } });
    if (prior) {
      if (prior.batchId !== batchId) throw new ConflictException('UUID client deja utilise pour une autre bande.');
      return { weighing: prior, idempotentReplay: true, reminder: await this.batches.weighingReminder(batchId, user) };
    }
    const outcome = await this.prisma.$transaction(async (transaction) => {
      await transaction.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${`batch:${batchId}`}))`;
      const currentBatch = await transaction.batch.findUnique({ where: { id: batchId } });
      if (!currentBatch || currentBatch.status !== 'ACTIVE' || currentBatch.isLocked) {
        throw new ConflictException('La bande est cloturee ou indisponible.');
      }
      const duplicate = await transaction.weighing.findUnique({ where: { clientUuid: input.clientUuid } });
      if (duplicate) {
        if (duplicate.batchId !== batchId) throw new ConflictException('UUID client deja utilise pour une autre bande.');
        return { weighing: duplicate, idempotentReplay: true };
      }
      const weighing = await transaction.weighing.create({
        data: {
          clientUuid: input.clientUuid,
          batchId,
          weighedAt,
          sampleCount: input.sampleCount,
          averageWeight: new Prisma.Decimal(input.averageWeight),
          minWeight: input.minWeight === undefined ? undefined : new Prisma.Decimal(input.minWeight),
          maxWeight: input.maxWeight === undefined ? undefined : new Prisma.Decimal(input.maxWeight),
          recordedById: user.id,
        },
      });
      return { weighing, idempotentReplay: false };
    });
    if (outcome.idempotentReplay) {
      return { ...outcome, reminder: await this.batches.weighingReminder(batchId, user) };
    }
    const weighing = outcome.weighing;
    await this.audit.record({ actorId: user.id, action: 'CREATE', entityType: 'Weighing', entityId: weighing.id, after: weighing });
    return {
      weighing,
      idempotentReplay: false,
      performance: await this.performance.calculate(batchId, weighedAt),
      reminder: await this.batches.weighingReminder(batchId, user),
    };
  }
}