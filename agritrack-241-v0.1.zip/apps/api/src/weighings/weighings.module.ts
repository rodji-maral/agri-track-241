import { Module } from '@nestjs/common';
import { AuditModule } from '../audit/audit.module';
import { BatchesModule } from '../batches/batches.module';
import { PerformanceModule } from '../performance/performance.module';
import { WeighingsController } from './weighings.controller';
import { WeighingsService } from './weighings.service';

@Module({
  imports: [AuditModule, BatchesModule, PerformanceModule],
  controllers: [WeighingsController],
  providers: [WeighingsService],
})
export class WeighingsModule {}