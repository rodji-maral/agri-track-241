import { IsDateString, IsNumber, IsOptional, IsUUID, Max, Min } from 'class-validator';

export class CreateWeighingDto {
  @IsUUID()
  clientUuid!: string;

  @IsDateString()
  weighedAt!: string;

  @IsNumber({ allowNaN: false, allowInfinity: false, maxDecimalPlaces: 0 })
  @Min(1)
  @Max(10000)
  sampleCount!: number;

  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0.001)
  averageWeight!: number;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0.001)
  minWeight?: number;

  @IsOptional()
  @IsNumber({ allowNaN: false, allowInfinity: false })
  @Min(0.001)
  maxWeight?: number;
}