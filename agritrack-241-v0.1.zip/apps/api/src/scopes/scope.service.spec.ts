import { ForbiddenException } from '@nestjs/common';
import { ScopeService } from './scope.service';
import { PrismaService } from '../prisma/prisma.service';

describe('ScopeService farm isolation', () => {
  it('intersecte un identifiant demandé avec les fermes réellement autorisées', async () => {
    const findMany = jest.fn().mockResolvedValue([{ farmId: 'farm-owned', provinceCode: null }]);
    const findFirst = jest.fn().mockResolvedValue(null);
    const service = new ScopeService({ userScope: { findMany }, farm: { findFirst } } as unknown as PrismaService);
    const user = { id: 'farmer-1', email: 'farmer@test.ga', roles: ['ELEVEUR'] };

    await expect(service.assertFarmAccess(user as never, 'farm-other')).rejects.toBeInstanceOf(ForbiddenException);
    expect(findFirst).toHaveBeenCalledWith({
      where: {
        AND: [
          { id: { in: ['farm-owned'] } },
          { id: 'farm-other' },
        ],
      },
      select: { id: true },
    });
  });
});