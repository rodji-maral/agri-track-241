import { ForbiddenException, Injectable } from '@nestjs/common';
import { Prisma, ProvinceCode, RoleCode } from '@prisma/client';
import { AuthenticatedUser } from '../auth/auth.types';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ScopeService {
  constructor(private readonly prisma: PrismaService) {}

  async farmWhere(
    user: AuthenticatedUser,
    requestedFarmId?: string,
  ): Promise<Prisma.FarmWhereInput> {
    if (this.hasGlobalFarmAccess(user)) return requestedFarmId ? { id: requestedFarmId } : {};
    const scopes = await this.prisma.userScope.findMany({
      where: { userId: user.id },
      select: { farmId: true, provinceCode: true },
    });
    const farmIds = scopes.flatMap(({ farmId }) => farmId ? [farmId] : []);
    const provinceCodes = scopes.flatMap(({ provinceCode }) => provinceCode ? [provinceCode] : []);
    const allowed: Prisma.FarmWhereInput[] = [];
    if (farmIds.length) allowed.push({ id: { in: farmIds } });
    if (provinceCodes.length) allowed.push({ provinceCode: { in: provinceCodes } });
    if (!allowed.length) return { id: '__scope_denied__' };
    const permittedWhere = allowed.length === 1 ? allowed[0] : { OR: allowed };
    const scopedWhere: Prisma.FarmWhereInput = requestedFarmId
      ? { AND: [permittedWhere, { id: requestedFarmId }] }
      : permittedWhere;
    return user.roles.includes(RoleCode.BCEG)
      ? {
        AND: [
          scopedWhere,
          { bcegFinanced: true },
          { consentHistory: { some: { purpose: 'BCEG_FINANCING', status: 'GRANTED', revokedAt: null } } },
        ],
      }
      : scopedWhere;
  }

  async batchWhere(
    user: AuthenticatedUser,
    requestedFarmId?: string,
  ): Promise<Prisma.BatchWhereInput> {
    const farm = await this.farmWhere(user, requestedFarmId);
    if (this.isDenied(farm)) return { id: '__scope_denied__' };
    return { farm };
  }

  async findFarms(user: AuthenticatedUser, args: Omit<Prisma.FarmFindManyArgs, 'where'> = {}) {
    return this.prisma.farm.findMany({ ...args, where: await this.farmWhere(user) });
  }

  async findBatches(user: AuthenticatedUser, args: Omit<Prisma.BatchFindManyArgs, 'where'> = {}) {
    return this.prisma.batch.findMany({ ...args, where: await this.batchWhere(user) });
  }

  async assertFarmAccess(user: AuthenticatedUser, farmId: string): Promise<void> {
    const farm = await this.prisma.farm.findFirst({ where: await this.farmWhere(user, farmId), select: { id: true } });
    if (!farm) throw new ForbiddenException('Acces refuse a cette ferme.');
  }

  async assertProvinceAccess(user: AuthenticatedUser, provinceCode: ProvinceCode): Promise<void> {
    if (this.hasGlobalFarmAccess(user)) return;
    const scope = await this.prisma.userScope.findFirst({
      where: { userId: user.id, kind: 'PROVINCE', provinceCode },
      select: { id: true },
    });
    if (!scope) throw new ForbiddenException('Acces refuse a cette province.');
  }

  private hasGlobalFarmAccess(user: AuthenticatedUser): boolean {
    return user.roles.some((role) => role === RoleCode.ADMIN || role === RoleCode.POUFA_DGE);
  }

  private isDenied(where: Prisma.FarmWhereInput): boolean {
    return where.id === '__scope_denied__';
  }
}
